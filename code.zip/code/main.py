"""Deterministic-first deletion audit pipeline for Ghost Data Still Exists."""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import json
import os
import re
import shutil
import sqlite3
import sys
import subprocess
import tempfile
import unicodedata
import urllib.error
import urllib.request
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None


REPO_ROOT = Path(__file__).resolve().parents[1]
DATASET_DIR = REPO_ROOT / "dataset"
OUTPUT_COLUMNS = ("case_id", "deletion_status", "steps_json")
MAX_ABSENCE_COVERAGE_AGE = timedelta(days=7)
RESOURCE_PATTERN = re.compile(
    r"\b(?:account|analytics|audit|backup|cache|data|email|export|legal|"
    r"marketing|object|search|support|tombstone)_[A-Za-z0-9][A-Za-z0-9_-]*\b",
    re.IGNORECASE,
)
EMAIL_PATTERN = re.compile(r"[\w.+%'-]+@[\w.-]+\.[A-Za-z]{2,}", re.UNICODE)
PHONE_PATTERN = re.compile(r"(?<!\w)\+?[\d(). -]{7,}\d(?!\w)")
HASH_PATTERN = re.compile(r"\b[a-f0-9]{32,128}\b", re.IGNORECASE)

DELETION_TERMS = (
    "delete", "deleting", "deletion", "erase", "erasing", "erasure", "wipe",
    "wiping", "purge", "purging", "right to be forgotten", "close my account",
    "close this account", "close the account", "account closure", "closed permanently",
    "remove my data", "remove my account", "remove my profile", "remove the profile",
    "remove records", "remove that search result", "clean my personal details",
    "clean the personal details", "clean personal data out", "already been removed",
    "already removed", "profile is gone", "account is gone", "account page is gone",
    "profile still appears", "still existed", "nothing tied to", "nothing in analytics",
    "like it closed",
    "exclus\u00e3o", "exclusao", "excluir", "exclua", "excluam",
    "elimina\u00e7\u00e3o", "eliminacao", "eliminar", "apagar", "apague", "apaguem",
    "deletar", "deleta\u00e7\u00e3o", "deletacao",
    "eliminar", "eliminación", "eliminacion", "borrar", "suprimir", "supresión",
    "suppression", "supresion", "supprim", "effacer", "lösch", "loesch", "löschen", "cancellare",
    "apagar", "excluir", "verwijder", "wissen", "削除", "消去", "删除", "刪除",
    "삭제", "탈퇴", "удалить", "удаление", "حذف", "احذف", "silin",
    "hesabımı sil", "हटाना", "मिटाना",
)
NEGATED_DELETION_PATTERNS = (
    re.compile(
        r"\b(?:n\u00e3o|nao)\s+(?:quero|desejo|solicito|pe\u00e7o|pretendo|autorizo)"
        r"(?:\s+que)?\s+(?:se\s+)?(?:exclu\w*|elim\w*|apag\w*|delet\w*)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:n\u00e3o|nao)\s+(?:\u00e9|e)\s+(?:um\s+)?(?:pedido|solicita\u00e7\u00e3o|"
        r"solicitacao)\s+de\s+(?:exclus\u00e3o|exclusao|elimina\u00e7\u00e3o|eliminacao)\b",
        re.IGNORECASE,
    ),
    re.compile(r"\b(?:do not|don't|never|not|no)\s+(?:want(?: you to)?\s+)?"
               r"(?:delete|deleting|deletion|erase|erasing|erasure|remove|removal|"
               r"purge|close|closure)\b", re.IGNORECASE),
    re.compile(r"\b(?:not|no)\s+(?:a\s+)?deletion\b", re.IGNORECASE),
    re.compile(
        r"\b(?:not|no)\s+(?:a\s+)?(?:request|request to|request for)\s+"
        r"(?:to\s+)?(?:delete|deleting|deletion|erase|erasing|erasure|remove|removal|"
        r"purge|close|closure)\b",
        re.IGNORECASE,
    ),
    re.compile(r"\b(?:not asking|not requesting|not authori[sz]ing)\s+"
               r"(?:you\s+to\s+|for\s+)?(?:delete|deleting|deletion|erase|erasing|"
               r"erasure|remove|removal|purge|close|closure)\b", re.IGNORECASE),
    re.compile(r"(?:不要|不需要|不能|不想).{0,8}(?:删除|刪除|削除|삭제)"),
    re.compile(r"(?:削除|刪除|删除|삭제).{0,8}(?:しないで|하지\s*마|不要)"),
)

SYSTEM_BY_PREFIX = {
    "account": "account_service",
    "analytics": "analytics_platform",
    "audit": "security_service",
    "backup": "backup_service",
    "cache": "cache_service",
    "data": "integration_service",
    "email": "email_delivery_service",
    "export": "export_service",
    "legal": "legal_service",
    "marketing": "marketing_platform",
    "object": "object_storage",
    "search": "search_service",
    "support": "support_platform",
    "tombstone": "identity_service",
}

TABLE_CATEGORY = {
    "backup_restore_entries": "BACKUP_ARCHIVE",
    "connector_subscriptions": "DATA_FLOW",
    "customer_analytics_profiles": "ANALYTICS_PROFILE",
    "customer_exports": "USER_EXPORT",
    "customer_profiles": "USER_PROFILE",
    "customer_profiles_primary": "USER_PROFILE",
    "customer_profiles_failover_replica": "USER_PROFILE",
    "customer_search_documents": "SEARCH_INDEX_ENTRY",
    "search_documents_primary": "SEARCH_INDEX_ENTRY",
    "security_audit_records": "SECURITY_AUDIT_LOG",
    "support_records": "SUPPORT_MESSAGE",
}

COLLECTION_CATEGORY = {
    "backup_catalog": "BACKUP_ARCHIVE",
    "connector_configurations": "DATA_FLOW",
    "customer_analytics_reports": "ANALYTICS_PROFILE",
    "customer_export_jobs": "USER_EXPORT",
    "customer_profiles": "USER_PROFILE",
    "customer_search_documents": "SEARCH_INDEX_ENTRY",
    "deleted_customer_references": "ACCOUNT_TOMBSTONE",
    "operational_record_history": "SECURITY_AUDIT_LOG",
    "retained_order_records": "SECURITY_AUDIT_LOG",
    "security_audit_events": "SECURITY_AUDIT_LOG",
    "support_conversations": "SUPPORT_MESSAGE",
    "ticket_attachments": "SUPPORT_ATTACHMENT",
}

CATEGORY_SYSTEM = {
    "USER_PROFILE": "account_service",
    "SECONDARY_IDENTIFIER": "identity_service",
    "SEARCH_INDEX_ENTRY": "search_service",
    "CACHE_ENTRY": "cache_service",
    "SUPPORT_MESSAGE": "support_platform",
    "SUPPORT_ATTACHMENT": "object_storage",
    "ANALYTICS_PROFILE": "analytics_platform",
    "PRODUCT_TELEMETRY": "analytics_platform",
    "USER_EXPORT": "export_service",
    "MARKETING_PROFILE": "marketing_platform",
    "EMAIL_DELIVERY_LOG": "email_delivery_service",
    "SECURITY_AUDIT_LOG": "security_service",
    "LEGAL_HOLD_RECORD": "legal_service",
    "BACKUP_ARCHIVE": "backup_service",
    "ACCOUNT_TOMBSTONE": "identity_service",
    "DATA_FLOW": "integration_service",
}

FINDING_OPERATION = {
    "DELETE": "REPORT_REMAINING_RECORD",
    "REDACT": "REPORT_EXPOSED_PII",
    "ANONYMIZE": "REPORT_EXPOSED_PII",
    "RETAIN": "REPORT_REMAINING_RECORD",
}
REMEDIATION_OPERATION = {
    "DELETE": "DELETE_RECORD",
    "REDACT": "REDACT_RECORD",
    "ANONYMIZE": "ANONYMIZE_RECORD",
}
VERIFICATION_OPERATION = {
    "DELETE": ("VERIFY_RECORD_ABSENT", "ABSENT"),
    "REDACT": ("VERIFY_RECORD_REDACTED", "REDACTED"),
    "ANONYMIZE": ("VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"),
    "RETAIN": ("VERIFY_RECORD_PRESENT", "PRESENT"),
}
PHASE_ORDER = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}
OPERATION_ORDER = {
    "REPORT_REMAINING_RECORD": 0,
    "REPORT_EXPOSED_PII": 1,
    "REPORT_ACTIVE_DATA_FLOW": 2,
    "REPORT_RESTORE_RISK": 3,
    "DISABLE_DATA_FLOW": 0,
    "BLOCK_RESTORE": 1,
    "DELETE_RECORD": 2,
    "REDACT_RECORD": 3,
    "ANONYMIZE_RECORD": 4,
    "VERIFY_RECORD_ABSENT": 0,
    "VERIFY_RECORD_PRESENT": 1,
    "VERIFY_RECORD_REDACTED": 2,
    "VERIFY_RECORD_ANONYMIZED": 3,
    "VERIFY_DATA_FLOW_DISABLED": 4,
    "VERIFY_RESTORE_BLOCKED": 5,
}
ACTION_ORDER = {name: index for index, name in enumerate(
    ("DELETE", "REDACT", "ANONYMIZE", "RETAIN")
)}
COPY_EVENT_TYPES = {
    "CREATE_EXPORT", "INDEX_RECORD", "REFRESH_CACHE", "RESTORE_BACKUP", "SYNC_RECORD",
}
ACTIVITY_TREATMENT = {
    "DELETE_RECORD": "DELETE",
    "REDACT_RECORD": "REDACT",
    "ANONYMIZE_RECORD": "ANONYMIZE",
}
PII_FIELD_MARKERS = (
    "email", "phone", "full_name", "customer_name", "requester_name",
    "customer_email", "requester_email", "customer_phone", "requester_phone",
    "email_hash", "display_name",
)
IDENTITY_REFERENCE_FIELDS = {
    "user_id", "customer_reference", "subject_reference", "user_reference",
    "subject_ref", "subject_selector", "subject_id", "customer_id", "account_id",
}


class PipelineError(ValueError):
    pass


@dataclass(frozen=True)
class Identity:
    user_id: str
    fields: dict[str, set[str]]

    @property
    def aliases(self) -> set[str]:
        return {value for values in self.fields.values() for value in values if value}


@dataclass
class Observation:
    system_id: str
    resource_id: str
    category: str
    evidence_id: str
    observed_at: datetime
    fields: dict[str, Any]
    snapshot: bool
    source_path: str
    event_type: str = ""
    scope_id: str = ""


@dataclass
class Coverage:
    system_id: str
    category: str
    evidence_id: str
    observed_at: datetime
    source_path: str
    replica: bool = False


@dataclass(frozen=True)
class ImageTextExtractor:
    name: str
    extract_tsv: Callable[[Path], str]
    cache_key: str = ""


@dataclass
class Activity:
    activity_id: str
    event_time: datetime
    event_type: str
    source_system: str
    target_system: str
    resource_id: str
    details: str
    reported_result: str


@dataclass
class Step:
    phase: str
    system_id: str
    resource_id: str
    operation: str
    state: str
    evidence_id: str


def parse_time(value: Any) -> datetime | None:
    if value is None:
        return None
    value = str(value).strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def read_csv(path: Path, required: Iterable[str]) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames is None:
                raise PipelineError(f"CSV has no header: {path}")
            missing = set(required) - set(reader.fieldnames)
            if missing:
                raise PipelineError(f"CSV {path} is missing columns: {sorted(missing)}")
            return [dict(row) for row in reader]
    except OSError as exc:
        raise PipelineError(f"Cannot read CSV: {path}") from exc


def resolve_dataset_path(value: str) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = REPO_ROOT / path
    return path.resolve()


def is_deletion_request(text: str) -> bool:
    normalized = unicodedata.normalize("NFKC", text or "").casefold()
    if any(pattern.search(normalized) for pattern in NEGATED_DELETION_PATTERNS):
        return False
    return any(term in normalized for term in DELETION_TERMS)


def normalize_email(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).strip().casefold()


def normalize_phone(value: Any) -> str:
    return re.sub(r"\D", "", str(value or ""))


def load_identity_rows(dataset_dir: Path) -> tuple[dict[str, dict[str, str]], list[dict[str, str]]]:
    identities = read_csv(
        dataset_dir / "user_identities.csv",
        ("user_id", "name", "email", "phone", "email_hash", "updated_at"),
    )
    audits = read_csv(
        dataset_dir / "user_audit_log.csv",
        ("audit_id", "user_id", "event_time", "field_name", "old_value", "new_value"),
    )
    by_user = {row["user_id"]: row for row in identities if row["user_id"]}
    return by_user, audits


def identity_at(
    user_id: str,
    cutoff: datetime,
    identity_rows: dict[str, dict[str, str]],
    audits: list[dict[str, str]],
) -> Identity:
    fields: dict[str, set[str]] = defaultdict(set)
    current = identity_rows.get(user_id)
    if current:
        updated_at = parse_time(current.get("updated_at"))
        if updated_at is not None and updated_at <= cutoff:
            for field_name in ("name", "email", "phone", "email_hash"):
                value = current.get(field_name, "")
                if value:
                    fields[field_name].add(value)

    for row in audits:
        if row.get("user_id") != user_id:
            continue
        event_time = parse_time(row.get("event_time"))
        if event_time is None or event_time > cutoff:
            continue
        field_name = row.get("field_name", "").strip().casefold()
        if field_name in {"name", "email", "phone", "email_hash"}:
            for key in ("old_value", "new_value"):
                value = row.get(key, "")
                if value:
                    fields[field_name].add(value)
    return Identity(user_id=user_id, fields=dict(fields))


def resolve_identity(
    email: str,
    cutoff: datetime,
    identity_rows: dict[str, dict[str, str]],
    audits: list[dict[str, str]],
) -> Identity | None:
    target = normalize_email(email)
    matches: list[Identity] = []
    for user_id in sorted(identity_rows):
        identity = identity_at(user_id, cutoff, identity_rows, audits)
        if any(normalize_email(value) == target for value in identity.fields.get("email", set())):
            matches.append(identity)
    if len(matches) == 1:
        return matches[0]

    # Fallback: try matching on historical emails from audit log
    # Build a map of all emails ever used by each user up to cutoff
    historical_emails: dict[str, set[str]] = defaultdict(set)
    for row in audits:
        event_time = parse_time(row.get("event_time"))
        if event_time is None or event_time > cutoff:
            continue
        if row.get("field_name", "").strip().casefold() == "email":
            user_id = row.get("user_id", "")
            if user_id:
                for key in ("old_value", "new_value"):
                    value = row.get(key, "")
                    if value:
                        historical_emails[user_id].add(normalize_email(value))

    # Also include current emails
    for user_id, row in identity_rows.items():
        updated_at = parse_time(row.get("updated_at"))
        if updated_at is not None and updated_at <= cutoff:
            current_email = row.get("email", "")
            if current_email:
                historical_emails[user_id].add(normalize_email(current_email))

    matches = []
    for user_id, emails in historical_emails.items():
        if target in emails:
            identity = identity_at(user_id, cutoff, identity_rows, audits)
            matches.append(identity)

    if len(matches) == 1:
        return matches[0]
    return None


def _walk_values(value: Any) -> Iterable[tuple[str, Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield str(key).casefold(), child
            yield from _walk_values(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk_values(child)


def _flatten_record(value: Any, prefix: str = "") -> dict[str, Any]:
    flattened: dict[str, Any] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(child, dict):
                flattened.update(_flatten_record(child, path))
            elif isinstance(child, list):
                flattened[path] = child
                for index, item in enumerate(child):
                    if isinstance(item, (dict, list)):
                        flattened.update(_flatten_record(item, f"{path}.{index}"))
                    else:
                        flattened[f"{path}.{index}"] = item
            else:
                flattened[path] = child
    else:
        flattened[prefix or "value"] = value
    return flattened


def _category_from_hints(resource_id: str, *hints: str) -> str:
    known_categories = {
        "USER_PROFILE", "SECONDARY_IDENTIFIER", "SEARCH_INDEX_ENTRY", "ANALYTICS_PROFILE",
        "USER_EXPORT", "SUPPORT_MESSAGE", "SUPPORT_ATTACHMENT", "SECURITY_AUDIT_LOG",
        "LEGAL_HOLD_RECORD", "BACKUP_ARCHIVE", "DATA_FLOW", "ACCOUNT_TOMBSTONE",
        "CACHE_ENTRY", "MARKETING_PROFILE", "EMAIL_DELIVERY_LOG",
    }
    for hint in hints:
        explicit = str(hint or "").strip().upper().replace("-", "_")
        if explicit in known_categories:
            return explicit

    # Extract prefix from resource_id (e.g., "account" from "account_2064")
    prefix_match = re.match(r"(account|analytics|audit|backup|cache|data|email|export|legal|marketing|object|search|support|tombstone)_", resource_id or "", re.IGNORECASE)
    if prefix_match:
        prefix = prefix_match.group(1).casefold()
        category = {
            "account": "USER_PROFILE",
            "analytics": "ANALYTICS_PROFILE",
            "audit": "SECURITY_AUDIT_LOG",
            "backup": "BACKUP_ARCHIVE",
            "cache": "CACHE_ENTRY",
            "data": "DATA_FLOW",
            "email": "EMAIL_DELIVERY_LOG",
            "export": "USER_EXPORT",
            "legal": "LEGAL_HOLD_RECORD",
            "marketing": "MARKETING_PROFILE",
            "object": "SUPPORT_ATTACHMENT",
            "search": "SEARCH_INDEX_ENTRY",
            "support": "SUPPORT_MESSAGE",
            "tombstone": "ACCOUNT_TOMBSTONE",
        }.get(prefix, "")
        if category:
            return category

    normalized_hints = [str(hint or "").casefold().replace("-", "_") for hint in hints]
    for hint in normalized_hints:
        if hint in COLLECTION_CATEGORY:
            return COLLECTION_CATEGORY[hint]
    combined = " ".join(normalized_hints)
    for collection, category in COLLECTION_CATEGORY.items():
        if collection in combined:
            return category
    if "connector" in combined or "data_flow" in combined or "subscription" in combined:
        return "DATA_FLOW"
    if "attachment" in combined or "object_storage" in combined:
        return "SUPPORT_ATTACHMENT"
    if "tombstone" in combined or "deleted_customer_reference" in combined:
        return "ACCOUNT_TOMBSTONE"
    if "analytics" in combined or "telemetry" in combined:
        return "ANALYTICS_PROFILE"
    if "search" in combined or "index" in combined:
        return "SEARCH_INDEX_ENTRY"
    if "backup" in combined or "archive" in combined:
        return "BACKUP_ARCHIVE"
    if "user_export" in combined or "customer_export_jobs" in combined:
        return "USER_EXPORT"
    if "support" in combined or "ticket" in combined:
        return "SUPPORT_MESSAGE"
    if "security_audit" in combined or "security" in combined:
        return "SECURITY_AUDIT_LOG"
    if "legal" in combined or "hold" in combined:
        return "LEGAL_HOLD_RECORD"
    if "marketing" in combined:
        return "MARKETING_PROFILE"
    if "email_delivery" in combined or "delivery_log" in combined:
        return "EMAIL_DELIVERY_LOG"
    return ""


def _system_for(category: str, resource_id: str, table_name: str = "", explicit: str = "") -> str:
    table = table_name.casefold()
    if "failover_replica" in table and category == "USER_PROFILE":
        return CATEGORY_SYSTEM[category]
    if explicit in CATEGORY_SYSTEM.values():
        return explicit
    if category in CATEGORY_SYSTEM:
        return CATEGORY_SYSTEM[category]
    prefix = RESOURCE_PATTERN.match(resource_id or "")
    return SYSTEM_BY_PREFIX.get(prefix.group(0).casefold(), "") if prefix else ""


def _truthy(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if value is None:
        return None
    normalized = str(value).strip().casefold()
    if normalized in {"true", "1", "yes", "enabled", "active", "allowed", "open", "live"}:
        return True
    if normalized in {"false", "0", "no", "disabled", "inactive", "blocked", "closed", "deleted"}:
        return False
    return None


def _record_time(fields: dict[str, Any], default: datetime) -> datetime:
    for name, value in _walk_values(fields):
        if name.split(".")[-1] in {
            "updated_at", "created_at", "recorded_at", "indexed_at", "event_time",
            "captured_at", "modified_at", "last_modified",
        }:
            parsed = parse_time(value)
            if parsed is not None:
                return parsed
    return default


def _record_resource_id(fields: dict[str, Any]) -> str:
    # First check for explicit resource_id at top level
    if isinstance(fields.get("resource_id"), str):
        value = fields["resource_id"].strip()
        if RESOURCE_PATTERN.fullmatch(value):
            return value
    for name, value in _walk_values(fields):
        if name.split(".")[-1] in {"resource_id", "record_id", "object_id", "_id"}:
            if isinstance(value, str) and RESOURCE_PATTERN.fullmatch(value.strip()):
                return value.strip()
    for _, value in _walk_values(fields):
        if isinstance(value, str):
            match = RESOURCE_PATTERN.search(value)
            if match:
                return match.group(0)
    return ""


def _row_category(table_name: str, fields: dict[str, Any], resource_id: str) -> str:
    if table_name in TABLE_CATEGORY:
        return TABLE_CATEGORY[table_name]
    collection = str(fields.get("collection_name", fields.get("collection", "")))
    return _category_from_hints(resource_id, collection, table_name)


def _json_records(value: Any, context: dict[str, Any] | None = None) -> Iterable[dict[str, Any]]:
    context = context or {}
    if isinstance(value, dict):
        merged_context = dict(context)
        for key in ("source", "origin", "data_store", "collection", "captured_at", "exported_at"):
            if isinstance(value.get(key), (str, int, float)):
                merged_context[key] = value[key]
        record = dict(merged_context)
        record.update(value)
        direct_ids = {
            key: child for key, child in value.items()
            if key.split(".")[-1] in {"resource_id", "record_id", "object_id", "_id"}
            and isinstance(child, (str, int))
        }
        if _record_resource_id(direct_ids):
            yield record
        for key, child in value.items():
            child_context = dict(merged_context)
            if key in {"records", "snapshots", "service_exports"}:
                child_context["collection"] = child_context.get("collection", key)
            yield from _json_records(child, child_context)
    elif isinstance(value, list):
        for child in value:
            yield from _json_records(child, context)


def _parse_details(detail: str) -> dict[str, Any]:
    parsed: dict[str, Any] = {"text": detail}
    for key, value in re.findall(r"([A-Za-z][A-Za-z0-9_ -]{0,30})\s*[:=]\s*([^;,|]+)", detail):
        parsed[key.strip().casefold().replace(" ", "_")] = value.strip().strip("'\"")
    return parsed


def _evidence_path(dataset_dir: Path, value: str) -> Path:
    path = (dataset_dir / value).resolve()
    try:
        path.relative_to(dataset_dir.resolve())
    except ValueError as exc:
        raise PipelineError(f"Evidence path escapes dataset/: {value}") from exc
    if not path.is_file():
        raise PipelineError(f"Manifest evidence file is missing: {value}")
    return path


def _manifest(dataset_dir: Path) -> list[dict[str, str]]:
    rows = read_csv(
        dataset_dir / "evidence_files.csv",
        ("file_id", "file_path", "origin", "captured_at"),
    )
    for row in rows:
        _evidence_path(dataset_dir, row["file_path"])
        if not row.get("file_id"):
            raise PipelineError("Evidence manifest contains an empty file_id")
    return rows


def load_activities(dataset_dir: Path) -> list[Activity]:
    rows = read_csv(
        dataset_dir / "system_activity.csv",
        ("activity_id", "event_time", "event_type", "source_system", "target_system",
         "resource_id", "reported_result", "details"),
    )
    activities: list[Activity] = []
    for row in rows:
        event_time = parse_time(row.get("event_time"))
        if event_time is None:
            continue
        activities.append(Activity(
            activity_id=row["activity_id"],
            event_time=event_time,
            event_type=row["event_type"].strip().upper(),
            source_system=row.get("source_system", "").strip(),
            target_system=row.get("target_system", "").strip(),
            resource_id=row.get("resource_id", "").strip(),
            details=row.get("details", ""),
            reported_result=row.get("reported_result", ""),
        ))
    return activities


def resource_targets(activities: list[Activity]) -> dict[str, set[str]]:
    targets: dict[str, set[str]] = defaultdict(set)
    for activity in activities:
        if activity.resource_id and activity.target_system:
            targets[activity.resource_id].add(activity.target_system)
    return targets


def _systems_for_replica(
    table_name: str,
    resource_id: str,
    category: str,
    explicit_system: str,
    targets: dict[str, set[str]],
) -> list[str]:
    if "replica" not in table_name.casefold():
        return [_system_for(category, resource_id, table_name, explicit_system)]
    candidates = sorted(
        system for system in targets.get(resource_id, set())
        if any(term in system.casefold() for term in ("replica", "replication", "cluster"))
    )
    if "failover" in table_name.casefold() and category == "USER_PROFILE":
        return [CATEGORY_SYSTEM[category]]
    if candidates:
        return candidates
    return [_system_for(category, resource_id, "", explicit_system)]


def _make_observation(
    fields: dict[str, Any],
    *,
    evidence_id: str,
    observed_at: datetime,
    source_path: str,
    category_hint: str = "",
    table_name: str = "",
    explicit_system: str = "",
    targets: dict[str, set[str]],
    snapshot: bool = True,
    event_type: str = "",
) -> list[Observation]:
    flattened = _flatten_record(fields)
    resource_id = _record_resource_id(fields)
    if not resource_id:
        return []
    category = _category_from_hints(
        resource_id, category_hint, table_name,
        str(fields.get("collection", "")), str(fields.get("record_type", "")),
    )
    if not category:
        return []
    system_ids = _systems_for_replica(
        table_name, resource_id, category,
        explicit_system or str(fields.get("system", fields.get("origin_system", ""))),
        targets,
    )
    record_time = _record_time(fields, observed_at)
    final_time = observed_at if snapshot else record_time
    if snapshot and record_time > observed_at:
        return []
    return [
        Observation(system, resource_id, category, evidence_id, final_time,
                    flattened, snapshot, source_path, event_type, table_name)
        for system in system_ids if system
    ]


def _table_coverage(
    table_name: str,
    category: str,
    evidence_id: str,
    captured_at: datetime,
    targets: dict[str, set[str]],
) -> list[Coverage]:
    replica = "replica" in table_name.casefold()
    system = _system_for(category, "", table_name)
    if not system:
        return []
    systems = {system}
    if replica and not ("failover" in table_name.casefold() and category == "USER_PROFILE"):
        linked = {
            target for values in targets.values() for target in values
            if any(term in target.casefold() for term in ("replica", "replication", "cluster"))
        }
        systems.update(linked)
    return [
        Coverage(value, category, evidence_id, captured_at, table_name, replica)
        for value in sorted(systems)
    ]


def _parse_sql_evidence(
    path: Path,
    file_id: str,
    captured_at: datetime,
    targets: dict[str, set[str]],
) -> tuple[list[Observation], list[Coverage]]:
    observations: list[Observation] = []
    coverages: list[Coverage] = []
    connection = sqlite3.connect(":memory:")
    try:
        connection.executescript(path.read_text(encoding="utf-8-sig"))
        table_names = [
            row[0] for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
        ]
        for table_name in table_names:
            category = TABLE_CATEGORY.get(table_name, "")
            columns = [row[1] for row in connection.execute(f'PRAGMA table_info("{table_name}")')]
            if table_name.startswith("customer_data_"):
                try:
                    collections = {
                        row[0] for row in connection.execute(
                            f'SELECT DISTINCT collection_name FROM "{table_name}"'
                        ) if row[0]
                    }
                except sqlite3.OperationalError:
                    collections = set()
                categories = {_category_from_hints("", value) for value in collections}
                categories.discard("")
                for found_category in sorted(categories):
                    coverages.extend(_table_coverage(
                        table_name, found_category, file_id, captured_at, targets
                    ))
            elif category:
                coverages.extend(_table_coverage(
                    table_name, category, file_id, captured_at, targets
                ))

            if not columns:
                continue
            query = f'SELECT * FROM "{table_name}"'
            for raw_row in connection.execute(query):
                fields = dict(zip(columns, raw_row))
                for key, value in list(fields.items()):
                    if isinstance(value, str) and value[:1] in {"{", "["}:
                        try:
                            fields[key] = json.loads(value)
                        except json.JSONDecodeError:
                            pass
                if table_name.startswith("customer_data_"):
                    category_hint = str(fields.get("collection_name", ""))
                else:
                    category_hint = category
                observations.extend(_make_observation(
                    fields,
                    evidence_id=file_id,
                    observed_at=captured_at,
                    source_path=path.as_posix(),
                    category_hint=category_hint,
                    table_name=table_name,
                    explicit_system=str(fields.get("origin_system", "")),
                    targets=targets,
                    snapshot=True,
                ))
    except sqlite3.Error as exc:
        raise PipelineError(f"Cannot parse SQLite evidence {path.name}: {exc}") from exc
    finally:
        connection.close()
    return observations, coverages


def _parse_json_evidence(
    path: Path,
    file_id: str,
    captured_at: datetime,
    origin: str,
    targets: dict[str, set[str]],
) -> tuple[list[Observation], list[Coverage]]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PipelineError(f"Cannot parse JSON evidence {path.name}") from exc
    observations: list[Observation] = []
    coverages: list[Coverage] = []
    for record in _json_records(value):
        collection = str(record.get("collection", ""))
        data_store = str(record.get("data_store", ""))
        category = _category_from_hints(
            _record_resource_id(record), collection, data_store,
            str(record.get("record_type", "")), origin,
        )
        observations.extend(_make_observation(
            record,
            evidence_id=file_id,
            observed_at=captured_at,
            source_path=path.as_posix(),
            category_hint=category,
            explicit_system=data_store or str(record.get("system", "")),
            targets=targets,
            snapshot=True,
        ))
    return observations, coverages


def _parse_log_line(line: str) -> dict[str, Any] | None:
    """Parse a structured log line into fields."""
    fields: dict[str, Any] = {"text": line}
    handover = re.match(
        r"^\s*(?:[-*]\s*)?(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)\s*\|\s*"
        r"([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*"
        r"([^|]+?)\s*\|\s*(.*?)\s*$",
        line,
    )
    if handover:
        timestamp, service, resource_id, category, status, subject = (
            part.strip() for part in handover.groups()
        )
        fields.update({
            "event_time": timestamp,
            "service": service,
            "resource_id": resource_id,
            "category": category.upper(),
            "status": status.upper(),
        })
        if EMAIL_PATTERN.fullmatch(subject):
            fields["email"] = subject
        elif re.fullmatch(r"user_[A-Za-z0-9_-]+", subject, re.IGNORECASE):
            fields["subject_reference"] = subject
        if status.upper() in {"FOUND", "IDENTIFIABLE"}:
            fields["rows"] = 1
        elif status.upper() in {"NOT_FOUND", "NOT FOUND", "ABSENT"}:
            fields["status_code"] = 404
            fields["rows"] = 0
        elif status.upper() == "ACTIVE":
            fields["enabled"] = True
            fields["restore_allowed"] = True
        elif status.upper() in {"DISABLED", "STOPPED"}:
            fields["enabled"] = False
        elif status.upper() == "BLOCKED":
            fields["restore_allowed"] = False
        return fields
    # Extract timestamp from the beginning of the line
    ts_match = re.match(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)", line)
    if ts_match:
        fields["event_time"] = ts_match.group(1)
        payload = line[ts_match.end():].strip()
        if payload.startswith("{"):
            try:
                record = json.loads(payload)
            except json.JSONDecodeError:
                record = None
            if isinstance(record, dict):
                fields.update({str(key).casefold(): value for key, value in record.items()})
                fields["event_time"] = ts_match.group(1)
                for status_key in ("status_code", "http_status"):
                    try:
                        fields[status_key] = int(fields[status_key])
                    except (KeyError, TypeError, ValueError):
                        pass
                for count_key in ("rows", "total", "count", "hits"):
                    try:
                        fields[count_key] = int(fields[count_key])
                    except (KeyError, TypeError, ValueError):
                        pass
                result = str(fields.get("result", "")).strip().casefold()
                if result in {"hit", "found", "identifiable", "present"}:
                    fields.setdefault("rows", 1)
                elif result in {"miss", "not_found", "absent", "deleted"}:
                    fields.setdefault("rows", 0)
                if result in {"active", "enabled", "live"}:
                    fields.setdefault("enabled", True)
                    fields.setdefault("restore_allowed", True)
                elif result in {"disabled", "stopped", "blocked"}:
                    fields.setdefault("enabled", False)
                    if result == "blocked":
                        fields.setdefault("restore_allowed", False)
                for key in (
                    "matched_value", "match_key", "lookup_key", "scan_key",
                    "correlation_key", "subject_key",
                ):
                    value = str(fields.get(key, ""))
                    if value and EMAIL_PATTERN.fullmatch(value):
                        fields.setdefault("email", value)
                    elif value and PHONE_PATTERN.fullmatch(value):
                        fields.setdefault("phone", value)
                if "email" not in fields:
                    email_match = EMAIL_PATTERN.search(line)
                    if email_match:
                        fields["email"] = email_match.group(0)
                return fields
        syslog_header = re.match(
            r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\s+<\d+>\d+\s+\S+\s+"
            r"([A-Za-z][A-Za-z0-9_-]*)\s+(tr-[A-Za-z0-9_-]+)\s+-\s+-\s+",
            line,
        )
        if syslog_header:
            fields["service"] = syslog_header.group(1)
            fields["trace_id"] = syslog_header.group(2)
    # Parse quoted fields with escaped quote/backslash support. Some exporters
    # place a second key/value record inside the quoted `message` field.
    pair_pattern = re.compile(
        r'''(\w+)\s*=\s*(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|(\S+))'''
    )

    def parse_pairs(source: str) -> dict[str, str]:
        pairs: dict[str, str] = {}
        for match in pair_pattern.finditer(source):
            key = match.group(1)
            raw = next((group for group in match.groups()[1:] if group is not None), "")
            if match.group(2) is not None:
                try:
                    value = json.loads('"' + raw + '"')
                except json.JSONDecodeError:
                    value = raw.replace('\\"', '"').replace('\\\\', '\\')
            elif match.group(3) is not None:
                value = raw.replace("\\'", "'").replace('\\\\', '\\')
            else:
                value = raw
            pairs[key] = value
        return pairs

    kv_pairs = parse_pairs(line)
    nested_message = kv_pairs.get("message", "")
    for key, value in parse_pairs(nested_message).items():
        kv_pairs.setdefault(key, value)
    request_id = str(kv_pairs.get("requestId", ""))
    if request_id.startswith("tr-"):
        kv_pairs.setdefault("trace_id", request_id)
    # Parse numeric values
    for key, value in kv_pairs.items():
        if value.isdigit() or (value.startswith('-') and value[1:].isdigit()):
            kv_pairs[key] = int(value)
    fields.update(kv_pairs)
    # Extract resource_id from explicit resource_id= field first
    if "resource_id" in kv_pairs:
        fields["resource_id"] = kv_pairs["resource_id"]
    # Extract service
    if "service" in kv_pairs:
        fields["service"] = kv_pairs["service"]
    # Extract event
    if "event" in kv_pairs:
        fields["event"] = kv_pairs["event"]
    # Extract lookup_key
    if "lookup_key" in kv_pairs:
        fields["lookup_key"] = kv_pairs["lookup_key"]
    # Extract status_code / http_status
    for status_key in ("status_code", "http_status"):
        if status_key in kv_pairs:
            try:
                fields[status_key] = int(kv_pairs[status_key])
            except (ValueError, TypeError):
                pass
    result = str(kv_pairs.get("result", "")).strip().casefold()
    if result in {"hit", "found", "identifiable", "present"}:
        fields.setdefault("rows", 1)
    elif result in {"miss", "not_found", "absent", "deleted"}:
        fields.setdefault("rows", 0)
    if result in {"active", "enabled", "live"}:
        fields.setdefault("enabled", True)
        fields.setdefault("restore_allowed", True)
    elif result in {"disabled", "stopped", "blocked"}:
        fields.setdefault("enabled", False)
        if result == "blocked":
            fields.setdefault("restore_allowed", False)
    # Extract customer_reference / subject_reference
    for ref_key in ("customer_reference", "subject_reference", "subject_ref", "user_reference", "subject_selector", "subject_id", "customer_id", "account_id"):
        if ref_key in kv_pairs:
            fields[ref_key] = kv_pairs[ref_key]
    # Extract email (from explicit email= or pattern)
    if "email" in kv_pairs:
        fields["email"] = kv_pairs["email"]
    else:
        email_match = EMAIL_PATTERN.search(line)
        if email_match:
            fields["email"] = email_match.group(0)
    if "subject_key" in kv_pairs and EMAIL_PATTERN.fullmatch(kv_pairs["subject_key"]):
        fields["email"] = kv_pairs["subject_key"]
    for key in ("matched_value", "lookup_key", "scan_key", "correlation_key", "subject_key"):
        value = str(kv_pairs.get(key, ""))
        if value and EMAIL_PATTERN.fullmatch(value):
            fields.setdefault("email", value)
        elif value and PHONE_PATTERN.fullmatch(value):
            fields.setdefault("phone", value)
    # Extract phone
    if "phone" in kv_pairs:
        fields["phone"] = kv_pairs["phone"]
    else:
        phone_match = PHONE_PATTERN.search(line)
        if phone_match:
            candidate = phone_match.group(0)
            # Avoid matching trace_id-like patterns
            if not re.match(r"^\d{6}-\d{3}$", candidate):
                fields["phone"] = candidate
    return fields


def _text_observations(
    text: str,
    file_id: str,
    observed_at: datetime,
    source_path: str,
    origin: str,
    targets: dict[str, set[str]],
    *,
    event_type: str = "",
    document_scope: bool = False,
    document_resource_aliases: dict[str, list[str]] | None = None,
) -> list[Observation]:
    result: list[Observation] = []
    parsed_lines: list[tuple[str, dict[str, Any]]] = []
    trace_subjects: dict[str, dict[str, Any]] = {}
    document_subjects: dict[str, set[str]] = {"email": set(), "phone": set()}
    document_resources: set[str] = set()
    for line in text.splitlines():
        if not line.strip():
            continue
        parsed = _parse_log_line(line)
        if not parsed:
            continue
        parsed_lines.append((line, parsed))
        if parsed.get("resource_id"):
            document_resources.add(str(parsed["resource_id"]))
        elif document_scope:
            match = RESOURCE_PATTERN.search(line)
            if match:
                document_resources.add(match.group(0))
        if parsed.get("email"):
            document_subjects["email"].add(str(parsed["email"]))
        if parsed.get("phone"):
            document_subjects["phone"].add(str(parsed["phone"]))
        trace_id = str(parsed.get("trace_id", ""))
        if trace_id and any(key in parsed for key in (
            "email", "phone", "subject_reference", "subject_ref", "subject_id",
            "customer_reference", "subject_selector",
        )):
            trace_subjects[trace_id] = {
                ("trace_subject_email" if key == "email" else
                 "trace_subject_phone" if key == "phone" else key): parsed[key]
                for key in (
                    "email", "phone", "subject_reference", "subject_ref", "subject_id",
                    "customer_reference", "subject_selector",
                )
                if key in parsed
            }

    if document_scope and document_resource_aliases:
        text_folded = text.casefold()
        matched_aliases = [
            (alias, resource_ids)
            for alias, resource_ids in document_resource_aliases.items()
            if re.search(
                r"(?<![A-Za-z0-9])" + re.escape(alias) + r"(?![A-Za-z0-9])",
                text_folded,
            )
        ]
        unique_refs = {
            resource_id
            for _alias, resource_ids in matched_aliases
            if len(resource_ids) == 1
            for resource_id in resource_ids
        }
        if len(unique_refs) == 1:
            resource_id = next(iter(unique_refs))
            for line, parsed in parsed_lines:
                if any(
                    len(resource_ids) == 1 and resource_ids[0] == resource_id
                    and re.search(
                        r"(?<![A-Za-z0-9])" + re.escape(alias) + r"(?![A-Za-z0-9])",
                        line.casefold(),
                    )
                    for alias, resource_ids in matched_aliases
                ):
                    parsed["resource_id"] = resource_id
                    document_resources.add(resource_id)

    for line, parsed in parsed_lines:
        resource_id = parsed.get("resource_id", "")
        if not resource_id and document_scope:
            match = RESOURCE_PATTERN.search(line)
            if match:
                resource_id = match.group(0)
                parsed["resource_id"] = resource_id
        if not resource_id:
            continue
        category = _category_from_hints(
            resource_id, parsed.get("category", ""), source_path, origin
        )
        if not category:
            continue
        trace_id = str(parsed.get("trace_id", ""))
        if trace_id in trace_subjects:
            parsed = {**trace_subjects[trace_id], **parsed}
        if document_scope and len(document_resources) == 1:
            if len(document_subjects["email"]) == 1:
                parsed.setdefault("document_subject_email", next(iter(document_subjects["email"])))
            if len(document_subjects["phone"]) == 1:
                parsed.setdefault("document_subject_phone", next(iter(document_subjects["phone"])))
        # A timestamp inside the file cannot make evidence available before capture.
        line_time = parse_time(parsed.get("event_time"))
        effective_time = max(observed_at, line_time) if line_time is not None else observed_at
        explicit_system = parsed.get("service", "")
        if not explicit_system and origin in set(CATEGORY_SYSTEM.values()):
            explicit_system = origin
        result.extend(_make_observation(
            parsed,
            evidence_id=file_id,
            observed_at=effective_time,
            source_path=source_path,
            category_hint=category,
            explicit_system=explicit_system,
            targets=targets,
            snapshot=True,
            event_type=parsed.get("event", event_type),
        ))
    return result


def _ollama_vision_text(path: Path, model: str) -> tuple[str, int, int, bool]:
    image_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    prompt_version = "screenshot-transcription-v1"
    cache_path = Path(os.environ.get(
        "GHOSTDATA_VLM_CACHE",
        str(Path(tempfile.gettempdir()) / "ghost-data-still-exists-vlm.sqlite3"),
    ))
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(cache_path)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS vlm_cache "
        "(cache_key TEXT PRIMARY KEY, response TEXT NOT NULL, input_tokens INTEGER, "
        "output_tokens INTEGER)"
    )
    cache_key = hashlib.sha256(
        f"{model}:{prompt_version}:{image_hash}".encode("utf-8")
    ).hexdigest()
    cached = connection.execute(
        "SELECT response,input_tokens,output_tokens FROM vlm_cache WHERE cache_key=?",
        (cache_key,),
    ).fetchone()
    if cached:
        connection.close()
        return str(cached[0]), int(cached[1] or 0), int(cached[2] or 0), True

    image_base64 = base64.b64encode(path.read_bytes()).decode("ascii")
    payload = json.dumps({
        "model": model,
        "stream": False,
        "prompt": (
            "Transcribe the visible business record fields and values faithfully. "
            "Return concise plain text. Do not infer deletion status or recommend actions."
        ),
        "images": [image_base64],
        "options": {"temperature": 0},
    }).encode("utf-8")
    endpoint = os.environ.get("GHOSTDATA_VLM_URL", "http://127.0.0.1:11434/api/generate")
    request = urllib.request.Request(
        endpoint, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            body = json.loads(response.read().decode("utf-8"))
    except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
        connection.close()
        raise PipelineError(
            "Optional local VLM call failed; unset GHOSTDATA_VLM_MODEL to skip images"
        ) from exc
    result = str(body.get("response", ""))
    input_tokens = int(body.get("prompt_eval_count", 0) or 0)
    output_tokens = int(body.get("eval_count", 0) or 0)
    connection.execute(
        "INSERT OR REPLACE INTO vlm_cache VALUES (?,?,?,?)",
        (cache_key, result, input_tokens, output_tokens),
    )
    connection.commit()
    connection.close()
    return result, input_tokens, output_tokens, False


def _cached_local_text(
    path: Path,
    engine: str,
    extract: Any,
    cache_stats: dict[str, int] | None = None,
) -> str:
    """Run a local text/OCR extractor once per file content and engine version."""
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    cache_path = Path(os.environ.get(
        "GHOSTDATA_LOCAL_TEXT_CACHE",
        str(Path(tempfile.gettempdir()) / "ghost-data-still-exists-text.sqlite3"),
    ))
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(cache_path)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS local_text_cache "
        "(cache_key TEXT PRIMARY KEY, response TEXT NOT NULL)"
    )
    cache_key = hashlib.sha256(f"{engine}:{digest}".encode("utf-8")).hexdigest()
    row = connection.execute(
        "SELECT response FROM local_text_cache WHERE cache_key=?", (cache_key,)
    ).fetchone()
    if row is not None:
        if cache_stats is not None:
            cache_stats["hits"] += 1
        connection.close()
        return str(row[0])
    if cache_stats is not None:
        cache_stats["misses"] += 1
    try:
        text = str(extract())
    except Exception:
        connection.close()
        raise
    connection.execute(
        "INSERT OR REPLACE INTO local_text_cache VALUES (?,?)", (cache_key, text)
    )
    connection.commit()
    connection.close()
    return text


def _tesseract_executable() -> str | None:
    executable = shutil.which("tesseract")
    if executable:
        return executable
    if os.name == "nt":
        install_path = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) \
            / "Tesseract-OCR" / "tesseract.exe"
        if install_path.is_file():
            return str(install_path)
    return None


def _local_pdf_text(path: Path) -> str:
    pdftotext = shutil.which("pdftotext")
    if pdftotext:
        try:
            result = subprocess.run(
                [pdftotext, "-layout", str(path), "-"],
                check=True, capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=60,
            )
            if result.stdout.strip():
                return result.stdout
        except (OSError, subprocess.SubprocessError):
            pass
    text = ""
    if PdfReader is not None:
        reader = PdfReader(str(path))
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
    if text.strip():
        return text
    pdftoppm = shutil.which("pdftoppm")
    tesseract = _tesseract_executable()
    if not pdftoppm or not tesseract:
        return text
    with tempfile.TemporaryDirectory(prefix="ghostdata-pdf-ocr-") as temporary:
        prefix = str(Path(temporary) / "page")
        try:
            subprocess.run(
                [pdftoppm, "-png", "-r", "200", str(path), prefix],
                check=True, capture_output=True, timeout=120,
            )
            pages = sorted(Path(temporary).glob("page-*.png"))
            transcripts = []
            for page in pages:
                result = subprocess.run(
                    [tesseract, str(page), "stdout"], check=True, capture_output=True,
                    text=True, encoding="utf-8", errors="replace", timeout=90,
                )
                transcripts.append(result.stdout)
            return "\n".join(transcripts)
        except (OSError, subprocess.SubprocessError):
            return ""


def _local_ocr_text(path: Path) -> str:
    tesseract = _tesseract_executable()
    if not tesseract:
        return ""
    try:
        result = subprocess.run(
            [tesseract, str(path), "stdout"], check=True, capture_output=True,
            text=True, encoding="utf-8", errors="replace", timeout=90,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return result.stdout


def _local_ocr_tsv(path: Path) -> str:
    tesseract = _tesseract_executable()
    if not tesseract:
        return ""
    try:
        result = subprocess.run(
            [tesseract, str(path), "stdout", "--psm", "11", "tsv"],
            check=True, capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=90,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return result.stdout


def _default_image_text_extractor() -> ImageTextExtractor | None:
    executable = _tesseract_executable()
    if not executable:
        return None
    return ImageTextExtractor(
        name="tesseract-tsv-v1",
        extract_tsv=_local_ocr_tsv,
        cache_key=executable,
    )


def _ocr_tsv_lines(tsv: str) -> list[list[dict[str, Any]]]:
    try:
        words = [
            {
                "left": int(row["left"]),
                "top": int(row["top"]),
                "height": int(row["height"]),
                "text": row["text"].strip(),
            }
            for row in csv.DictReader(tsv.splitlines(), delimiter="\t")
            if row.get("text", "").strip() and float(row.get("conf", "-1")) >= 0
        ]
    except (KeyError, TypeError, ValueError):
        return []
    rows: list[list[dict[str, Any]]] = []
    for word in sorted(words, key=lambda item: (item["top"], item["left"])):
        row = next(
            (candidate for candidate in reversed(rows)
             if abs(candidate[0]["top"] - word["top"]) <= max(8, word["height"])),
            None,
        )
        if row is None:
            rows.append([word])
        else:
            row.append(word)
    return rows


def _ocr_detail_panel_observations(
    tsv: str,
    *,
    image_width: int,
    file_id: str,
    observed_at: datetime,
    source_path: str,
    targets: dict[str, set[str]],
) -> list[Observation]:
    if not tsv or image_width <= 0:
        return []
    try:
        words = [
            {
                "left": int(row["left"]),
                "top": int(row["top"]),
                "height": int(row["height"]),
                "confidence": float(row["conf"]),
                "text": row["text"].strip(),
            }
            for row in csv.DictReader(tsv.splitlines(), delimiter="\t")
            if row.get("text", "").strip() and float(row.get("conf", "-1")) >= 35
        ]
    except (KeyError, TypeError, ValueError):
        return []

    panel_words = [word for word in words if word["left"] >= image_width * 0.7]
    panel_candidates = {
        resource_id
        for resource_id in targets
        if any(
            re.sub(r"[^a-z0-9]", "", word["text"].casefold())
            == re.sub(r"[^a-z0-9]", "", resource_id.casefold())
            for word in panel_words
        )
    }
    all_rows: list[list[dict[str, Any]]] = []
    for word in sorted(words, key=lambda item: (item["top"], item["left"])):
        row = next(
            (candidate for candidate in reversed(all_rows)
             if abs(candidate[0]["top"] - word["top"]) <= max(8, word["height"])),
            None,
        )
        if row is None:
            all_rows.append([word])
        else:
            row.append(word)

    panel_rows: list[list[dict[str, Any]]] = []
    for word in sorted(panel_words, key=lambda item: (item["top"], item["left"])):
        row = next(
            (candidate for candidate in reversed(panel_rows)
             if abs(candidate[0]["top"] - word["top"]) <= max(8, word["height"])),
            None,
        )
        if row is None:
            panel_rows.append([word])
        else:
            row.append(word)

    linked_row: list[dict[str, Any]] = []
    if len(panel_candidates) == 1:
        candidates = panel_candidates
        rows = panel_rows
    elif not panel_candidates:
        resource_email_rows = []
        for row in all_rows:
            row_text = " ".join(word["text"] for word in row)
            row_candidates = {
                resource_id for resource_id in targets
                if any(
                    re.sub(r"[^a-z0-9]", "", word["text"].casefold())
                    == re.sub(r"[^a-z0-9]", "", resource_id.casefold())
                    for word in row
                )
            }
            email = EMAIL_PATTERN.search(row_text)
            if len(row_candidates) == 1 and email:
                resource_email_rows.append((next(iter(row_candidates)), row, email.group(0)))
        resource_ids = {resource_id for resource_id, _row, _email in resource_email_rows}
        if len(resource_ids) == 1 and resource_email_rows:
            candidates = resource_ids
            linked_row = resource_email_rows[0][1]
            rows = [row for row in all_rows if row is linked_row]
        else:
            global_candidates = {
                resource_id
                for resource_id in targets
                if any(
                    re.sub(r"[^a-z0-9]", "", word["text"].casefold())
                    == re.sub(r"[^a-z0-9]", "", resource_id.casefold())
                    for word in words
                )
            }
            global_emails = {
                match.group(0)
                for word in words
                for match in [EMAIL_PATTERN.search(word["text"])]
                if match
            }
            labels_present = {
                re.sub(r"[^a-z]", "", word["text"].casefold()) for word in words
            }
            if (len(global_candidates) != 1 or len(global_emails) != 1
                    or not labels_present.intersection({"email", "customer", "owner", "account"})):
                return []
            candidates = global_candidates
            screen_email = next(iter(global_emails))
            linked_row = [{"left": 0, "top": 0, "height": 0, "text": screen_email}]
            rows = []
    else:
        return []

    labels: dict[str, str] = {}
    for row in rows:
        ordered = sorted(row, key=lambda item: item["left"])
        for index, word in enumerate(ordered[:-1]):
            label = re.sub(r"[^a-z]", "", word["text"].casefold())
            if label in {"sync", "download"} and index + 1 < len(ordered) - 1:
                next_label = re.sub(r"[^a-z]", "", ordered[index + 1]["text"].casefold())
                compound = {("sync", "mode"): "syncmode", ("download", "count"): "downloadcount"}
                if (label, next_label) in compound:
                    labels[compound[(label, next_label)]] = " ".join(
                        item["text"].strip() for item in ordered[index + 2:]
                    )
            if label in {
                "status", "state", "syncmode", "restoreallowed", "restoreaccess",
                "selector", "expires", "expiration", "downloadcount",
            }:
                labels[label] = " ".join(
                    item["text"].strip() for item in ordered[index + 1:]
                )

    fields: dict[str, Any] = {"resource_id": next(iter(candidates))}
    for word in (panel_words if panel_candidates else linked_row):
        email = EMAIL_PATTERN.search(word["text"])
        if email:
            fields["email"] = email.group(0)
            break
    expires_text = labels.get("expires", labels.get("expiration", ""))
    for date_format in (
        "%d %b %Y %H:%M UTC", "%d %b %Y", "%b %d %Y %H:%M UTC", "%b %d %Y",
    ):
        try:
            fields["expires_at"] = datetime.strptime(expires_text, date_format).replace(
                tzinfo=timezone.utc
            ).isoformat()
            break
        except ValueError:
            continue
    download_count = re.search(r"\b\d+\b", labels.get("downloadcount", ""))
    if download_count:
        fields["download_available"] = int(download_count.group(0)) > 0

    category = _category_from_hints(fields["resource_id"])
    if category == "DATA_FLOW":
        status = labels.get("status", labels.get("state", "")).casefold()
        mode = labels.get("syncmode", "").casefold()
        if status in {"healthy", "active", "running", "enabled", "online"}:
            fields["active"] = True
        elif status in {"disabled", "inactive", "stopped", "paused", "offline"}:
            fields["active"] = False
        elif "continuous" in mode:
            fields["active"] = True
    elif category == "BACKUP_ARCHIVE":
        access = labels.get("restoreallowed", labels.get("restoreaccess", "")).casefold()
        if access in {"allowed", "enabled", "yes", "true", "open"}:
            fields["restore_allowed"] = True
        elif access in {"blocked", "disabled", "no", "false", "closed"}:
            fields["restore_allowed"] = False

    if not any(key in fields for key in ("active", "restore_allowed", "email")):
        return []
    return _make_observation(
        fields,
        evidence_id=file_id,
        observed_at=observed_at,
        source_path=source_path,
        category_hint=category,
        targets=targets,
        snapshot=True,
        event_type="SCREENSHOT_DETAIL_PANEL",
    )


def _document_resource_aliases(activities: list[Activity]) -> dict[str, list[str]]:
    """Extract explicit external-reference links from identity-catalog activity."""
    aliases: dict[str, set[str]] = defaultdict(set)
    pattern = re.compile(
        r"\b((?:account|analytics|audit|backup|cache|data|email|export|legal|"
        r"marketing|object|search|support|tombstone)_[A-Za-z0-9][A-Za-z0-9_-]*)"
        r"\s+\(([^)]+)\)"
    )
    for activity in activities:
        if activity.event_type != "LINK_RESOURCE_IDENTITY":
            continue
        for resource_id, external_ref in pattern.findall(activity.details):
            aliases[external_ref.strip().casefold()].add(resource_id)
    return {alias: sorted(resource_ids) for alias, resource_ids in aliases.items()}


def load_evidence(
    dataset_dir: Path,
    activities: list[Activity],
    enable_vlm_model: str = "",
    *,
    image_text_extractor: ImageTextExtractor | None = None,
    image_extraction_report: dict[str, Any] | None = None,
) -> tuple[list[Observation], list[Coverage], dict[str, int]]:
    manifest = _manifest(dataset_dir)
    targets = resource_targets(activities)
    document_aliases = _document_resource_aliases(activities)
    observations: list[Observation] = []
    coverages: list[Coverage] = []
    usage = {"calls": 0, "cache_hits": 0, "input_tokens": 0, "output_tokens": 0}
    image_text_extractor = image_text_extractor or _default_image_text_extractor()
    image_extractors_used: set[str] = set()
    image_cache_stats = {"hits": 0, "misses": 0}
    image_evidence_count = 0
    extracted_image_text_ids: set[str] = set()
    skipped_image_text_ids: set[str] = set()
    skipped_image_reasons: dict[str, str] = {}

    for item in manifest:
        path = _evidence_path(dataset_dir, item["file_path"])
        is_image = path.suffix.casefold() in {".png", ".jpg", ".jpeg", ".webp"}
        if is_image:
            image_evidence_count += 1
        captured_at = parse_time(item.get("captured_at"))
        if captured_at is None:
            if is_image:
                skipped_image_text_ids.add(item["file_id"])
                skipped_image_reasons[item["file_id"]] = "missing_capture_time"
            continue
        suffix = path.suffix.casefold()
        if suffix == ".sql":
            found, covered = _parse_sql_evidence(
                path, item["file_id"], captured_at, targets
            )
            observations.extend(found)
            coverages.extend(covered)
        elif suffix == ".json":
            found, covered = _parse_json_evidence(
                path, item["file_id"], captured_at, item.get("origin", ""), targets
            )
            observations.extend(found)
            coverages.extend(covered)
        elif suffix in {".log", ".txt"}:
            try:
                text = path.read_text(encoding="utf-8-sig", errors="replace")
            except OSError as exc:
                raise PipelineError(f"Cannot read text evidence {path.name}") from exc
            observations.extend(_text_observations(
                text, item["file_id"], captured_at, path.as_posix(),
                item.get("origin", ""), targets,
            ))
        elif suffix == ".pdf":
            try:
                text = _cached_local_text(
                    path, "pdf:" + ":".join((
                        shutil.which("pdftotext") or "pypdf",
                        shutil.which("pdftoppm") or "no-pdftoppm",
                        _tesseract_executable() or "no-tesseract",
                    )),
                    lambda: _local_pdf_text(path),
                )
            except Exception as exc:
                raise PipelineError(f"Cannot extract PDF evidence {path.name}") from exc
            observations.extend(_text_observations(
                text, item["file_id"], captured_at, path.as_posix(),
                item.get("origin", ""), targets, document_scope=True,
                document_resource_aliases=document_aliases,
            ))
        elif suffix in {".png", ".jpg", ".jpeg", ".webp"}:
            tsv = ""
            if image_text_extractor:
                image_extractors_used.add(image_text_extractor.name)
                tsv = _cached_local_text(
                    path,
                    f"image-tsv:{image_text_extractor.name}:{image_text_extractor.cache_key}",
                    lambda: image_text_extractor.extract_tsv(path),
                    image_cache_stats,
                )
            if tsv.strip():
                extracted_image_text_ids.add(item["file_id"])
                try:
                    from PIL import Image
                    with Image.open(path) as image:
                        image_width = image.width
                except (ImportError, OSError):
                    image_width = 0
                observations.extend(_ocr_detail_panel_observations(
                    tsv,
                    image_width=image_width,
                    file_id=item["file_id"],
                    observed_at=captured_at,
                    source_path=path.as_posix(),
                    targets=targets,
                ))
                text = "\n".join(
                    " ".join(word["text"].strip() for word in sorted(
                        group, key=lambda word: int(word["left"])
                    ))
                    for group in _ocr_tsv_lines(tsv)
                )
                observations.extend(_text_observations(
                    text, item["file_id"], captured_at, path.as_posix(),
                    item.get("origin", ""), targets,
                ))
                continue

            if not enable_vlm_model:
                skipped_image_text_ids.add(item["file_id"])
                skipped_image_reasons[item["file_id"]] = (
                    "no_extractor" if image_text_extractor is None else "empty_ocr_result"
                )
                continue
            image_extractors_used.add("ollama-vlm:" + enable_vlm_model)
            text, input_tokens, output_tokens, cached = _ollama_vision_text(path, enable_vlm_model)
            usage["calls"] += int(not cached)
            usage["cache_hits"] += int(cached)
            usage["input_tokens"] += input_tokens
            usage["output_tokens"] += output_tokens
            if not text.strip():
                skipped_image_text_ids.add(item["file_id"])
                skipped_image_reasons[item["file_id"]] = "empty_extraction_result"
                continue
            extracted_image_text_ids.add(item["file_id"])
            observations.extend(_text_observations(
                text, item["file_id"], captured_at, path.as_posix(),
                item.get("origin", ""), targets,
            ))
    if image_extraction_report is not None:
        image_extraction_report.clear()
        image_extraction_report.update({
            "image_evidence_count": image_evidence_count,
            "local_ocr_available": image_text_extractor is not None,
            "vlm_available": bool(enable_vlm_model),
            "cache": dict(image_cache_stats),
            "extractors": sorted(image_extractors_used),
            "text_extracted_evidence_ids": sorted(extracted_image_text_ids),
            "skipped_evidence_ids": sorted(skipped_image_text_ids),
            "skipped_reasons": dict(sorted(skipped_image_reasons.items())),
        })
    return observations, coverages, usage


def _normalize_scalar(value: Any) -> str:
    s = unicodedata.normalize("NFKC", str(value or "")).strip().casefold()
    if s in {"null", "none", "n/a", "na", "nil"}:
        return ""
    return s


def _text_matches_identity(text: str, identity: Identity) -> bool:
    source = unicodedata.normalize("NFKC", text or "")
    emails = {_normalize_scalar(value) for value in EMAIL_PATTERN.findall(source)}
    hashes = {_normalize_scalar(value) for value in HASH_PATTERN.findall(source)}
    phones = {normalize_phone(value) for value in PHONE_PATTERN.findall(source)}
    if emails & {_normalize_scalar(value) for value in identity.fields.get("email", set())}:
        return True
    if hashes & {_normalize_scalar(value) for value in identity.fields.get("email_hash", set())}:
        return True
    if phones & {
        normalize_phone(value) for value in identity.fields.get("phone", set())
        if len(normalize_phone(value)) >= 7
    }:
        return True
    return False


def _observation_matches(observation: Observation, identity: Identity) -> bool:
    for key, value in _walk_values(observation.fields):
        leaf = key.split(".")[-1]
        normalized = _normalize_scalar(value)
        if leaf in {
            "matched_value", "match_key", "lookup_key", "scan_key", "correlation_key", "subject_key",
        }:
            if normalized == _normalize_scalar(identity.user_id):
                return True
            if normalized in {
                _normalize_scalar(v)
                for field_name in ("email", "email_hash")
                for v in identity.fields.get(field_name, set())
            }:
                return True
            if normalize_phone(value) and normalize_phone(value) in {
                normalize_phone(v) for v in identity.fields.get("phone", set())
            }:
                return True
        if leaf in IDENTITY_REFERENCE_FIELDS or leaf == "lookup_key":
            if normalized == _normalize_scalar(identity.user_id):
                return True
        if leaf in {
            "email", "owner_email", "requester_email", "customer_email", "lookup_key",
            "trace_subject_email", "document_subject_email",
        }:
            if normalized in {_normalize_scalar(v) for v in identity.fields.get("email", set())}:
                return True
        if leaf in {
            "phone", "customer_phone", "requester_phone", "owner_phone",
            "trace_subject_phone", "document_subject_phone",
        }:
            if normalize_phone(value) in {
                normalize_phone(v) for v in identity.fields.get("phone", set())
            } and normalize_phone(value):
                return True
        if leaf in {"email_hash", "hash"}:
            if normalized in {_normalize_scalar(v) for v in identity.fields.get("email_hash", set())}:
                return True
        if leaf in {"name", "full_name", "customer_name", "requester_name", "owner_name"}:
            if normalized and normalized in {
                _normalize_scalar(value) for value in identity.fields.get("name", set())
            }:
                return True
        if isinstance(value, str) and _text_matches_identity(value, identity):
            return True
    return False


def _activity_matches(activity: Activity, identity: Identity) -> bool:
    return (
        _text_matches_identity(activity.details, identity)
        or _subject_reference_present(_parse_details(activity.details), identity)
    )


def _direct_identifiers_present(observation: Observation, identity: Identity) -> bool:
    return _direct_identifiers_present_fields(observation.fields, identity)


def _direct_identifiers_present_fields(fields: dict[str, Any], identity: Identity) -> bool:
    alias_values = {
        field_name: {_normalize_scalar(value) for value in identity.fields.get(field_name, set())}
        for field_name in ("email", "phone", "email_hash", "name")
    }
    for key, value in _walk_values(fields):
        leaf = key.split(".")[-1]
        if leaf in {
            "trace_subject_email", "trace_subject_phone",
            "document_subject_email", "document_subject_phone",
        }:
            continue
        normalized = _normalize_scalar(value)
        if not normalized:
            continue
        if leaf in PII_FIELD_MARKERS or leaf.endswith(("_email", "_phone", "_name")):
            if leaf in {"email_hash", "hash"}:
                if normalized in alias_values["email_hash"]:
                    return True
            elif "phone" in leaf:
                if normalize_phone(value) in {normalize_phone(v) for v in identity.fields.get("phone", set())}:
                    return True
            elif "name" in leaf or "display_name" in leaf:
                if normalized in alias_values["name"]:
                    return True
            elif "email" in leaf and normalized in alias_values["email"]:
                return True
        if (
            leaf == "matched_value"
            and (
                normalized in alias_values["email"]
                or normalize_phone(value) in {
                    normalize_phone(alias)
                    for alias in identity.fields.get("phone", set())
                }
            )
            and any(
                _normalize_scalar(nested_value) == "direct_identifier"
                for nested_key, nested_value in _walk_values(fields)
                if nested_key.split(".")[-1] == "detector"
            )
        ):
            return True
        if leaf in {"text", "message_excerpt", "record_json"} and isinstance(value, str):
            if _text_matches_identity(value, identity):
                return True
    return False


def _subject_reference_present(fields: dict[str, Any], identity: Identity) -> bool:
    return any(
        (key.split(".")[-1] in IDENTITY_REFERENCE_FIELDS
         or key.split(".")[-1] == "lookup_key")
        and _normalize_scalar(value) == _normalize_scalar(identity.user_id)
        for key, value in _walk_values(fields)
    )


def _linked_activity_observations(
    activities: list[Activity], identity: Identity, cutoff: datetime
) -> list[Observation]:
    result: list[Observation] = []
    for activity in activities:
        if activity.event_time > cutoff or not _activity_matches(activity, identity):
            continue
        category = _category_from_hints(activity.resource_id)
        if activity.event_type == "CHECK_DATA_FLOW":
            category = "DATA_FLOW"
        elif activity.event_type == "CHECK_RESTORE_ACCESS":
            category = "BACKUP_ARCHIVE"
        elif activity.event_type in COPY_EVENT_TYPES:
            if activity.event_type == "SYNC_RECORD" and activity.resource_id.startswith("data_flow_"):
                category = "DATA_FLOW"
        if not category:
            continue
        if category == "DATA_FLOW":
            system = "integration_service"
        elif activity.event_type == "SYNC_RECORD" and activity.target_system:
            system = activity.target_system
        elif category == "USER_PROFILE" and "replica" in activity.target_system:
            system = activity.target_system
        else:
            system = _system_for(category, activity.resource_id)
        fields = _parse_details(activity.details)
        fields.update({
            "resource_id": activity.resource_id,
            "source_system": activity.source_system,
            "target_system": activity.target_system,
            "reported_result": activity.reported_result,
        })
        result.append(Observation(
            system_id=system,
            resource_id=activity.resource_id,
            category=category,
            evidence_id=activity.activity_id,
            observed_at=activity.event_time,
            fields=_flatten_record(fields),
            snapshot=False,
            source_path="dataset/system_activity.csv",
            event_type=activity.event_type,
        ))
    return result


def _bool_field(fields: dict[str, Any], names: set[str]) -> bool | None:
    for key, value in _walk_values(fields):
        if key.split(".")[-1] in names:
            parsed = _truthy(value)
            if parsed is not None:
                return parsed
    return None


def _event_operation_state(observation: Observation) -> bool | None:
    if observation.category == "DATA_FLOW":
        if observation.event_type == "CHECK_DATA_FLOW":
            return _bool_field(
                observation.fields, {"enabled", "active", "is_active", "flow_enabled"}
            )
    if observation.category == "BACKUP_ARCHIVE":
        if observation.event_type == "CHECK_RESTORE_ACCESS":
            return _bool_field(
                observation.fields, {"restore_allowed", "restore_access", "allowed"}
            )
    return None


def _policy_action(
    category: str,
    fields: dict[str, Any],
    rules: dict[str, str],
    identity: Identity | None = None,
) -> str:
    action = rules.get(category, "")
    if category == "SUPPORT_ATTACHMENT":
        shared = _bool_field(fields, {"shared", "shared_context", "belongs_only_to_subject"})
        if shared is True or _truthy(fields.get("belongs_only_to_subject")) is False:
            return "REDACT"
    if category == "SUPPORT_MESSAGE":
        # Subject-linked support conversations are retained under rule_05;
        # redact direct identifiers instead of deleting the conversation.
        if identity is not None and _direct_identifiers_present_fields(fields, identity):
            return "REDACT"
        keys = {key.split(".")[-1] for key in fields}
        if any(
            marker in key
            for key in keys
            for marker in ("agent", "order", "conversation", "shared", "other_customer")
        ):
            return "REDACT"
        text = " ".join(
            str(value) for key, value in fields.items()
            if key.split(".")[-1] in {"text", "message_excerpt", "record_json"}
        ).casefold()
        if re.search(r"\b(order|tracking|agent|another customer|other customer|shared context)\b", text):
            return "REDACT"
        if (
            identity is not None
            and _subject_reference_present(fields, identity)
            and not _direct_identifiers_present_fields(fields, identity)
        ):
            return "REDACT"
        return "DELETE"
    if category == "LEGAL_HOLD_RECORD":
        active = _bool_field(fields, {"active", "hold_active", "is_active"})
        return "RETAIN" if active is not False else "DELETE"
    if category == "SECURITY_AUDIT_LOG":
        retention = None
        for key, value in _walk_values(fields):
            if key.split(".")[-1] in {"retention_until", "retained_until"}:
                retention = parse_time(value)
                break
        return "RETAIN" if retention is not None else action
    if category == "BACKUP_ARCHIVE":
        return "RETAIN"
    return action


def _activity_treatment_for_resource(
    resource_id: str, activities: list[Activity], cutoff: datetime,
) -> str:
    """Return the latest explicit resource operation, if recorded by cutoff."""
    matching = [
        activity for activity in activities
        if activity.resource_id == resource_id
        and activity.event_type in ACTIVITY_TREATMENT
        and activity.event_time <= cutoff
    ]
    if not matching:
        return ""
    latest = max(matching, key=lambda activity: (activity.event_time, activity.activity_id))
    return ACTIVITY_TREATMENT[latest.event_type]


def _treatment_for_resource(
    observation: Observation,
    rules: dict[str, str],
    identity: Identity,
    activities: list[Activity],
    cutoff: datetime,
) -> str:
    policy_action = _policy_action(
        observation.category, observation.fields, rules, identity
    )
    if policy_action:
        return policy_action
    return _activity_treatment_for_resource(
        observation.resource_id, activities, cutoff
    )


def _is_violation(
    observation: Observation,
    action: str,
    identity: Identity,
    cutoff: datetime,
) -> tuple[bool, str]:
    if observation.category == "DATA_FLOW":
        state = _event_operation_state(observation)
        if state is None:
            state = _bool_field(observation.fields, {"enabled", "active", "is_active", "flow_enabled"})
        return state is True, "ACTIVE" if state is True else ("DISABLED" if state is False else "")
    if observation.category == "BACKUP_ARCHIVE":
        state = _bool_field(observation.fields, {"restore_allowed", "restore_access", "allowed"})
        if state is None:
            # deletion_block=false means restore is allowed (violation)
            # deletion_block=true means restore is blocked (no violation)
            deletion_block = _bool_field(observation.fields, {"deletion_block"})
            if deletion_block is not None:
                state = not deletion_block
        if state is None:
            state = _event_operation_state(observation)
        return state is True, "ACTIVE" if state is True else ("BLOCKED" if state is False else "")
    if not observation.snapshot and observation.event_type not in COPY_EVENT_TYPES:
        return False, ""
    if observation.event_type in COPY_EVENT_TYPES and not observation.snapshot:
        return action == "DELETE", "PRESENT"
    if action == "DELETE":
        if observation.category == "USER_EXPORT":
            expiration = None
            for key, value in _walk_values(observation.fields):
                if key.split(".")[-1] == "expires_at":
                    expiration = parse_time(value)
                    break
            downloadable = _bool_field(observation.fields, {"download_available", "is_downloadable"})
            if expiration is not None and expiration <= cutoff and downloadable is not True:
                return False, "ABSENT"
        # Check for explicit deletion/absence markers
        deleted = _bool_field(observation.fields, {"deleted", "is_deleted", "absent"})
        if deleted is True:
            return False, "ABSENT"
        # Check for HTTP 404 / status_code 404 indicating absence
        for key, value in _walk_values(observation.fields):
            leaf = key.split(".")[-1]
            if leaf in {"status_code", "http_status"} and isinstance(value, (int, str)):
                try:
                    if int(value) == 404:
                        return False, "ABSENT"
                except (ValueError, TypeError):
                    pass
        # Check for rows=0 or total=0 indicating absence
        for key, value in _walk_values(observation.fields):
            leaf = key.split(".")[-1]
            if leaf in {"rows", "total", "count", "hits"} and isinstance(value, (int, str)):
                try:
                    if int(value) == 0:
                        return False, "ABSENT"
                except (ValueError, TypeError):
                    pass
        return True, "PRESENT"
    if action == "RETAIN":
        return False, "PRESENT"
    if action == "ANONYMIZE":
        linked = any(
            key.split(".")[-1] in IDENTITY_REFERENCE_FIELDS
            and _normalize_scalar(value) == _normalize_scalar(identity.user_id)
            for key, value in _walk_values(observation.fields)
        )
        return linked or _direct_identifiers_present(observation, identity), "PRESENT"
    if action == "REDACT":
        return _direct_identifiers_present(observation, identity), "PRESENT"
    return False, ""


def _latest_observations(
    observations: list[Observation], cutoff: datetime
) -> dict[tuple[str, str, str], Observation]:
    latest: dict[tuple[str, str, str], Observation] = {}
    for observation in observations:
        if observation.observed_at > cutoff:
            continue
        key = (observation.system_id, observation.resource_id, observation.category)
        previous = latest.get(key)
        if previous is None or (observation.observed_at, observation.evidence_id) >= (
            previous.observed_at, previous.evidence_id
        ):
            latest[key] = observation
    return latest


def _latest_coverages(
    coverages: list[Coverage], cutoff: datetime
) -> dict[tuple[str, str, str], Coverage]:
    latest: dict[tuple[str, str, str], Coverage] = {}
    for coverage in coverages:
        if coverage.observed_at > cutoff:
            continue
        key = (coverage.system_id, coverage.category, coverage.source_path)
        previous = latest.get(key)
        if previous is None or (coverage.observed_at, coverage.evidence_id) > (
            previous.observed_at, previous.evidence_id
        ):
            latest[key] = coverage
    return latest


def _coverage_is_fresh(coverage: Coverage | None, cutoff: datetime) -> bool:
    if coverage is None or coverage.observed_at > cutoff:
        return False
    return cutoff - coverage.observed_at <= MAX_ABSENCE_COVERAGE_AGE


def _coverage_proves_resource_absence(
    coverage: Coverage | None,
    resource_id: str,
    activities: list[Activity],
    cutoff: datetime,
) -> bool:
    if not _coverage_is_fresh(coverage, cutoff) or coverage is None:
        return False
    return not any(
        activity.event_type == "LINK_RESOURCE_IDENTITY"
        and activity.resource_id == resource_id
        and coverage.observed_at < activity.event_time <= cutoff
        for activity in activities
    )


def _coverage_for(
    system_id: str,
    category: str,
    scope_id: str,
    latest_coverages: dict[tuple[str, str, str], Coverage],
) -> Coverage | None:
    normalized_system = system_id or CATEGORY_SYSTEM.get(category, "")
    if scope_id:
        return latest_coverages.get((normalized_system, category, scope_id))
    candidates = [
        coverage for (candidate_system, candidate_category, _scope), coverage
        in latest_coverages.items()
        if candidate_system == normalized_system and candidate_category == category
    ]
    return max(
        candidates,
        key=lambda coverage: (coverage.observed_at, coverage.evidence_id, coverage.source_path),
        default=None,
    )


def _reported_activity_assignments(
    cases: list[dict[str, str]], activities: list[Activity],
) -> dict[str, Activity]:
    """Link explicit resource operations only when the report/event pair is unique."""
    candidates: dict[str, list[tuple[int, Activity]]] = defaultdict(list)
    event_cases: dict[str, list[str]] = defaultdict(list)
    for case in cases:
        reported_at = parse_time(case.get("reported_at", ""))
        cutoff = parse_time(case.get("audit_at", ""))
        if reported_at is None or cutoff is None:
            continue
        for activity in activities:
            if activity.event_type not in ACTIVITY_TREATMENT or activity.event_time > cutoff:
                continue
            # Account delete events are case workflow resource links. For other
            # categories, only an explicit anonymization operation can establish
            # the otherwise unidentifiable, now-anonymous resource association.
            if (
                activity.target_system != "account_service"
                and activity.event_type != "ANONYMIZE_RECORD"
            ):
                continue
            delta = int(abs((activity.event_time - reported_at).total_seconds()))
            if delta <= 600:
                candidates[case["case_id"]].append((delta, activity))
                event_cases[activity.activity_id].append(case["case_id"])

    assignments: dict[str, Activity] = {}
    for case_id, matches in candidates.items():
        nearest_distance = min(distance for distance, _activity in matches)
        nearest = [activity for distance, activity in matches if distance == nearest_distance]
        if len(nearest) == 1 and event_cases[nearest[0].activity_id] == [case_id]:
            assignments[case_id] = nearest[0]
    return assignments


def _build_case_steps(
    case: dict[str, str],
    identity_rows: dict[str, dict[str, str]],
    audits: list[dict[str, str]],
    activities: list[Activity],
    observations: list[Observation],
    coverages: list[Coverage],
    rules: dict[str, str],
    trace_stats: dict[str, Any] | None = None,
    reported_activity: Activity | None = None,
) -> tuple[str, list[Step]]:
    if trace_stats is not None:
        trace_stats.update({
            "identity_resolved": 0,
            "activities_as_of_cutoff": 0,
            "activities_identity_matched": 0,
            "linked_activity_observations": 0,
            "evidence_as_of_cutoff": 0,
            "direct_evidence_matches": 0,
            "linked_resource_ids": 0,
            "coverage_as_of_cutoff": 0,
            "state_count": 0,
            "step_count": 0,
        })
    if not is_deletion_request(case.get("request_text", "")):
        return "NOT_APPLICABLE", []

    cutoff = parse_time(case.get("audit_at"))
    if cutoff is None:
        raise PipelineError(f"Request has invalid audit_at: {case.get('case_id', '')}")
    identity = resolve_identity(case.get("email", ""), cutoff, identity_rows, audits)
    if identity is None:
        return "INCOMPLETE", []
    if trace_stats is not None:
        trace_stats["identity_resolved"] = 1
        trace_stats["activities_as_of_cutoff"] = sum(
            activity.event_time <= cutoff for activity in activities
        )
        trace_stats["activities_identity_matched"] = sum(
            activity.event_time <= cutoff and _activity_matches(activity, identity)
            for activity in activities
        )

    linked = _linked_activity_observations(activities, identity, cutoff)
    directly_linked = [
        item for item in observations
        if item.observed_at <= cutoff and _observation_matches(item, identity)
    ]
    resource_ids = {item.resource_id for item in linked + directly_linked if item.resource_id}
    if reported_activity is not None and reported_activity.event_time <= cutoff:
        resource_ids.add(reported_activity.resource_id)
    if trace_stats is not None:
        trace_stats.update({
            "linked_activity_observations": len(linked),
            "evidence_as_of_cutoff": sum(item.observed_at <= cutoff for item in observations),
            "direct_evidence_matches": len(directly_linked),
            "linked_resource_ids": len(resource_ids),
            "coverage_as_of_cutoff": sum(item.observed_at <= cutoff for item in coverages),
        })

    related_observations = [
        item for item in observations + linked
        if item.observed_at <= cutoff
        and item.resource_id in resource_ids
        and item.event_type != "LINK_RESOURCE_IDENTITY"
    ]
    if reported_activity is not None and reported_activity.resource_id in resource_ids:
        category = _category_from_hints(reported_activity.resource_id)
        system = reported_activity.target_system or _system_for(
            category, reported_activity.resource_id
        )
        if category and system:
            related_observations.append(Observation(
                system, reported_activity.resource_id, category,
                reported_activity.activity_id, reported_activity.event_time,
                {"reported_result": reported_activity.reported_result}, False,
                "dataset/system_activity.csv", reported_activity.event_type,
            ))
    latest = _latest_observations(related_observations, cutoff)
    latest_coverage = _latest_coverages(coverages, cutoff)

    states: dict[tuple[str, str, str], tuple[Observation | None, bool, str, str]] = {}
    for key, observation in latest.items():
        coverage = _coverage_for(key[0], key[2], observation.scope_id, latest_coverage)
        if (
            _coverage_proves_resource_absence(coverage, key[1], activities, cutoff)
            and coverage is not None
            and coverage.observed_at > observation.observed_at
        ):
            absence = Observation(
                key[0], key[1], key[2], coverage.evidence_id, coverage.observed_at,
                {}, True, coverage.source_path, scope_id=coverage.source_path,
            )
            states[key] = (absence, False, "ABSENT", rules.get(key[2], "DELETE"))
            continue
        action = _treatment_for_resource(
            observation, rules, identity, activities, cutoff
        )
        violation, state = _is_violation(observation, action, identity, cutoff)
        states[key] = (observation, violation, state, action)

    for resource_id in sorted(resource_ids):
        category = _category_from_hints(resource_id)
        if not category:
            continue
        target_systems = {
            activity.target_system
            for activity in activities
            if activity.resource_id == resource_id
            and activity.target_system
            and activity.event_time <= cutoff
        }
        systems = target_systems or {CATEGORY_SYSTEM.get(category, _system_for(category, resource_id))}
        for system_id in sorted(system for system in systems if system):
            key = (system_id, resource_id, category)
            if key in states:
                continue
            coverage = _coverage_for(system_id, category, "", latest_coverage)
            if _coverage_proves_resource_absence(coverage, resource_id, activities, cutoff):
                absence = Observation(
                    system_id, resource_id, category, coverage.evidence_id,
                    coverage.observed_at, {}, True, coverage.source_path,
                )
                states[key] = (absence, False, "ABSENT", rules.get(category, "DELETE"))

    steps: list[Step] = []
    incomplete = False
    for (system_id, resource_id, category), (observation, violation, state, action) in states.items():
        if category == "DATA_FLOW":
            if violation:
                incomplete = True
                evidence_id = observation.evidence_id if observation else ""
                steps.extend([
                    Step("FINDING", system_id, resource_id, "REPORT_ACTIVE_DATA_FLOW", "ACTIVE", evidence_id),
                    Step("REMEDIATION", system_id, resource_id, "DISABLE_DATA_FLOW", "DISABLED", ""),
                    Step("VERIFICATION", system_id, resource_id, "VERIFY_DATA_FLOW_DISABLED", "DISABLED", ""),
                ])
            elif state == "DISABLED":
                evidence_id = observation.evidence_id if observation else ""
                if evidence_id:
                    steps.append(Step(
                        "VERIFICATION", system_id, resource_id,
                        "VERIFY_DATA_FLOW_DISABLED", "DISABLED", evidence_id,
                    ))
            elif state != "ABSENT":
                incomplete = True
            continue

        if category == "BACKUP_ARCHIVE":
            if violation:
                incomplete = True
                evidence_id = observation.evidence_id if observation else ""
                steps.extend([
                    Step("FINDING", system_id, resource_id, "REPORT_RESTORE_RISK", "ACTIVE", evidence_id),
                    Step("REMEDIATION", system_id, resource_id, "BLOCK_RESTORE", "BLOCKED", ""),
                    Step("VERIFICATION", system_id, resource_id, "VERIFY_RESTORE_BLOCKED", "BLOCKED", ""),
                ])
            elif state == "BLOCKED" and observation and observation.evidence_id:
                steps.append(Step(
                    "VERIFICATION", system_id, resource_id,
                    "VERIFY_RESTORE_BLOCKED", "BLOCKED", observation.evidence_id,
                ))
            elif state != "ABSENT":
                incomplete = True
            continue

        evidence_id = observation.evidence_id if observation else ""
        if violation:
            incomplete = True
            finding = FINDING_OPERATION.get(action, "")
            remediation = REMEDIATION_OPERATION.get(action, "")
            if finding and evidence_id:
                steps.append(Step("FINDING", system_id, resource_id, finding, "PRESENT", evidence_id))
            if remediation:
                remediation_state = {
                    "DELETE": "ABSENT",
                    "REDACT": "REDACTED",
                    "ANONYMIZE": "ANONYMIZED",
                }[action]
                steps.append(Step(
                    "REMEDIATION", system_id, resource_id,
                    remediation, remediation_state, "",
                ))
                verification_operation = VERIFICATION_OPERATION.get(action)
                if verification_operation:
                    steps.append(Step(
                        "VERIFICATION", system_id, resource_id,
                        verification_operation[0], verification_operation[1], "",
                    ))
        elif observation is not None and evidence_id and state and not (
            action == "DELETE"
            and state == "ABSENT"
            and any(
                other_resource == resource_id and other_violation
                for (_other_system, other_resource, _other_category),
                (_other_observation, other_violation, _other_state, _other_action)
                in states.items()
            )
        ):
            verification = VERIFICATION_OPERATION.get(action)
            if verification:
                steps.append(Step(
                    "VERIFICATION", system_id, resource_id,
                    verification[0], verification[1], evidence_id,
                ))
        elif (
            action == "DELETE"
            and state == "ABSENT"
            and evidence_id
            and not any(
                other_resource == resource_id and other_violation
                for (_other_system, other_resource, _other_category),
                (_other_observation, other_violation, _other_state, _other_action)
                in states.items()
            )
        ):
            steps.append(Step(
                "VERIFICATION", system_id, resource_id,
                "VERIFY_RECORD_ABSENT", "ABSENT", evidence_id,
            ))

    if not states:
        incomplete = True
    status = "INCOMPLETE" if incomplete else "COMPLETE"
    if incomplete:
        for step in steps:
            if step.phase == "VERIFICATION":
                step.evidence_id = ""
    steps.sort(key=lambda step: (
        PHASE_ORDER[step.phase],
        OPERATION_ORDER[step.operation],
        step.system_id,
        step.resource_id,
        step.evidence_id,
    ))
    if trace_stats is not None:
        trace_stats["state_count"] = len(states)
        trace_stats["step_count"] = len(steps)
        trace_stats["observations"] = sorted({
            (
                observation.evidence_id,
                observation.resource_id,
                observation.system_id,
                observation.category,
                state,
                violation,
            )
            for observation, violation, state, _action in states.values()
            if observation is not None
        })
        trace_stats["observations"] = [
            {
                "evidence_id": evidence_id,
                "resource_id": resource_id,
                "system_id": system_id,
                "category": category,
                "state": state,
                "violation": violation,
            }
            for (
                evidence_id,
                resource_id,
                system_id,
                category,
                state,
                violation,
            ) in trace_stats["observations"]
        ]
    return status, steps


def _validate_step(step: Step) -> None:
    operation_states = {
        "REPORT_REMAINING_RECORD": ("FINDING", "PRESENT"),
        "REPORT_EXPOSED_PII": ("FINDING", "PRESENT"),
        "REPORT_ACTIVE_DATA_FLOW": ("FINDING", "ACTIVE"),
        "REPORT_RESTORE_RISK": ("FINDING", "ACTIVE"),
        "DISABLE_DATA_FLOW": ("REMEDIATION", "DISABLED"),
        "BLOCK_RESTORE": ("REMEDIATION", "BLOCKED"),
        "DELETE_RECORD": ("REMEDIATION", "ABSENT"),
        "REDACT_RECORD": ("REMEDIATION", "REDACTED"),
        "ANONYMIZE_RECORD": ("REMEDIATION", "ANONYMIZED"),
        "VERIFY_RECORD_ABSENT": ("VERIFICATION", "ABSENT"),
        "VERIFY_RECORD_PRESENT": ("VERIFICATION", "PRESENT"),
        "VERIFY_RECORD_REDACTED": ("VERIFICATION", "REDACTED"),
        "VERIFY_RECORD_ANONYMIZED": ("VERIFICATION", "ANONYMIZED"),
        "VERIFY_DATA_FLOW_DISABLED": ("VERIFICATION", "DISABLED"),
        "VERIFY_RESTORE_BLOCKED": ("VERIFICATION", "BLOCKED"),
    }
    if operation_states.get(step.operation) != (step.phase, step.state):
        raise PipelineError(f"Invalid phase/state for operation {step.operation}")
    if not step.system_id or not step.resource_id:
        raise PipelineError("Output step is missing system_id or resource_id")
    if step.phase == "FINDING" and not step.evidence_id:
        raise PipelineError("Finding step is missing evidence_id")
    if step.phase == "REMEDIATION" and step.evidence_id:
        raise PipelineError("Remediation step must have empty evidence_id")


def serialize_case(
    case: dict[str, str],
    status: str,
    steps: list[Step],
) -> dict[str, str]:
    if status == "NOT_APPLICABLE" and steps:
        raise PipelineError("NOT_APPLICABLE cases must have no steps")
    if status == "COMPLETE" and any(step.phase != "VERIFICATION" for step in steps):
        raise PipelineError("COMPLETE cases may contain verification steps only")
    serialized: list[dict[str, Any]] = []
    for index, step in enumerate(steps, start=1):
        _validate_step(step)
        if status == "COMPLETE" and not step.evidence_id:
            raise PipelineError("COMPLETE verification requires evidence")
        # INCOMPLETE: future verifications (from remediation plan) have empty evidence_id;
        # current-state verifications (findings) correctly carry evidence_id.
        serialized.append({
            "step_no": index,
            "phase": step.phase,
            "system_id": step.system_id,
            "resource_id": step.resource_id,
            "operation": step.operation,
            "state": step.state,
            "evidence_id": step.evidence_id,
        })
    return {
        "case_id": case["case_id"],
        "deletion_status": status,
        "steps_json": json.dumps(serialized, ensure_ascii=False, separators=(",", ":")),
    }


def load_rules(dataset_dir: Path) -> dict[str, str]:
    rows = read_csv(
        dataset_dir / "deletion_rules.csv",
        ("rule_id", "data_category", "condition", "required_action"),
    )
    return {
        row["data_category"]: row["required_action"].strip().upper()
        for row in rows if row.get("data_category")
    }


def write_output(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=OUTPUT_COLUMNS, lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)
    except OSError as exc:
        raise PipelineError(f"Cannot write output CSV: {path}") from exc


def run_pipeline(
    request_path: Path, output_path: Path, *, trace: bool = False
) -> dict[str, Any]:
    dataset_dir = DATASET_DIR.resolve()
    request_path = request_path.resolve()
    if not request_path.is_file():
        raise PipelineError(f"Request CSV is missing: {request_path}")
    cases = read_csv(
        request_path,
        ("case_id", "email", "requested_at", "reported_status", "reported_at", "audit_at", "request_text"),
    )
    if len({row["case_id"] for row in cases}) != len(cases):
        raise PipelineError("Request CSV contains duplicate case_id values")
    identity_rows, audits = load_identity_rows(dataset_dir)
    activities = load_activities(dataset_dir)
    model = os.environ.get("GHOSTDATA_VLM_MODEL", "").strip()
    image_extraction_report: dict[str, Any] = {}
    observations, coverages, usage = load_evidence(
        dataset_dir, activities, model,
        image_extraction_report=image_extraction_report,
    )
    rules = load_rules(dataset_dir)
    reported_assignments = _reported_activity_assignments(cases, activities)

    output_rows: list[dict[str, str]] = []
    status_counts: dict[str, int] = defaultdict(int)
    case_traces: list[dict[str, Any]] = []
    for case in cases:
        trace_stats: dict[str, Any] | None = {} if trace else None
        status, steps = _build_case_steps(
            case, identity_rows, audits, activities, observations, coverages, rules,
            trace_stats, reported_assignments.get(case["case_id"]),
        )
        if trace_stats is not None:
            case_traces.append({"case_id": case["case_id"], "status": status, **trace_stats})
        output_rows.append(serialize_case(case, status, steps))
        status_counts[status] += 1
    output_rows.sort(key=lambda row: row["case_id"])
    write_output(output_path, output_rows)
    result = {
        "requests": len(cases),
        "statuses": dict(sorted(status_counts.items())),
        "output": str(output_path),
        "vision_usage": usage,
        "vision_model": model or None,
        "image_text_extraction": image_extraction_report,
    }
    if trace:
        result["trace"] = case_traces
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Audit deletion requests using participant-facing dataset evidence"
    )
    parser.add_argument(
        "--requests", default="dataset/deletion_requests.csv",
        help="Request CSV path, relative to the repository root by default",
    )
    parser.add_argument(
        "--output", default="output.csv",
        help="Output CSV path, relative to the repository root by default",
    )
    parser.add_argument(
        "--trace", action="store_true",
        help="Include per-request aggregate identity, activity, evidence, coverage, and state counters",
    )
    args = parser.parse_args(argv)
    try:
        result = run_pipeline(
            resolve_dataset_path(args.requests),
            resolve_dataset_path(args.output),
            trace=args.trace,
        )
    except PipelineError as exc:
        print(f"pipeline error: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
