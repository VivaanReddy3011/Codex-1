"""Synthetic regressions for structured log formats used by evidence parsers."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import main as pipeline


def main() -> int:
    json_line = (
        '2026-06-01T10:00:00Z '
        '{"service":"support_platform","trace_id":"tr-synthetic-1",'
        '"resource_id":"support_synthetic_1","event":"message_pii_scan",'
        '"matched_value":"person@example.test","detector":"direct_identifier"}'
    )
    json_fields = pipeline._parse_log_line(json_line) or {}
    assert json_fields.get("resource_id") == "support_synthetic_1"
    assert json_fields.get("trace_id") == "tr-synthetic-1"
    assert json_fields.get("matched_value") == "person@example.test"
    assert json_fields.get("event_time") == "2026-06-01T10:00:00Z"

    cloud_line = (
        '2026-06-01T10:02:00Z requestId=tr-synthetic-3 level=WARN '
        'function=support_platform message="instance=\\"support-1\\" '
        'resource_id=\\"support_synthetic_2\\" event=\\"message_pii_scan\\" '
        'matched_value=\\"person@example.test\\" detector=\\"direct_identifier\\""'
    )
    cloud_fields = pipeline._parse_log_line(cloud_line) or {}
    assert cloud_fields.get("trace_id") == "tr-synthetic-3"
    assert cloud_fields.get("resource_id") == "support_synthetic_2"
    assert cloud_fields.get("matched_value") == "person@example.test"
    assert cloud_fields.get("event") == "message_pii_scan"

    syslog_line = (
        '2026-06-01T10:01:00Z <15>1 node-1 search_service tr-synthetic-2 - - '
        'level=INFO resource_id=search_synthetic_1 event=index_query_completed '
        'result=hit correlation_key="person@example.test"'
    )
    syslog_fields = pipeline._parse_log_line(syslog_line) or {}
    assert syslog_fields.get("service") == "search_service"
    assert syslog_fields.get("trace_id") == "tr-synthetic-2"
    assert syslog_fields.get("resource_id") == "search_synthetic_1"
    assert pipeline._category_from_hints(
        "search_synthetic_1", "", "syslog_archive_example.log"
    ) == "SEARCH_INDEX_ENTRY"

    jsonl_line = (
        '2026-06-01T10:02:30Z '
        '{"service":"account_service","resource_id":"account_synthetic_1",'
        '"event":"profile_lookup_completed","rows":"0",'
        '"lookup_key":"person@example.test"}'
    )
    jsonl_fields = pipeline._parse_log_line(jsonl_line) or {}
    assert jsonl_fields.get("resource_id") == "account_synthetic_1"
    assert jsonl_fields.get("email") == "person@example.test"
    assert jsonl_fields.get("rows") == 0
    print("PASS: 4 synthetic key/value, nested, JSONL, and syslog parser cases")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
