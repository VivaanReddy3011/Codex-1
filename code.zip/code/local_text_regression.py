"""Synthetic checks for optional, cached local text extraction."""

from __future__ import annotations

import binascii
import sys
import struct
import tempfile
import unittest
import zlib
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))

import main as pipeline


def synthetic_dashboard_png() -> bytes:
    width, height = 640, 360
    pixels = bytearray([246, 248, 251] * width * height)

    def rectangle(left: int, top: int, right: int, bottom: int,
                  color: tuple[int, int, int]) -> None:
        row = bytes(color) * (right - left)
        for y in range(top, bottom):
            start = (y * width + left) * 3
            pixels[start:start + len(row)] = row

    rectangle(0, 0, width, 44, (30, 50, 82))
    rectangle(0, 44, 170, height, (36, 49, 69))
    rectangle(192, 84, 620, 142, (255, 255, 255))
    rectangle(192, 154, 620, 214, (255, 255, 255))
    rectangle(506, 168, 590, 195, (188, 228, 205))

    def chunk(kind: bytes, data: bytes) -> bytes:
        payload = kind + data
        return struct.pack(">I", len(data)) + payload + struct.pack(">I", binascii.crc32(payload) & 0xffffffff)

    stride = width * 3
    raw = b"".join(b"\x00" + pixels[y * stride:(y + 1) * stride]
                    for y in range(height))
    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header)
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


class LocalTextRegression(unittest.TestCase):
    def test_extraction_cache_uses_file_content_and_engine(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "artifact.bin"
            path.write_bytes(b"synthetic content")
            cache = Path(directory) / "local.sqlite3"
            with patch.dict("os.environ", {"GHOSTDATA_LOCAL_TEXT_CACHE": str(cache)}):
                extractor = unittest.mock.Mock(return_value="recognized text")
                stats = {"hits": 0, "misses": 0}
                self.assertEqual(pipeline._cached_local_text(path, "engine-a", extractor, stats),
                                 "recognized text")
                self.assertEqual(pipeline._cached_local_text(path, "engine-a", extractor, stats),
                                 "recognized text")
                self.assertEqual(pipeline._cached_local_text(path, "engine-b", extractor, stats),
                                 "recognized text")
                path.write_bytes(b"changed synthetic content")
                self.assertEqual(pipeline._cached_local_text(path, "engine-a", extractor, stats),
                                 "recognized text")
                self.assertEqual(extractor.call_count, 3)
                self.assertEqual(stats, {"hits": 1, "misses": 3})

    def test_pdf_text_uses_pdftotext_when_available(self) -> None:
        completed = type("Completed", (), {"stdout": "extracted PDF text"})()
        with patch.object(pipeline.shutil, "which", return_value="/tool/pdftotext"):
            with patch.object(pipeline.subprocess, "run", return_value=completed) as run:
                text = pipeline._local_pdf_text(Path("fixture.pdf"))
        self.assertEqual(text, "extracted PDF text")
        self.assertEqual(run.call_args.args[0][1], "-layout")

    def test_ocr_absence_is_graceful(self) -> None:
        with patch.object(pipeline, "_tesseract_executable", return_value=None):
            with patch.object(pipeline.subprocess, "run") as run:
                self.assertEqual(pipeline._local_ocr_text(Path("fixture.png")), "")
        run.assert_not_called()

    def test_image_evidence_uses_tesseract_when_available(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evidence = root / "evidence"
            evidence.mkdir()
            image = evidence / "synthetic.png"
            image.write_bytes(synthetic_dashboard_png())
            (root / "evidence_files.csv").write_text(
                "file_id,file_path,origin,captured_at\n"
                "evidence_synth,evidence/synthetic.png,account_service,2026-05-20T00:00:00Z\n",
                encoding="utf-8",
            )
            recognized = "level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext\n"
            recognized += "5\t1\t1\t1\t1\t1\t500\t50\t100\t20\t95\tdata_flow_ocr_synth\n"
            recognized += "5\t1\t1\t1\t2\t1\t500\t90\t40\t20\t95\tStatus\n"
            recognized += "5\t1\t1\t1\t2\t2\t550\t90\t50\t20\t95\tHealthy\n"
            completed = type("Completed", (), {"stdout": recognized})()
            cache = root / "cache.sqlite3"
            activity = pipeline.Activity(
                "activity_synth", pipeline.parse_time("2026-05-20T00:00:00Z"),
                "LINK_RESOURCE_IDENTITY", "data_catalog", "account_service",
                "data_flow_ocr_synth", "synthetic identity link", "SUCCESS",
            )
            extraction_report = {}
            with patch.dict("os.environ", {"GHOSTDATA_LOCAL_TEXT_CACHE": str(cache)}):
                with patch.object(pipeline, "_tesseract_executable", return_value="/tool/tesseract"):
                    with patch.object(pipeline.subprocess, "run", return_value=completed) as run:
                        observations, _coverage, _usage = pipeline.load_evidence(
                            root, [activity], image_extraction_report=extraction_report
                        )
            self.assertEqual(len(observations), 1)
            self.assertEqual(observations[0].resource_id, "data_flow_ocr_synth")
            self.assertEqual(observations[0].evidence_id, "evidence_synth")
            self.assertIs(observations[0].fields.get("active"), True)
            self.assertEqual(extraction_report, {
                "image_evidence_count": 1,
                "local_ocr_available": True,
                "vlm_available": False,
                "cache": {"hits": 0, "misses": 1},
                "extractors": ["tesseract-tsv-v1"],
                "text_extracted_evidence_ids": ["evidence_synth"],
                "skipped_evidence_ids": [],
                "skipped_reasons": {},
            })
            self.assertEqual(run.call_args.args[0][0], "/tool/tesseract")
            self.assertTrue(Path(run.call_args.args[0][1]).samefile(image))
            self.assertEqual(run.call_args.args[0][2], "stdout")

    def test_image_evidence_skips_cleanly_when_tesseract_is_unavailable(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evidence = root / "evidence"
            evidence.mkdir()
            image = evidence / "synthetic.png"
            image.write_bytes(synthetic_dashboard_png())
            (root / "evidence_files.csv").write_text(
                "file_id,file_path,origin,captured_at\n"
                "evidence_synth,evidence/synthetic.png,account_service,2026-05-20T00:00:00Z\n",
                encoding="utf-8",
            )
            cache = root / "cache.sqlite3"
            extraction_report = {}
            with patch.dict("os.environ", {"GHOSTDATA_LOCAL_TEXT_CACHE": str(cache)}):
                with patch.object(pipeline, "_tesseract_executable", return_value=None):
                    with patch.object(pipeline.subprocess, "run") as run:
                        observations, _coverage, usage = pipeline.load_evidence(
                            root, [], image_extraction_report=extraction_report
                        )
            run.assert_not_called()
            self.assertEqual(observations, [])
            self.assertEqual(usage, {"calls": 0, "cache_hits": 0,
                                     "input_tokens": 0, "output_tokens": 0})
            self.assertEqual(extraction_report, {
                "image_evidence_count": 1,
                "local_ocr_available": False,
                "vlm_available": False,
                "cache": {"hits": 0, "misses": 0},
                "extractors": [],
                "text_extracted_evidence_ids": [],
                "skipped_evidence_ids": ["evidence_synth"],
                "skipped_reasons": {"evidence_synth": "no_extractor"},
            })


if __name__ == "__main__":
    unittest.main()
