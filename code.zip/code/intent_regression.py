"""Synthetic intent regressions for Portuguese deletion requests."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import main as pipeline


CASES = (
    ("Solicito a exclus\u00e3o permanente da conta associada a este e-mail.", True),
    ("Pe\u00e7o a elimina\u00e7\u00e3o dos meus dados pessoais.", True),
    ("Quero apagar minha conta permanentemente.", True),
    ("N\u00e3o quero excluir minha conta; desejo mant\u00ea-la ativa.", False),
    ("N\u00e3o solicito exclus\u00e3o da conta.", False),
    ("Please update my phone number and leave the account active.", False),
)


def main() -> int:
    failures = [
        (text, expected, pipeline.is_deletion_request(text))
        for text, expected in CASES
        if pipeline.is_deletion_request(text) != expected
    ]
    if failures:
        for text, expected, actual in failures:
            print(f"FAIL expected={expected} actual={actual}: {text}")
        return 1
    print(f"PASS: {len(CASES)} synthetic deletion-intent cases")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
