"""Synthetic checks that explicit deletion policy wins over conflicting activity."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import main as pipeline


def main() -> int:
    cutoff = pipeline.parse_time("2026-09-15T12:00:00Z")
    event_time = pipeline.parse_time("2026-08-25T12:53:51Z")
    identity = pipeline.Identity(
        "user_synthetic", {"email": {"person@example.test"}, "email_hash": set()}
    )
    observation = pipeline.Observation(
        "analytics_platform", "analytics_synthetic", "ANALYTICS_PROFILE",
        "evidence_synthetic", event_time, {"user_id": "user_synthetic"},
        True, "synthetic.json",
    )
    conflicting_activity = pipeline.Activity(
        "activity_synthetic", event_time, "DELETE_RECORD", "deletion_worker",
        "analytics_platform", "analytics_synthetic", "Failed delete attempt", "FAILED",
    )

    action = pipeline._treatment_for_resource(
        observation,
        {"ANALYTICS_PROFILE": "ANONYMIZE"},
        identity,
        [conflicting_activity],
        cutoff,
    )
    assert action == "ANONYMIZE"
    assert pipeline.REMEDIATION_OPERATION[action] == "ANONYMIZE_RECORD"
    assert pipeline.VERIFICATION_OPERATION[action] == (
        "VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"
    )

    print("1 policy precedence regression passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
