"""Synthetic checks for unique activity-to-report resource linkage."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import main as pipeline


def activity(activity_id: str, timestamp: str) -> pipeline.Activity:
    return pipeline.Activity(
        activity_id, pipeline.parse_time(timestamp), "DELETE_RECORD",
        "deletion_worker", "account_service", f"account_{activity_id}",
        "resource operation", "FAILED",
    )


def main() -> int:
    unique_case = {
        "case_id": "synthetic_one_to_one", "reported_at": "2026-06-01T10:00:00Z",
        "audit_at": "2026-06-01T11:00:00Z",
    }
    unique_event = activity("synthetic_event", "2026-06-01T10:01:00Z")
    assigned = pipeline._reported_activity_assignments([unique_case], [unique_event])
    assert assigned == {"synthetic_one_to_one": unique_event}

    competing_cases = [
        {**unique_case, "case_id": "synthetic_left"},
        {**unique_case, "case_id": "synthetic_right",
         "reported_at": "2026-06-01T10:02:00Z"},
    ]
    assert pipeline._reported_activity_assignments(competing_cases, [unique_event]) == {}

    after_cutoff = activity("synthetic_late", "2026-06-01T12:00:00Z")
    assert pipeline._reported_activity_assignments([unique_case], [after_cutoff]) == {}

    document_link = pipeline.Activity(
        "synthetic_link", pipeline.parse_time("2026-06-01T09:59:00Z"),
        "LINK_RESOURCE_IDENTITY", "catalog", "export_service", "export_synth_1",
        "Catalog linked export_synth_1 (statement-synth-1) to subject", "SUCCESS",
    )
    aliases = pipeline._document_resource_aliases([document_link])
    observations = pipeline._text_observations(
        "Statement statement-synth-1\nemail=person@example.test",
        "evidence_synth_1", pipeline.parse_time("2026-06-01T10:00:00Z"),
        "synthetic.pdf", "export_service", {}, document_scope=True,
        document_resource_aliases=aliases,
    )
    assert any(
        item.resource_id == "export_synth_1" and item.category == "USER_EXPORT"
        and pipeline._observation_matches(
            item, pipeline.Identity("user_synth_1", {"email": {"person@example.test"}})
        )
        for item in observations
    )

    state_case = {
        "case_id": "synthetic_state_after_link", "email": "person@example.test",
        "audit_at": "2026-06-01T11:00:00Z", "request_text": "Delete my account.",
    }
    identity_rows = {"user_synth_1": {
        "user_id": "user_synth_1", "name": "Synthetic User",
        "email": "person@example.test", "phone": "", "email_hash": "",
        "updated_at": "2026-06-01T08:00:00Z",
    }}
    state_observation = pipeline.Observation(
        "account_service", "account_synth_1", "USER_PROFILE", "evidence_state",
        pipeline.parse_time("2026-06-01T10:00:00Z"),
        {"resource_id": "account_synth_1", "email": "person@example.test"},
        True, "synthetic.json",
    )
    later_link = pipeline.Activity(
        "activity_link", pipeline.parse_time("2026-06-01T10:05:00Z"),
        "LINK_RESOURCE_IDENTITY", "catalog", "account_service", "account_synth_1",
        "Catalog linked account_synth_1 to person@example.test and user_synth_1", "SUCCESS",
    )
    status, steps = pipeline._build_case_steps(
        state_case, identity_rows, [], [later_link], [state_observation], [],
        {"USER_PROFILE": "DELETE"},
    )
    assert status == "INCOMPLETE"
    assert steps and steps[0].evidence_id == "evidence_state"

    coverage_case = {
        "case_id": "synthetic_coverage_before_link", "email": "person@example.test",
        "audit_at": "2026-06-01T11:00:00Z", "request_text": "Delete my account.",
    }
    flow_link = pipeline.Activity(
        "activity_flow_link", pipeline.parse_time("2026-06-01T10:05:00Z"),
        "LINK_RESOURCE_IDENTITY", "catalog", "integration_service", "data_flow_synth_1",
        "Catalog linked data_flow_synth_1 to person@example.test and user_synth_1", "SUCCESS",
    )
    old_coverage = pipeline.Coverage(
        "integration_service", "DATA_FLOW", "evidence_old_snapshot",
        pipeline.parse_time("2026-06-01T09:00:00Z"), "connector_configurations",
    )
    status, steps = pipeline._build_case_steps(
        coverage_case, identity_rows, [], [flow_link], [], [old_coverage],
        {"DATA_FLOW": "DELETE"},
    )
    assert status == "INCOMPLETE" and steps == []
    print("PASS: unique/ambiguous links, PDF refs, state precedence, and coverage cutoff")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
