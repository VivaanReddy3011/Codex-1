"""Synthetic regressions for conservative, layout-aware screenshot OCR."""

from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import main as pipeline


def tsv(words: list[tuple[int, int, str]]) -> str:
    header = "level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext"
    rows = [header]
    for index, (left, top, text) in enumerate(words, start=1):
        rows.append(f"5\t1\t{index}\t1\t1\t1\t{left}\t{top}\t80\t12\t95\t{text}")
    return "\n".join(rows)


def main() -> int:
    captured_at = datetime(2026, 8, 7, 8, tzinfo=timezone.utc)
    source = tsv([
        (1442, 333, "data_flow_1121"),
        (1442, 381, "Status"), (1558, 382, "Healthy"),
        (1442, 481, "Selector"), (1558, 482, "person@example.test"),
        (1442, 515, "Sync"), (1490, 515, "mode"), (1558, 515, "Continuous"),
    ])
    observations = pipeline._ocr_detail_panel_observations(
        source,
        image_width=1800,
        file_id="evidence_synthetic_screen",
        observed_at=captured_at,
        source_path="synthetic.png",
        targets={"data_flow_1121": {"integration_service"}},
    )
    assert len(observations) == 1
    assert observations[0].resource_id == "data_flow_1121"
    assert observations[0].fields["active"] is True
    assert observations[0].fields["email"] == "person@example.test"

    profile = tsv([
        (250, 120, "analytics_profile_21"),
        (480, 120, "person@example.test"),
        (380, 200, "Email"),
    ])
    profile_observations = pipeline._ocr_detail_panel_observations(
        profile,
        image_width=1800,
        file_id="evidence_synthetic_profile",
        observed_at=captured_at,
        source_path="synthetic-profile.png",
        targets={"analytics_profile_21": {"analytics_platform"}},
    )
    assert len(profile_observations) == 1
    assert profile_observations[0].fields["email"] == "person@example.test"

    ambiguous = tsv([
        (1442, 333, "data_flow_1121"),
        (1442, 345, "data_flow_9846"),
        (1442, 381, "Status"), (1558, 382, "Healthy"),
    ])
    assert not pipeline._ocr_detail_panel_observations(
        ambiguous,
        image_width=1800,
        file_id="evidence_synthetic_screen",
        observed_at=captured_at,
        source_path="synthetic.png",
        targets={
            "data_flow_1121": {"integration_service"},
            "data_flow_9846": {"integration_service"},
        },
    )
    print("3 screenshot OCR regressions passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
