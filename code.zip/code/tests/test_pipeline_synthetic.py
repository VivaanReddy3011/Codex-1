"""Fictional end-to-end fixtures for the deterministic audit pipeline."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import main as pipeline


REQUEST_FIELDS = (
    "case_id", "email", "requested_at", "reported_status", "reported_at",
    "audit_at", "request_text",
)


def write_csv(path: Path, fieldnames: tuple[str, ...], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


class SyntheticPipelineCases(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="ghostdata-synthetic-")
        self.root = Path(self.temp.name)
        (self.root / "evidence").mkdir()

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_fixture(
        self,
        *,
        user_id: str,
        current_email: str,
        request_email: str,
        evidence_capture: str,
        record: dict[str, str] | None,
        audit_old_email: str | None = None,
        email_hash: str = "",
        evidence_text: str | None = None,
        rules: list[dict[str, str]] | None = None,
    ) -> dict[str, object]:
        write_csv(
            self.root / "user_identities.csv",
            ("user_id", "name", "email", "phone", "email_hash", "updated_at"),
            [{
                "user_id": user_id,
                "name": "Morgan Patel",
                "email": current_email,
                "phone": "",
                "email_hash": email_hash,
                "updated_at": "2026-05-01T00:00:00Z",
            }],
        )
        audit_rows = []
        if audit_old_email:
            audit_rows.append({
                "audit_id": "audit_synth_01", "user_id": user_id,
                "event_time": "2026-04-01T00:00:00Z", "field_name": "email",
                "old_value": audit_old_email, "new_value": current_email,
            })
        write_csv(
            self.root / "user_audit_log.csv",
            ("audit_id", "user_id", "event_time", "field_name", "old_value", "new_value"),
            audit_rows,
        )
        write_csv(
            self.root / "system_activity.csv",
            ("activity_id", "event_time", "event_type", "source_system", "target_system",
             "resource_id", "reported_result", "details"),
            [],
        )
        write_csv(
            self.root / "deletion_rules.csv",
            ("rule_id", "data_category", "condition", "required_action"),
            rules or [{"rule_id": "rule_synth_01", "data_category": "USER_PROFILE",
                       "condition": "Always", "required_action": "DELETE"}],
        )
        evidence_name = "fixture.log" if evidence_text is not None else "fixture.json"
        if evidence_text is not None:
            (self.root / "evidence" / evidence_name).write_text(evidence_text, encoding="utf-8")
        else:
            (self.root / "evidence" / evidence_name).write_text(
                json.dumps({"records": [record or {}]}), encoding="utf-8"
            )
        write_csv(
            self.root / "evidence_files.csv",
            ("file_id", "file_path", "origin", "captured_at"),
            [{"file_id": "evidence_synth_01", "file_path": f"evidence/{evidence_name}",
              "origin": "customer_profiles", "captured_at": evidence_capture}],
        )
        request_path = self.root / "requests.csv"
        write_csv(
            request_path, REQUEST_FIELDS,
            [{"case_id": "synthetic_case", "email": request_email,
              "requested_at": "2026-05-15T00:00:00Z", "reported_status": "COMPLETE",
              "reported_at": "2026-05-16T00:00:00Z", "audit_at": "2026-06-01T00:00:00Z",
              "request_text": "Please delete my account."}],
        )
        output_path = self.root / "prediction.csv"
        with patch.object(pipeline, "DATASET_DIR", self.root):
            pipeline.run_pipeline(request_path, output_path)
        with output_path.open("r", encoding="utf-8", newline="") as stream:
            row = next(csv.DictReader(stream))
        row["steps"] = json.loads(row.pop("steps_json"))
        return row

    def test_historical_email_links_to_the_same_user_record(self) -> None:
        row = self.run_fixture(
            user_id="user_synth_01", current_email="morgan.current@example.test",
            request_email="morgan.old@example.test", audit_old_email="morgan.old@example.test",
            evidence_capture="2026-05-20T00:00:00Z",
            record={"resource_id": "account_synth_01", "email": "morgan.old@example.test"},
        )
        self.assertEqual(row["deletion_status"], "INCOMPLETE")
        self.assertIn("account_synth_01", {step["resource_id"] for step in row["steps"]})

    def test_similarly_named_decoy_without_identity_edge_is_not_linked(self) -> None:
        row = self.run_fixture(
            user_id="user_synth_02", current_email="morgan.current@example.test",
            request_email="morgan.current@example.test", evidence_capture="2026-05-20T00:00:00Z",
            record={"resource_id": "account_decoy_02", "name": "Morgan Patell",
                    "email": "decoy@example.test"},
        )
        self.assertNotIn("account_decoy_02", {step["resource_id"] for step in row["steps"]})

    def test_post_cutoff_evidence_does_not_change_case_state(self) -> None:
        email = "morgan.future@example.test"
        email_hash = hashlib.sha256(email.encode("utf-8")).hexdigest()
        row = self.run_fixture(
            user_id="user_synth_03", current_email=email, request_email=email,
            email_hash=email_hash, evidence_capture="2026-06-02T00:00:00Z", record=None,
            evidence_text=(
                "2026-06-02T00:00:00Z level=INFO service=account_service "
                f"resource_id=account_future_03 correlation_key=\\\"{email_hash}\\\" result=found\n"
            ),
        )
        self.assertEqual(row["deletion_status"], "INCOMPLETE")
        self.assertEqual(row["steps"], [])

    def test_escaped_quoted_identity_aliases_link_without_raw_email(self) -> None:
        email = "morgan.current@example.test"
        email_hash = hashlib.sha256(email.encode("utf-8")).hexdigest()
        aliases = ("matched_value", "lookup_key", "scan_key", "correlation_key", "subject_key")
        for index, alias in enumerate(aliases, start=1):
            with self.subTest(alias=alias):
                resource_id = f"account_log_{index:02d}"
                log_line = (
                    "2026-05-20T00:00:00Z level=INFO service=account_service "
                    f"resource_id={resource_id} {alias}=\\\"{email_hash}\\\" result=found\n"
                )
                self.assertIn("\\\"", log_line)
                row = self.run_fixture(
                    user_id="user_synth_log", current_email=email, request_email=email,
                    email_hash=email_hash, evidence_capture="2026-05-20T00:00:00Z",
                    record=None, evidence_text=log_line,
                )
                self.assertEqual(row["deletion_status"], "INCOMPLETE")
                self.assertIn(resource_id, {step["resource_id"] for step in row["steps"]})

    def test_pdf_text_fallback_extracts_document_scoped_record(self) -> None:
        pdf_path = self.root / "evidence" / "synthetic.pdf"
        pdf_path.write_bytes(b"synthetic PDF fixture; parser is mocked")
        write_csv(
            self.root / "evidence_files.csv",
            ("file_id", "file_path", "origin", "captured_at"),
            [{"file_id": "evidence_pdf_synth", "file_path": "evidence/synthetic.pdf",
              "origin": "support_platform", "captured_at": "2026-05-20T00:00:00Z"}],
        )
        page_text = "email=morgan.pdf@example.test;" + chr(10) + (
            "2026-05-20T00:00:00Z service=support_platform "
            "resource_id=support_pdf_synth event=attachment_scan result=found"
        )
        page = type("SyntheticPage", (), {"extract_text": lambda self: page_text})()
        reader = type("SyntheticReader", (), {"pages": [page]})()
        with patch.object(pipeline, "PdfReader", return_value=reader):
            observations, _coverages, usage = pipeline.load_evidence(self.root, [])
        self.assertEqual(usage["calls"], 0)
        self.assertEqual(len(observations), 1)
        self.assertEqual(observations[0].resource_id, "support_pdf_synth")
        self.assertEqual(observations[0].category, "SUPPORT_MESSAGE")
        self.assertEqual(observations[0].evidence_id, "evidence_pdf_synth")
        self.assertTrue(str(observations[0].fields.get("document_subject_email", ""))
                        .startswith("morgan.pdf@example.test"))

    def test_mocked_ocr_fallback_extracts_image_evidence_and_usage(self) -> None:
        image_path = self.root / "evidence" / "synthetic.png"
        image_path.write_bytes(b"synthetic image fixture; OCR is mocked")
        write_csv(
            self.root / "evidence_files.csv",
            ("file_id", "file_path", "origin", "captured_at"),
            [{"file_id": "evidence_ocr_synth", "file_path": "evidence/synthetic.png",
              "origin": "account_service", "captured_at": "2026-05-20T00:00:00Z"}],
        )
        recognized_text = (
            "2026-05-20T00:00:00Z service=account_service "
            "resource_id=account_ocr_synth event=profile_scan email=morgan.ocr@example.test"
        )
        with patch.object(
            pipeline, "_ollama_vision_text", return_value=(recognized_text, 12, 4, False)
        ) as ocr:
            observations, _coverages, usage = pipeline.load_evidence(
                self.root, [], enable_vlm_model="synthetic-ocr"
            )
        ocr.assert_called_once()
        self.assertEqual(ocr.call_args.args[0].name, image_path.name)
        self.assertEqual(ocr.call_args.args[1], "synthetic-ocr")
        self.assertEqual(usage, {"calls": 1, "cache_hits": 0, "input_tokens": 12,
                                 "output_tokens": 4})
        self.assertEqual(len(observations), 1)
        self.assertEqual(observations[0].resource_id, "account_ocr_synth")
        self.assertEqual(observations[0].evidence_id, "evidence_ocr_synth")

    def write_image_evidence(self, captured_at: str, content: bytes = b"synthetic image") -> Path:
        image_path = self.root / "evidence" / "synthetic.png"
        image_path.write_bytes(content)
        write_csv(
            self.root / "evidence_files.csv",
            ("file_id", "file_path", "origin", "captured_at"),
            [{"file_id": "evidence_image_synth", "file_path": "evidence/synthetic.png",
              "origin": "integration_service", "captured_at": captured_at}],
        )
        return image_path

    @staticmethod
    def image_tsv(words: list[tuple[int, int, str]]) -> str:
        header = "level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext"
        rows = [header]
        for index, (left, top, text) in enumerate(words, start=1):
            rows.append(f"5\t1\t{index}\t1\t1\t{index}\t{left}\t{top}\t80\t12\t95\t{text}")
        return "\n".join(rows)

    def test_injected_image_extractor_cache_uses_namespace_and_content_hash(self) -> None:
        from PIL import Image

        image_path = self.write_image_evidence("2026-05-20T00:00:00Z")
        Image.new("RGB", (1000, 500), "white").save(image_path)
        calls: list[Path] = []
        extractor = pipeline.ImageTextExtractor(
            name="synthetic-tsv", cache_key="v1",
            extract_tsv=lambda path: calls.append(path) or self.image_tsv([
                (750, 100, "data_flow_synth_01"),
                (750, 130, "Status"), (850, 130, "Healthy"),
            ]),
        )
        identity_link = pipeline.Activity(
            activity_id="activity_identity_only", event_time=datetime(2026, 5, 19, tzinfo=timezone.utc),
            event_type="identity_link", source_system="identity_service",
            target_system="integration_service", resource_id="data_flow_synth_01",
            details="subject-linked resource", reported_result="linked",
        )
        cache_path = self.root / "local-text-cache.sqlite3"
        with patch.dict(os.environ, {"GHOSTDATA_LOCAL_TEXT_CACHE": str(cache_path)}):
            first, _, _ = pipeline.load_evidence(self.root, [identity_link], image_text_extractor=extractor)
            second, _, _ = pipeline.load_evidence(self.root, [identity_link], image_text_extractor=extractor)
            Image.new("RGB", (1000, 500), "black").save(image_path)
            third, _, _ = pipeline.load_evidence(self.root, [identity_link], image_text_extractor=extractor)
            namespaced = pipeline.ImageTextExtractor(
                name="synthetic-tsv", cache_key="v2",
                extract_tsv=lambda path: calls.append(path) or self.image_tsv([
                    (750, 100, "data_flow_synth_01"),
                    (750, 130, "Status"), (850, 130, "Healthy"),
                ]),
            )
            pipeline.load_evidence(self.root, [identity_link], image_text_extractor=namespaced)

        self.assertEqual([path.name for path in calls], [image_path.name] * 3)
        self.assertTrue(first[0].fields["active"])
        self.assertEqual(first[0].fields, second[0].fields)
        self.assertEqual(second[0].fields, third[0].fields)

    def test_image_extractor_diagnostics_report_unavailable_evidence(self) -> None:
        self.write_image_evidence("2026-05-20T00:00:00Z")
        report: dict[str, object] = {}
        extractor = pipeline.ImageTextExtractor(
            name="unavailable-tsv", extract_tsv=lambda _path: "", cache_key="none",
        )
        with patch.dict(os.environ, {"GHOSTDATA_LOCAL_TEXT_CACHE": str(self.root / "cache.sqlite3")}):
            observations, coverages, usage = pipeline.load_evidence(
                self.root, [], image_text_extractor=extractor,
                image_extraction_report=report,
            )
        self.assertEqual((observations, coverages), ([], []))
        self.assertEqual(usage["calls"], 0)
        self.assertEqual(report["extractors"], ["unavailable-tsv"])
        self.assertEqual(report["skipped_evidence_ids"], ["evidence_image_synth"])

    def test_image_state_after_cutoff_is_filtered_and_identity_link_is_not_state(self) -> None:
        from PIL import Image

        image_path = self.write_image_evidence("2026-05-20T00:00:00Z")
        Image.new("RGB", (1000, 500), "white").save(image_path)
        identity_link = pipeline.Activity(
            activity_id="activity_identity_only", event_time=datetime(2026, 5, 19, tzinfo=timezone.utc),
            event_type="identity_link", source_system="identity_service",
            target_system="integration_service", resource_id="data_flow_synth_01",
            details="subject-linked resource", reported_result="linked",
        )
        cache_path = self.root / "local-text-cache.sqlite3"
        with patch.dict(os.environ, {"GHOSTDATA_LOCAL_TEXT_CACHE": str(cache_path)}):
            identity_only, _, _ = pipeline.load_evidence(
                self.root, [identity_link], image_text_extractor=pipeline.ImageTextExtractor(
                    "identity-only", lambda _path: self.image_tsv([(750, 100, "data_flow_synth_01")]),
                ),
            )
            image_path.write_bytes(b"post-cutoff image contents")
            write_csv(
                self.root / "evidence_files.csv",
                ("file_id", "file_path", "origin", "captured_at"),
                [{"file_id": "evidence_image_synth", "file_path": "evidence/synthetic.png",
                  "origin": "integration_service", "captured_at": "2026-06-02T00:00:00Z"}],
            )
            Image.new("RGB", (1000, 500), "white").save(image_path)
            post_cutoff, _, _ = pipeline.load_evidence(
                self.root, [identity_link], image_text_extractor=pipeline.ImageTextExtractor(
                    "state-tsv", lambda _path: self.image_tsv([
                        (750, 100, "data_flow_synth_01"),
                        (750, 130, "Status"), (850, 130, "Healthy"),
                    ]), cache_key="state-v1",
                ),
            )

        cutoff = datetime(2026, 6, 1, tzinfo=timezone.utc)
        self.assertEqual(identity_only, [])
        self.assertTrue(post_cutoff)
        self.assertEqual(pipeline._latest_observations(post_cutoff, cutoff), {})

    def test_support_message_category_applies_redaction_treatment(self) -> None:
        email = "morgan.support@example.test"
        row = self.run_fixture(
            user_id="user_synth_support", current_email=email, request_email=email,
            evidence_capture="2026-05-20T00:00:00Z",
            record={"resource_id": "support_synth_01", "email": email,
                    "message_excerpt": "Customer asked about order delivery."},
            rules=[{"rule_id": "rule_synth_support", "data_category": "SUPPORT_MESSAGE",
                    "condition": "Shared conversation context", "required_action": "REDACT"}],
        )
        self.assertEqual(row["deletion_status"], "INCOMPLETE")
        resource_steps = [step for step in row["steps"]
                          if step["resource_id"] == "support_synth_01"]
        self.assertEqual(
            [(step["phase"], step["operation"], step["state"]) for step in resource_steps],
            [("FINDING", "REPORT_EXPOSED_PII", "PRESENT"),
             ("REMEDIATION", "REDACT_RECORD", "REDACTED"),
             ("VERIFICATION", "VERIFY_RECORD_REDACTED", "REDACTED")],
        )


if __name__ == "__main__":
    unittest.main()
