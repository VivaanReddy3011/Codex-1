import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "evaluation"))

from scorer import EvaluationInputError, score_rows


def step(number, operation, resource):
    return {
        "step_no": number,
        "phase": "VERIFICATION",
        "system_id": "synthetic_service",
        "resource_id": resource,
        "operation": operation,
        "state": "ABSENT",
        "evidence_id": "synthetic_evidence",
    }


def row(case_id, status, steps):
    return {"case_id": case_id, "deletion_status": status, "steps": steps}


class ScorerSyntheticCases(unittest.TestCase):
    def test_synthetic_non_deletion_case_scores_empty_sequence(self):
        gold = [row("synthetic_non_deletion", "NOT_APPLICABLE", [])]
        result = score_rows(gold, [row("synthetic_non_deletion", "NOT_APPLICABLE", [])])
        self.assertEqual(result["case_status_accuracy"], 1)
        self.assertEqual(result["sequence_accuracy"], 1)
        self.assertEqual(result["field_accuracy"], None)

    def test_synthetic_object_key_order_is_ignored(self):
        expected = step(1, "VERIFY_RECORD_ABSENT", "synthetic_account")
        reordered_keys = dict(reversed(list(expected.items())))
        result = score_rows(
            [row("synthetic_key_order", "COMPLETE", [expected])],
            [row("synthetic_key_order", "COMPLETE", [reordered_keys])],
        )
        self.assertEqual(result["step_f1"], 1)
        self.assertEqual(result["field_accuracy"], 1)
        self.assertEqual(result["sequence_accuracy"], 1)

    def test_synthetic_reordering_isolated_from_step_content_accuracy(self):
        first = step(1, "VERIFY_RECORD_ABSENT", "synthetic_account")
        second = step(2, "VERIFY_RECORD_ABSENT", "synthetic_replica")
        result = score_rows(
            [row("synthetic_order", "COMPLETE", [first, second])],
            [row("synthetic_order", "COMPLETE", [second, first])],
        )
        self.assertEqual(result["step_f1"], 1)
        self.assertEqual(result["sequence_accuracy"], 0)
        self.assertLess(result["field_accuracy"], 1)

    def test_synthetic_missing_and_extra_steps_are_penalized(self):
        first = step(1, "VERIFY_RECORD_ABSENT", "synthetic_account")
        second = step(2, "VERIFY_RECORD_ABSENT", "synthetic_replica")
        result = score_rows(
            [row("synthetic_step_count", "COMPLETE", [first, second])],
            [row("synthetic_step_count", "COMPLETE", [first])],
        )
        self.assertEqual(result["step_recall"], 0.5)
        self.assertEqual(result["sequence_accuracy"], 0)
        self.assertLess(result["field_accuracy"], 1)

    def test_duplicate_case_ids_are_rejected(self):
        duplicate = row("synthetic_duplicate", "NOT_APPLICABLE", [])
        with self.assertRaises(EvaluationInputError):
            score_rows([duplicate], [duplicate, duplicate])


if __name__ == "__main__":
    unittest.main()
