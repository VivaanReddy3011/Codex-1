# Evaluation report

## Current evaluation and production-run status

For the 32 public cases, **exact-row accuracy is 11/32 (34.38%)** using the latest QA-generated sample prediction against `dataset/sample_output.csv`. A row counts as correct only when its `deletion_status` and complete ordered `steps_json` array match; JSON object-key order is ignored. This is the same set of eleven exact step sequences in the latest sample evaluation, and all eleven also have the correct status.

The separate production execution **was completed** by Operator: `python code/main.py` exited successfully on all 518 requests and generated root `output.csv` with 518 unique case rows. `code/evaluation/usage_report.md` records the run and zero model calls/tokens. Hidden canonical answers for those 518 cases were not available for comparison, so production hidden-gold accuracy is unknown and was not scored. Older statements below saying the full run was not performed describe QA turns before Operator's final run; they do not describe the final project state.

## Synthetic evaluation fixtures

The suite distinguishes **scorer-only fixtures** from **pipeline-level fixtures**. `test_evaluation_scorer.py` contains five fictional scorer checks (NOT_APPLICABLE empty output, ignored JSON object-key order, sequence order, missing steps, and duplicate case IDs); these verify metric behavior and do not exercise `code/main.py`.

`test_pipeline_synthetic.py` runs the actual deterministic pipeline against isolated temporary datasets containing fictional identities and evidence only. It adds three end-to-end scenarios:

1. **Historical email:** an old address in the audit history resolves to exactly one fictional user, and the matching profile record is reported as a finding.
2. **Near-name decoy:** a fictional record for “Morgan Patell” has a separate email and no identity edge to “Morgan Patel.” The current pipeline leaves the decoy unlinked; this passed after Builder's identity-linking changes.
3. **Post-cutoff evidence:** a matching record captured after `audit_at` contributes no steps and cannot make the case complete.

Exact command and observed result:

```powershell
python -m unittest discover -s code/tests -p "test_pipeline_synthetic.py" -v
```

Result: 3 tests ran and passed. All fixtures are created in temporary directories and removed after each test; neither production code nor dataset files are modified by the tests.

The combined scorer and pipeline suite was also run with `python -m unittest discover -s code/tests -v`: 8 tests ran and passed.

## Scoring definitions

Run from the repository root after generating predictions:

```powershell
python code/evaluation/main.py output.csv
```

The optional `--gold` argument defaults to `dataset/sample_output.csv`. The scorer joins rows by `case_id`, rejects duplicate case IDs and malformed `steps_json`, and does not depend on CSV row ordering.

- **Case/status accuracy:** sample cases whose predicted `deletion_status` equals the reference status, divided by all reference cases. A missing prediction is incorrect. Case coverage and unexpected prediction count are also reported.
- **Step precision, recall, and F1:** exact step objects matched as a multiset within the same case; JSON object key order is ignored. Precision penalizes extra steps and recall penalizes omitted steps.
- **Field accuracy:** exact field values at each ordered step position over the union of fields present at that position in either answer. Missing, changed, or additional fields count as incorrect. An omitted or extra step contributes its full field set as incorrect.
- **Sequence accuracy:** cases whose complete ordered step arrays match, including step values; object key order is ignored. This metric catches ordering errors even when all step objects are otherwise present.

## Initial public sample baseline

The oracle self-comparison of `dataset/sample_output.csv` against itself validates the scorer and format only: 32 cases, 10 `COMPLETE`, 22 `INCOMPLETE`, and 193 steps. It yields case/status `32/32`, step precision/recall/F1 `193/193`, field accuracy `1351/1351`, and sequence accuracy `32/32` (all 100%).

### Pipeline iteration 1 (Builder-reported)

Builder reported 32/32 case coverage, case/status 12/32 (37.5%), step F1 5.25%, field accuracy 10.25%, and sequence accuracy 0/32. Its status matrix was exact 12, reference `COMPLETE`→predicted `NOT_APPLICABLE` 5, reference `INCOMPLETE`→predicted `NOT_APPLICABLE` 7, reference `INCOMPLETE`→predicted `COMPLETE` 5, and reference `COMPLETE`→predicted `INCOMPLETE` 3. No prediction artifact was available for that iteration, so those figures are retained as collaborator-reported history and were not independently reproduced.

### Pipeline iteration 2 (QA-reproduced)

Reproduced the current code with `python code/main.py --requests dataset/sample_deletion_requests.csv --output <temporary-csv>` and scored it with `python code/evaluation/main.py <temporary-csv>`. The temporary prediction file was removed after scoring. `GHOSTDATA_VLM_MODEL` was blank; the pipeline reported no vision model, 0 calls, and 0 input/output tokens.

- Coverage: 32/32.
- Case/status accuracy: 23/32 (71.875%). Matrix: reference `COMPLETE`→predicted `COMPLETE` 1; `COMPLETE`→`INCOMPLETE` 9; `INCOMPLETE`→`INCOMPLETE` 22.
- Step precision: 13/49 (26.53%); recall: 13/193 (6.74%); F1: 10.74%.
- Field accuracy: 208/1407 (14.78%).
- Sequence accuracy: 0/32.

This reproduces the metrics in Builder's category-precedence update. No persistent prediction CSV was retained.

### Error diagnosis for iteration 2

**Case/status, first priority:** nine reference `COMPLETE` cases are predicted `INCOMPLETE`: `case_01`, `case_02`, `case_03`, `case_04`, `case_21`, `case_25`, `case_26`, `case_27`, and `case_28`. The sample requests resolve to an identity in all nine. The reproducible `--trace` run shows zero identity-matched activities, zero linked activity observations, zero direct evidence matches, zero linked resources, zero reconstructed states, and zero steps for each. Global pre-cutoff activity/evidence rows exist, but none match these subjects. Thus the observed gap is evidence linkage/coverage after identity resolution, not intent classification.

Builder's follow-up reports exact `subject_selector` candidate matches for these cases only in evidence captured after their `audit_at`; those later records are correctly excluded. Keep the cutoff intact. The next investigation is whether earlier evidence can be linked through historical identifiers or extracted from currently unsupported image-only sources. The empty-state branch emits `INCOMPLETE, []`; this is conservative under missing proof, but it does not explain or remediate the underlying evidence gap.

**Step and field coverage:** only 13 of 193 reference steps match; 180 are missing and 36 are extra. All 32 cases have at least one missing step; 10 have extras. Most frequently missing operations are `VERIFY_RECORD_ABSENT` (49), `VERIFY_RECORD_PRESENT` (23), `DELETE_RECORD` (18), `REPORT_REMAINING_RECORD` (17), `VERIFY_RECORD_ANONYMIZED` (12), and `REPORT_EXPOSED_PII` / `VERIFY_RECORD_REDACTED` (10 each). The most affected public sample cases are `case_30`, `case_29`, `case_18`, and `case_11`; each omits two exposed-PII findings, two absent verifications, and several related finding/remediation steps. Positional field accuracy is 208/1407 (14.78%); mismatches occur across `system_id` (180), `resource_id` (179), `operation` (175), `state` (172), `phase` (169), `evidence_id` (164), and `step_no` (160). This broad mismatch pattern points to step inventory and resource/evidence alignment as the primary issue, rather than a single serialization field.

**Sequence and ordering:** exact sequence accuracy is 0/32 and no case has an exact step multiset, so none of the sequence failures is an order-only error. All 32 predicted arrays comply with the required phase/operation/system/resource sort. Keep the deterministic sort; improve record discovery, operation selection, resource IDs, and evidence references first, then rerun sequence scoring.

## Synthetic edge cases

All fixtures use fictional `synthetic_*` case, service, evidence, and resource identifiers and are exercised in `code/tests/test_evaluation_scorer.py`.

1. **Non-deletion request:** `NOT_APPLICABLE` with an empty step list; should score the status and sequence exactly, with field accuracy not applicable because there are no fields to compare.
2. **JSON object key order:** identical one-step answers with dictionary keys inserted in opposite orders; should remain an exact step and sequence match.
3. **Step order swap:** two identical-content steps appear in reverse order; step precision/recall remain perfect while field-by-position and sequence accuracy reveal the ordering error.
4. **Missing step:** prediction omits one of two expected steps; recall is 50%, sequence accuracy is zero, and omitted fields lower field accuracy.
5. **Duplicate case ID:** scorer rejects ambiguous input instead of silently overwriting one row.

## Failures found and improvements

- The starter `code/evaluation/main.py` was empty, so there was no runnable scoring interface. Added a standard-library-only CLI and importable scorer.
- A single exact-row score would conflate step content and ordering. Separate multiset step metrics, positional field accuracy, and exact ordered-sequence accuracy now localize those failure types.
- Added explicit case-ID join, duplicate detection, and JSON shape validation to prevent malformed inputs from producing misleading scores.
- The earlier Builder-reported iteration had substantial request-intent false negatives and a 472-step explosion; the category-precedence fix reduced the current sample prediction to 49 steps and improved status accuracy to 71.875%.
- The current trace narrows the nine status mismatches: identity resolves, but there is no linked activity or evidence before `audit_at`; later exact `subject_selector` matches must remain excluded. Improve earlier-evidence linkage/extraction rather than weakening the temporal cutoff.
- Current results still show low step recall (6.74%), low field accuracy (14.78%), and zero exact sequences. Builder reports image-only evidence is not parsed because no OCR/VLM model is configured; those cases remain a known evidence-extraction gap.
- Next improvement target: raise relevant-step recall and verify image evidence handling, then rerun this same sample command and compare all four metric groups.


## Evidence map and cutoff audit (public sample, 24 Oct 2026)

Mapped all 193 gold steps in `dataset/sample_output.csv` to the manifest and request cutoff. **75 steps carry an evidence ID (13 distinct files); all 75 cited files were captured on/before their case's `audit_at`. The other 118 steps have empty evidence IDs and are proposed remediation/future verification, so they do not have source observations by contract.** No gold evidence citation in the public sample is post-cutoff. This corrects the earlier ?no linked evidence before cutoff? diagnosis: that describes Builder's prediction trace, not the admissible evidence present in the gold's cited files.

| Evidence ID | Gold uses | Cases | Manifest file (captured UTC) |
|---|---:|---|---|
| evidence_01 | 5 | 12, 15, 17, 19 | `evidence/logs/service_events_ap_south_20260915.log` (2026-09-15 11:59:39) |
| evidence_03 | 7 | 11, 13, 14 | `evidence/records/customer_account_handover_20261001.txt` (2026-10-01 12:00:00) |
| evidence_05 | 4 | 16, 22 | `evidence/databases/customer_data_read_replica_20260921.sql` (2026-09-21 10:00:00) |
| evidence_51 | 4 | 31, 32 | `evidence/records/customer_data_snapshot_bundle_20260915.json` (2026-09-15 12:00:00) |
| evidence_54 | 4 | 01, 02, 04, 05 | `evidence/databases/customer_accounts_failover_replica_20260902.sql` (2026-09-02 23:00:00) |
| evidence_56 | 1 | 04 | `evidence/records/customer_analytics_report_20260907.json` (2026-09-07 09:45:00) |
| evidence_57 | 1 | 06 | `evidence/databases/customer_search_primary_20260910.sql` (2026-09-10 08:45:00) |
| evidence_58 | 1 | 07 | `evidence/documents/delivery_correction_attachment.pdf` (2026-09-12 07:30:00) |
| evidence_59 | 1 | 08 | `evidence/records/customer_export_jobs_20260914.json` (2026-09-14 15:40:00) |
| evidence_61 | 1 | 10 | `evidence/logs/support_replica.log` (2026-09-17 22:00:19) |
| evidence_92 | 36 | 21, 23, 24, 25, 26, 27, 28, 29, 30 | `evidence/records/service_resource_export_20260915_114455.json` (2026-09-15 11:44:55) |
| evidence_93 | 1 | 09 | `evidence/databases/customer_data_inventory_20260916.sql` (2026-09-16 08:37:39) |
| evidence_94 | 9 | 03, 18, 20 | `evidence/logs/resource_lookup_trace_20260926_103856.log` (2026-09-26 10:38:56) |

### Requested mismatch cases and smallest actionable gaps

- **case_01 / case_02 ? COMPLETE; one `VERIFY_RECORD_ABSENT` each.** Gold cites evidence_54 and resources `account_001` / `account_002`; the failover SQL is an admissible 2026-09-02 snapshot with `customer_profiles_primary` and `customer_profiles_failover_replica` tables. It does not contain either cited account row. The evidence is a table snapshot, not an explicit per-account 404. The narrow gap is linking an identity/resource to a scoped complete snapshot, then expressing absence without inventing a row. Also check system normalization: `code/main.py` maps failover observations/coverage to `account_failover_replica`, while gold uses logical `account_service`.
- **case_03 ? COMPLETE; absent account, retained audit, anonymized analytics.** evidence_94 has explicit pre-cutoff lookup lines for account_7566 (HTTP 404), audit_record_2016 (`subject_reference=user_43`), and analytics_9406 (all direct identifiers null). The first two are directly linkable; the analytics row has no subject reference and needs a grounded join via the same readback batch/case resource map, not ?all anonymized analytics in the file.? The text-log parser handles `key=value`; instrument whether each parsed observation survives identity linking and category/system mapping.
- **case_04 ? COMPLETE; absent account plus anonymized analytics.** evidence_54 is the admissible SQL snapshot; evidence_56 is the admissible JSON report and contains analytics_901 with null user/email/phone/hash. The row is not independently attributable from its content alone. Link by explicit request/resource evidence (or a same-case lookup relation); do not treat a null-identifier analytics row as belonging to this subject just because it shares a file.
- **case_21 ? COMPLETE; account absent, audit retained, analytics anonymized.** All three cite evidence_92 (captured 11:44:55, cutoff 12:00). Its JSON has a 404 lookup for account_6440 and records for audit_record_3737 / analytics_5335; the latter's identity relation must be grounded. Inspect recursive JSON traversal plus service/category context when diagnosing missed resources.
- **case_25 ? COMPLETE; account absent, audit retained, analytics anonymized.** evidence_92 has account_3136 404, audit_record_451, and analytics_1895; all are before cutoff. Ensure fields inside `service_exports` arrays are traversed and linked to the subject through stable reference or a case-scoped relation.
- **case_26 / case_27 / case_28 ? COMPLETE; six verifications each.** evidence_92 carries the account 404, retained audit, redacted support, anonymized analytics, disabled connector, and blocked restore records named by gold. It is admissible at 11:44:55. The useful debug cut is per-file parsed observation counts and, for each expected resource ID, parsed system/category/state and the exact identity edge. The JSON parser recurses `service_exports`, but linking anonymized/redacted records and recognizing `enabled=false` / `restore_allowed=false` need explicit state interpretation.
- **case_11 ? INCOMPLETE; 4 findings plus 10 planned steps.** evidence_03 is captured at the audit cutoff and its handover rows explicitly label search_052 `FOUND`, analytics_2034/support_864 `IDENTIFIABLE`, and data_flow_9522 `ACTIVE` with the subject email. It is admissible. The file is pipe-delimited prose rather than key-value log lines. `_parse_log_line` currently extracts only `key=value`; `_text_observations` retains the whole line as `text`, so identity may link, but the status tokens are not normalized into `found`/`active`/`identifiable`. Add a parser for the handover row grammar and map those tokens to existence, PII, and active-flow state.
- **case_18 ? INCOMPLETE; same four finding classes as case_11.** evidence_94 has admissible direct lines for search_4013 (hit), analytics_037 and support_5569 (subject email present), and data_flow_4890 (`enabled=true`). The supported `key=value` fields are present; ensure operation-specific interpretation treats `result=hit` as present and `enabled=true` as active. The repeated lookups are grouped by trace IDs, not one request trace; associate each matched record on its own identity fields.
- **case_29 / case_30 ? INCOMPLETE; four findings each, then ten planned steps.** evidence_92 is admissible and contains explicit search, analytics, support, and connector resources for both cases. JSON traversal already supports nested records; prioritize confirming category mapping and observed values for `search_1993` / `search_9359`, `analytics_5208` / `analytics_3697`, `support_5281` / `support_6477`, and active `data_flow_3827` / `data_flow_8524`. This pattern is state interpretation/linkage, not missing or late evidence.

**Builder action:** add parser-stage diagnostics keyed only by evidence ID/resource ID/system/category/state (never print row contents), then fix the handover pipe grammar and normalize failover logical system IDs. For JSON/log cases above, compare expected resource keys against parsed observations before altering identity matching. Preserve `audit_at`: the gold citations are all admissible, and later `subject_selector` hits are not a basis to backdate a result.

### Current artifact limits

This map covers the public sample only. The full 518-request run has not been performed in this QA turn. `usage_report.md` must wait for the verified final run artifact and its actual provider/model/call/token/cost totals; none can be inferred from the sample map.


## Builder iteration 3 ? QA-reproduced 32-case sample

Re-ran after the Builder changes with only the public sample:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
```

The generated `qa_public_sample.csv` was removed after scoring. Pipeline summary: 32 requests, 8 `COMPLETE`, 24 `INCOMPLETE`; VLM unset, zero calls/tokens. Scorer result: coverage 32/32; status accuracy 24/32 (75.00%); 166 predicted vs 193 gold steps; 67 matched steps; precision 40.36%, recall 34.72%, F1 37.33%; field accuracy 812/1407 (57.71%); exact sequences 2/32 (6.25%). These results are from the QA run and differ from Builder's message (23/32 status, 205 steps); the source file was being iterated during this period, so use the command/result above for this observed run.

Compared with the previous QA-reproduced sample (23/32 status, 49 predictions, 13 matched, F1 10.74%, field accuracy 14.78%, sequences 0/32), step F1 rose 26.59 percentage points, field accuracy rose 42.93 points, and two sequences now match. Status accuracy rose by one case. `case_11` now has the correct four target findings/resources (`search_052`, `analytics_2034`, `support_864`, `data_flow_9522`) and 14 total steps, demonstrating the handover row parser is effective. The matched evidence file is admissible at the case cutoff.

### Remaining concrete mismatches

- **Support policy/action:** `case_11`, `case_18`, and `case_30` identify the correct support resources but emit `REPORT_REMAINING_RECORD` + `DELETE_RECORD`; gold requires `REPORT_EXPOSED_PII` + `REDACT_RECORD`. `case_27` and `case_28` falsely report support rows as remaining/deletable, while gold treats them as redacted and complete. `deletion_rules.csv` `rule_05` is conditional: retain support conversations with shared customer/agent/order context and redact prohibited identifiers. `SUPPORT_MESSAGE` must not default to DELETE merely because the parser did not expose a context marker; parse/normalize relevant context and redact identifiers for retained messages. This accounts for the incorrect status in cases 27/28.
- **Expected absence and retained-record proofs:** `case_18`, `case_29`, and `case_30` still omit gold absent account resources and retained audit records. The reference resource IDs are in evidence-backed gold steps; do not infer IDs from user/case numbering. For cases 01/02/04, the failover SQL snapshot is pre-cutoff, and system normalization changed as intended, but predictions still have no steps: the snapshot contains no row for the gold absent account IDs, so no subject-to-resource edge currently establishes which absent account the snapshot is proving.
- **Anonymized analytics after removing broad cross-link:** `case_03`, `case_21`, `case_25`, and `case_26` each omit the gold anonymized analytics verification (`analytics_9406`, `analytics_5335`, `analytics_1895`, `analytics_4566`). Removing the file-wide association stopped speculative attribution, but the sample gold expects these records. Their evidence rows have no direct subject identifiers; restore only with an independently grounded, case-scoped link, not by assigning every identifier-free analytics row in a matched file.
- **Structured evidence resource boundaries:** evidence_92 cases still need precise per-subject resources. `case_21`/25 show some correctly linked retained audit records but lack the account and anonymized analytics checks; cases 27/28 promote redacted support evidence to incomplete. Validate evidence-to-identity links and final status at resource granularity. The QA run's two exact sequences show serialization/order can now match in some cases, but sequence coverage remains low.

The capture-time lower bound and failover `USER_PROFILE` logical-system normalization are present in the code. The cited files in the gold map remain pre-cutoff. Keep output status conservative where no grounded evidence exists; do not manufacture missing resource IDs or weaken cutoffs. No production code or dataset files were edited by QA, and the 518-request run was not performed.


## Builder follow-up iteration ? current QA reproduction

Reproduced the current code twice using only the 32 public sample cases; both runs returned the same result. Commands:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
```

The temporary prediction file was removed. Pipeline summary: 32 requests, 13 `COMPLETE`, 19 `INCOMPLETE`; VLM unset, 0 calls and 0 tokens. Scorer: coverage 32/32; status accuracy 29/32 (90.625%); 193 predicted vs 193 gold steps; 80 exact matched steps; precision/recall/F1 41.45%; field accuracy 949/1470 (64.56%); exact sequences 3/32 (9.375%). This supersedes the immediately preceding iteration-3 run figures above and does not match Builder's reported 23/32, F1 15.08%, and 0 sequences. The verified rerun is repeatable at these metrics.

Status matrix: 19/19 reference `INCOMPLETE` cases remain `INCOMPLETE`; 10/10 reference `COMPLETE` cases are `COMPLETE`; three reference `INCOMPLETE` cases are incorrectly `COMPLETE`: `case_05`, `case_07`, and `case_15`.

### Specific remaining gaps

- **Remove ordinal account-ID synthesis.** `code/main.py` now defines `_account_resource_for_identity` that maps `user_XX` to `account_XX` and then uses failover table coverage to assert that account is absent. The participant-facing evidence does not establish this relationship; sample account IDs are frequently unrelated (`case_21`: user 21 has gold account_6440; current prediction invents account_021). The same false mapping creates extra/incorrect absent-account steps in cases 03/04/11/18/21/25?30 and likely explains the false `COMPLETE` statuses in cases 05/07/15. Remove this inferred mapping. Emit absent-account verification only when an actual identity-to-resource edge and complete-snapshot scope are evidenced. Cases 01/02 happen to align numerically and should not be used to justify the rule.
- **Support message policy is still wrong.** Cases 11 (`support_864`), 18 (`support_5569`), and 30 (`support_6477`) still get `REPORT_REMAINING_RECORD` + `DELETE_RECORD`; gold requires `REPORT_EXPOSED_PII` + `REDACT_RECORD`. The evidence map shows these are admissible rows with `IDENTIFIABLE` or direct PII. Use the support rule's retain-shared-context condition and preserve/redact where applicable; don't default to deleting a support conversation when the status indicates identifiable data. Case 11 also gets a duplicate future absence check for support_864.
- **Correct case_04 evidence provenance.** Expected absent account evidence is evidence_54 and anonymized analytics is analytics_901/evidence_56; current output emits an absent account_004 step citing evidence_90 and omits analytics_901. Do not substitute unrelated inventory evidence solely because it covers the same broad category.
- **Anonymized analytics remain undiscovered after unsafe cross-link removal.** Gold checks `analytics_9406`/evidence_94 in case_03 and `analytics_5335`, `analytics_1895`, `analytics_4566`, `analytics_4574`, and `analytics_6077`/evidence_92 in cases 21, 25?28. Current output misses these and instead emits unsupported account IDs. The referenced evidence rows lack direct identifiers; recover only with an explicit case-scoped link in participant-facing evidence, never by linking every anonymized record in a file.
- **Missing remaining-resource verifications.** Case_18, case_29, and case_30 lack expected audit-record `VERIFY_RECORD_PRESENT` checks; case_18 also lacks its expected absent-account check. For incomplete cases, those steps currently use empty evidence IDs as future checks, but they still need the correct resource IDs grounded in the case's admissible evidence.
- **Failover normalization improved cases 01/02.** These now produce their expected absent-profile verification steps. Case_04 still has the wrong evidence provenance/resource linkage; don't broaden the pass based only on a matching account number.

No production or dataset files were edited by QA; no full 518-case evaluation was run. The detailed previous iteration sections remain historical results, while this section records the latest repeatable sample run.


## Builder latest follow-up ? QA reproduction

Independently reran only the 32 public sample cases after the follow-up changes. The result matched Builder's reported metrics:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
```

The temporary prediction file was removed. Pipeline summary: 32 requests, 11 `COMPLETE`, 21 `INCOMPLETE`; VLM unset, 0 calls/tokens. Scorer: coverage 32/32; status accuracy 31/32 (96.875%); 197 predicted vs 193 gold steps; 83 exact matched steps; precision 42.13%, recall 43.01%, F1 42.56%; field accuracy 977/1484 (65.84%); exact sequences 3/32 (9.375%). Status mismatch: reference `INCOMPLETE`, predicted `COMPLETE` for `case_15`. The capture-time floor and leading-bullet handover parser changes are consistent with the sample run; cases 01/02 now match their absent-account verifications, and cases 27/28 remain `COMPLETE` without treating their stable subject-referenced support rows as violations.

### Remaining case-level gaps

- **Unsupported user-to-account ordinal inference remains.** The current output still generates `account_043` for case_03 (gold is account_7566), `account_021`/`account_025`/`account_026`/`account_027`/`account_028` in cases 21/25?28 (gold uses arbitrary resources account_6440/account_3136/account_5684/account_3866/account_5482), and `account_032`/`account_050`/`account_029`/`account_030` in cases 11/18/29/30. Several use evidence_90 rather than the gold's cited file. User number does not establish account resource ID; remove the inferred relation and only emit resource IDs with a participant-facing identity edge.
- **The one status error is case_15.** It is predicted `COMPLETE`, but gold is `INCOMPLETE`. The expected evidence-backed finding is active `data_flow_9846` from evidence_01, with disable and verify steps, plus absence/present verification for account_4745 and audit_record_1596. Current steps omit the flow and cite evidence_01 as proof of absent account_4745. Check identity matching and event-state interpretation for the evidence_01 lines before accepting COMPLETE.
- **Support records still get the wrong action when direct identifiers are present.** Cases 11 (`support_864`), 18 (`support_5569`), and 30 (`support_6477`) still emit `REPORT_REMAINING_RECORD`/`DELETE_RECORD`; gold requires `REPORT_EXPOSED_PII`/`REDACT_RECORD`. Current fix for identifier-free, subject-referenced support rows improves cases 27/28, but it does not fix these identifiable message rows.
- **Case_04 evidence provenance and analytics are wrong.** Output contains only `account_004` absent using evidence_90; gold uses evidence_54 for account absence and evidence_56 for anonymized `analytics_901`. Use source-scoped coverage only when the snapshot demonstrably covers the correct resource/system and don't drop the analytics record just because it has null direct identifiers.
- **Expected anonymized analytics remain absent.** Cases 03, 21, 25, 26, 27, and 28 lack gold verifications for `analytics_9406`, `analytics_5335`, `analytics_1895`, `analytics_4566`, `analytics_4574`, and `analytics_6077` respectively. evidence_94/evidence_92 are all pre-cutoff per the evidence map, but those rows themselves have no direct subject identifiers. Require a real case-scoped link; do not reinstate a file-wide join.
- **Case_07 has unrelated record attribution.** Expected is support resource `support_001` from evidence_58. Output instead reports unrelated `account_7204` from evidence_54 and verifies `object_19`; inspect extraction/link keys for the PDF and suppress resource candidates that lack a matching subject edge.
- **Case_05 has a contradictory failover step.** Gold marks the case `INCOMPLETE` with three steps; output adds a future `VERIFY_RECORD_ABSENT` for `account_005` on `account_failover_replica`, even though evidence_54 contains account_005 in the failover table. Reconcile the finding/remediation and subsequent verification against the actual row state.
- **Incomplete cases still miss final checks:** cases 18, 29, and 30 omit expected retained audit-record verification; cases 18/29/30 also have absent-account checks with synthesized resource IDs instead of the gold resource. Keep future verification evidence empty, but ground its system/resource pair in that case's data.

This is the latest verified public-sample run and supersedes previous iteration metrics. No production or dataset files were edited by QA; no full-dataset run was performed.


## Admin-requested verification rerun of latest iteration

Re-ran and re-scored the public 32-case sample after Admin's follow-up. The result is identical to the preceding QA run: 32/32 coverage; 31/32 status (96.875%); 197 predicted steps / 193 gold; 83 matched; precision 42.13%, recall 43.01%, F1 42.56%; fields 977/1484 (65.84%); sequences 3/32 (9.375%); VLM unset, zero calls/tokens. The sole status error is still `case_15` (gold `INCOMPLETE`, predicted `COMPLETE`).

Resolution check: user-to-account inference is **not resolved**; unsupported `account_043`, `account_021`, `account_025`?`account_028`, and other ordinal IDs still appear (often with evidence_90). Support redaction is **partially resolved**: identifier-free subject-referenced support cases 27/28 now avoid false findings, but identifier-present support cases 11/18/30 still get DELETE instead of REDACT. Case-scoped anonymized analytics linking is **not resolved**: expected checks remain missing in cases 03 and 21/25?28. New concrete misses/extras confirmed by this rerun are in the preceding iteration section: case_07 cross-record attribution, case_05 contradictory future absence verification, case_04 wrong evidence source/missing analytics, and case_15 missed active flow. Thus the prior 05/07 false-COMPLETE status errors are fixed, but resource attribution remains unsafe and case_15 still has the false-COMPLETE result.


## Latest Builder iteration — independent public-sample rerun

Commands run from the repository root:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
python -m unittest discover -s code/tests -v
```

The pipeline emitted all 32 cases with VLM unset and zero calls/tokens. Scoring against `dataset/sample_output.csv`: status 28/32 (87.50%); 153 predicted / 193 gold steps, 96 exact matched steps; precision 62.75%, recall 49.74%, F1 55.49%; field accuracy 882/1351 (65.28%); exact sequences 5/32 (15.63%). This rerun differs from the prior recorded iteration and supersedes its metrics.

All 8 scorer and synthetic pipeline tests pass. Historical-email resolution, the near-name decoy rejection, and post-cutoff exclusion all passed after Builder's changes.

### Remaining confirmed sample errors

- **False INCOMPLETE on complete snapshots:** cases 01, 02, and 04 are predicted `INCOMPLETE`; gold is `COMPLETE`. Each misses the evidence_54 absent-account verification (`account_001`, `account_002`, `account_004`). Case 04 additionally misses anonymized `analytics_901` / evidence_56. Investigate how failover snapshot coverage is joined to the case and resource identity.
- **False COMPLETE from unrelated evidence:** case 07 is predicted `COMPLETE`; gold is `INCOMPLETE` with a support_001 finding sourced from evidence_58. The prediction instead emits an unrelated `object_19` absence verification from evidence_20. The evidence association still needs case-scoped grounding.
- **Policy action overcorrection:** case 10 gold requires deleting `support_002`, while prediction reports exposed PII and redacts it. Case 13 likewise predicts redaction of `support_4218` where gold requires deletion. Conversely case 12 predicts anonymization of `analytics_9914`, where gold requires deletion. Keep action selection tied to the specific record's policy condition and content.

The generated `qa_public_sample.csv` was removed after scoring. No production or dataset files were edited by QA, and no 518-request evaluation or packaging was performed.


## Admin-requested verification — subsequent Builder sample iteration

Exact commands run from the repository root:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
python -m unittest discover -s code/tests -v
```

Independent rerun matches Builder's reported metrics: 32/32 coverage; status 31/32 (96.875%); 158 predicted / 193 gold steps, 110 exact matched; precision 69.62%, recall 56.99%, F1 62.68%; field accuracy 945/1351 (69.95%); exact sequences 10/32 (31.25%). Pipeline reports VLM unset, zero calls/tokens. All 8 scorer and pipeline tests pass. The three pipeline cases for historical email, near-name decoy rejection, and post-cutoff evidence all pass.

Exact-row accuracy for the same verified `admin_verified_sample.csv` is 10/32 (31.25%): each row must match both status and the entire ordered steps array.

### Case_04 and case_12 interpretation

- **case_04 is the one remaining status error:** gold is `COMPLETE`, prediction is `INCOMPLETE` with no steps. Gold cites evidence_54 for absent `account_004` and evidence_56 for anonymized `analytics_901`; both manifest capture times precede the 2026-09-07T10:20:00Z cutoff. evidence_54 is a SQL snapshot with four failover and three primary customer-profile rows. The pipeline still fails to connect the user/case to the scoped absence proof and to emit the evidence_56 analytics verification; it should use source scope and grounded identity linkage, without inventing an account ID.
- **case_12 has a sample-reference versus policy discrepancy:** the prediction reports/anonymizes `analytics_9914` from admissible evidence_01; the observed log event has a resource row and a correlation key matching the resolved identity, so the record is attributable. `deletion_rules.csv` rule_07 says an attributable `ANALYTICS_PROFILE` requires `ANONYMIZE`, matching the current prediction. The sample reference instead requests `DELETE_RECORD`/`VERIFY_RECORD_ABSENT`. This is not a confirmed pipeline defect under the supplied policy; resolve the category/policy-versus-sample discrepancy before changing the action.

The generated `qa_public_sample.csv` was removed. No production code or dataset inputs were edited, and the full 518-request evaluation and packaging were not run.


## Admin follow-up — identity-key logs, case_12 policy, and NOT_APPLICABLE audit

Latest sample commands:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
python -m unittest discover -s code/tests -v
```

The fresh run reproduced 32/32 coverage; 31/32 statuses (96.875%); 158 predicted / 193 gold steps, 110 exact matched; step precision 69.62%, recall 56.99%, F1 62.68%; field accuracy 945/1351 (69.95%); 10/32 exact sequences (31.25%). Exact-row accuracy is also **10/32 (31.25%)**, comparing status and the full ordered parsed step array. Case_04 remains the sole status mismatch. VLM was unset with zero calls/tokens. All 9 tests passed.

Added a pipeline fixture that writes escaped quoted key/value logs containing no raw email and exercises identity matching via each of `matched_value`, `lookup_key`, `scan_key`, `correlation_key`, and `subject_key`. A post-audit cutoff fixture with an escaped, hash-only `correlation_key` also passes. Fixtures use fictional identities and temporary files only.

### Case_12 operation-based treatment check

The discrepancy note remains. Participant-facing `deletion_rules.csv` rule_07 says `ANALYTICS_PROFILE` records that remain attributable require `ANONYMIZE`. The pre-cutoff evidence_01 event for `analytics_9914` contains a correlation key matching the resolved identity, so attribution is present. `system_activity.csv` has `activity_3435`, an earlier `DELETE_RECORD` attempt whose reported result is `FAILED`; this confirms an attempted operation, not a policy rule or successful state change. The public sample answer explicitly expects `DELETE_RECORD` and absence verification. The operation and sample agree with each other, but conflict with rule_07, so the operation-based hypothesis does not resolve the discrepancy without overriding the supplied policy.

### Manual intent audit of production NOT_APPLICABLE rows

Reviewed the `request_text` for all 21 `NOT_APPLICABLE` rows in the already-generated root `output.csv`, matching each to `dataset/deletion_requests.csv`. Fourteen are questionable false `NOT_APPLICABLE`: the Portuguese text explicitly requests permanent account deletion, but the current classifier returns false because it does not recognize the wording. IDs: `case_54`, `case_93`, `case_132`, `case_171`, `case_210`, `case_249`, `case_288`, `case_327`, `case_366`, `case_405`, `case_444`, `case_483`, `case_522`, and `case_546`. The other seven are non-deletion requests (profile/contact changes, data/invoice copies, a marketing-only opt-out, or an explicit request to leave the account unchanged) and are correctly `NOT_APPLICABLE`.

This review only inspected the 21 existing output rows and their request text; it did not rerun the 518-request pipeline. The 518-row production execution remains complete, but its hidden-gold accuracy is unknown and unscored. The QA-generated `qa_public_sample.csv` was removed after evaluation; no production code or dataset files were changed.


## Latest Builder operation-treatment iteration — QA rerun

Commands run against the current shared code:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
python -m unittest discover -s code/tests -v
```

Verified metrics: coverage 32/32; status 31/32 (96.875%); 160 predicted / 193 gold steps, 114 exact matched; precision 71.25%, recall 59.07%, F1 64.59%; fields 960/1351 (71.06%); exact sequences 11/32 (34.38%); exact rows 11/32 (34.38%), requiring both matching status and the complete ordered step array. `case_04` remains the sole status mismatch. The pipeline used no VLM (0 calls/tokens). All 9 tests pass.

`case_12` now emits the public reference's DELETE steps, so the prior sample action mismatch is closed. The policy conflict remains: activity_3435 is a `DELETE_RECORD` event with `reported_result=FAILED`, and the public sample expects DELETE, but rule_07 says attributable `ANALYTICS_PROFILE` records require ANONYMIZE. The current code selects treatment from the latest operation event without checking its result; that matches the sample here but is not supported by rule_07 for a still-attributable record. Keep the discrepancy note until the governing policy is clarified; do not claim the conflict is resolved.

The prior `NOT_APPLICABLE` audit remains: the existing 518-row `output.csv` still contains 21 such rows, including the same 14 explicit Portuguese permanent-deletion requests (`case_54`, `case_93`, `case_132`, `case_171`, `case_210`, `case_249`, `case_288`, `case_327`, `case_366`, `case_405`, `case_444`, `case_483`, `case_522`, `case_546`). The current `is_deletion_request` classifier still returns false for those 14 texts. The other seven N/A requests have non-deletion intent. This turn classified the 21 existing rows and reran only the 32 public cases; it did not run the full 518 requests or alter production code/dataset files. The temporary QA prediction was removed after scoring.

## Admin follow-up � Portuguese intent handling QA rerun

Commands run from the repository root:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
python -m unittest discover -s code/tests -v
python code/intent_regression.py
```

The public-sample pipeline produced 32/32 rows (9 `COMPLETE`, 23 `INCOMPLETE`), with VLM unset and zero calls/tokens. Scoring against `dataset/sample_output.csv`: status accuracy 31/32 (96.875%); 160 predicted / 193 gold steps, 114 exact matches; precision 71.25%, recall 59.07%, F1 64.59%; field accuracy 960/1351 (71.06%); exact sequences 11/32 (34.38%). Exact-row accuracy is 11/32 (34.38%), where a row requires matching status and the complete ordered parsed step array. The sole status mismatch remains `case_04` (gold `COMPLETE`, prediction `INCOMPLETE`). All 9 unit tests passed, including historical-email linkage, decoy rejection, escaped identity aliases, and cutoff exclusion. The six-case synthetic intent regression runner passed all 6 cases (three positive deletion requests in Portuguese and three negative/negated controls).

Rechecked the 21 rows currently marked `NOT_APPLICABLE` in the existing root `output.csv` by applying the current `is_deletion_request` classifier to each corresponding participant-facing request text. Fourteen now classify as deletion intent, confirming the Portuguese intent fix; seven remain non-deletion intent. The 14 IDs are `case_54`, `case_93`, `case_132`, `case_171`, `case_210`, `case_249`, `case_288`, `case_327`, `case_366`, `case_405`, `case_444`, `case_483`, `case_522`, and `case_546`. This is a classifier check against those existing rows, not a regenerated 518-row output; do not interpret it as reclassification in the existing `output.csv` until Operator reruns production.

### Case_12 policy conflict remains

The current sample prediction matches the public reference for `case_12`, including `DELETE_RECORD` for `analytics_9914`; the sample status and complete ordered step array match. However, `deletion_rules.csv` rule_07 says an attributable `ANALYTICS_PROFILE` requires `ANONYMIZE`. `activity_3435` records a `DELETE_RECORD` attempt with result `FAILED`, which is not evidence of a successful treatment and does not override the policy. Since the record remains attributable in the case evidence, the public gold's DELETE treatment conflicts with the supplied policy. Keep this as a documented reference-versus-policy discrepancy; no QA production or dataset files were changed, and no 518-case execution was run.

## Admin follow-up � empty-case subset and current intent QA

Recreated the 25-case subset from the named rows in participant-facing `dataset/deletion_requests.csv` and ran only those requests with trace enabled:

```powershell
python code/main.py --requests qa_25_requests.csv --output qa_25_predictions.csv --trace
```

The run returned 25 rows: 20 evidence-backed outputs, 3 `NOT_APPLICABLE`, and 2 empty `INCOMPLETE` rows (`case_39`, `case_55`). The three N/A rows are `case_534`, `case_536`, and `case_539`; direct review of their request intent confirms promotional-email opt-out while retaining the account, login recovery with an explicit instruction not to close the account, and an information-access request. The current classifier returns false for deletion intent on all three.

### Cutoff check for the two empty INCOMPLETE cases

- `case_39` cutoff is `2026-08-08T10:00:00Z`. The pre-cutoff identity/resource link is `activity_4002` at `2026-08-07T08:07:01Z` for `data_flow_1121`. The activity is a `LINK_RESOURCE_IDENTITY` claim and does not establish whether the flow was active. The stateful sync event `activity_3434` is dated `2026-08-25T12:44:24Z`, after cutoff. The only matching resource state line found in participant-facing evidence is `evidence_01` at `2026-09-15T11:54:45Z`, also after cutoff. The traced evidence parser found zero direct matches as of cutoff.
- `case_55` cutoff is `2026-04-30T11:00:00Z`. The pre-cutoff link is `activity_4006` at `2026-04-29T09:07:01Z` for `backup_9287`; it establishes identity association only, not restorability. The restore operation `activity_3387` is dated `2026-08-22T12:58:26Z`, after cutoff. Its only matching state line is in `evidence_01`, captured `2026-09-15T11:59:39Z`, after cutoff. The traced parser found zero direct evidence matches as of cutoff.

Thus the two empty `INCOMPLETE` outputs are not resolvable as evidenced violations at their respective cutoffs from the located participant-facing records. The linked activity rows prove resource identity only; post-cutoff state claims cannot establish the earlier state. Keep the cases unresolved rather than inferring an active flow or restorable backup from identity linkage alone.

### Fresh 32-case public sample

Commands:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
python -m unittest discover -s code/tests -v
python code/intent_regression.py
```

Current metrics remain: coverage 32/32; status accuracy 31/32 (96.875%); 160 predicted / 193 gold steps, 114 matched; precision 71.25%, recall 59.07%, F1 64.59%; fields 960/1351 (71.06%); exact sequences 11/32 (34.38%); exact rows 11/32 (34.38%). Sole status mismatch remains `case_04`. VLM is unset, with zero calls/tokens. All 9 unit tests and all 6 synthetic intent regressions pass. The previously documented case_12 reference-versus-rule_07 conflict remains unchanged. Temporary QA CSVs were removed; no production code or dataset inputs were changed, and no 518-case run was performed.

## QA regression coverage and fresh post-Builder verification

The synthetic suite now covers the requested parser and policy boundaries. Existing fixtures cover historical-email resolution, near-name decoy rejection, post-cutoff evidence exclusion, escaped quoted identity keys through five alias fields, and scoring edge cases. Added three fictional-only end-to-end tests in `code/tests/test_pipeline_synthetic.py`:

- PDF text extraction through a mocked `PdfReader`, including document-scoped resource association;
- image OCR/VLM fallback through a mocked transcription result, including call/token accounting (no real model or OCR service is invoked);
- `SUPPORT_MESSAGE` category/treatment: a subject-linked record with a direct identifier yields exposed-PII finding, redaction remediation, and redaction verification.

Fresh verification commands:

```powershell
python -m unittest discover -s code/tests -v
python code/intent_regression.py
python code/log_parser_regression.py
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
```

All 12 unit tests, 6 synthetic intent cases, and 2 structured-log parser regressions pass. The 32-case sample is unchanged: coverage 32/32; status 31/32 (96.875%); 160 predicted / 193 gold steps, 114 matched; precision 71.25%, recall 59.07%, F1 64.59%; fields 960/1351 (71.06%); exact sequences and exact rows 11/32 (34.38%). The only status mismatch is still `case_04`; VLM unset, zero calls/tokens.

A fresh 21-request intent subset, comprising the 14 previously identified Portuguese deletion requests and seven non-deletion controls (`case_533`�`case_539`), produced 14 deletion-authorized statuses (1 COMPLETE, 13 INCOMPLETE) and 7 NOT_APPLICABLE. Separately reran the 25-case unresolved subset: 20 rows have steps, 3 are NOT_APPLICABLE, and only `case_39` and `case_55` remain INCOMPLETE with empty steps. Their identity-only pre-cutoff links and post-cutoff state evidence remain as documented above. Case_12's rule_07 versus failed activity/public-reference conflict also remains documented. All generated QA subset and sample CSVs were removed; no production code or participant dataset inputs were changed, and the 518-case run was not repeated.

## QA � cached extraction and one-to-one activity-link iteration

Independently ran the current Builder snapshot against the 32 public sample cases:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_public_sample.csv
python code/evaluation/main.py qa_public_sample.csv
```

Verified metrics: coverage 32/32; status accuracy 32/32 (100%); 161 predicted / 193 gold steps, 114 matched; precision 70.81%, recall 59.07%, F1 64.41%; field accuracy 962/1351 (71.21%); exact sequences 11/32 (34.38%); exact rows 11/32 (34.38%). The VLM is unset, with zero calls/tokens. This matches Builder's reported metrics. All sample statuses are correct; remaining error is in step content/coverage/order (only 11 exact step sequences).

Regression commands:

```powershell
python -m unittest discover -s code/tests -v
python code/intent_regression.py
python code/log_parser_regression.py
python code/local_text_regression.py
python code/activity_link_regression.py
```

All 12 unit tests, 6 intent cases, 4 structured-log parser cases, 3 local-text cache/PDF/OCR cases, and 3 one-to-one activity-link cases pass. The pipeline synthetic tests added in this report additionally exercise mocked PDF extraction and document-scoped subject matching, mocked image OCR/VLM fallback and usage counters, and support-message redaction treatment. No real model or OCR service was invoked for synthetic fixtures.

Re-ran the 21 intent requests (14 previously identified Portuguese deletion requests plus the seven non-deletion controls case_533�case_539): results were 1 COMPLETE + 13 INCOMPLETE for deletion-authorized requests and 7 NOT_APPLICABLE. Re-ran the unresolved 25-case subset: 20 have steps, three are NOT_APPLICABLE, and only case_39/case_55 remain empty INCOMPLETE. A fresh two-case trace confirms both still have one identity-linked activity observation with unknown state and zero direct evidence matches at cutoff. case_39's flow identity link is activity_4002; case_55's backup identity link is activity_4006. The corresponding state-bearing sync/restore activity events and evidence_01 log observations are all after each case's audit cutoff, so neither row supports a state finding at cutoff. The case_12 policy/reference conflict remains documented in the preceding section.

**Earlier freeze recommendation (superseded):** At the preceding snapshot QA found the code ready for Operator's final run, with case_39/case_55 limitations. The latest Builder snapshot was retested below and is not recommended for a quality-ready freeze because it still misses pre-cutoff visual state in evidence_14 and leaves eight empty INCOMPLETE rows in the focused subset.

## Admin follow-up � latest PDF-reference patch QA

Reran the current shared code on the public sample and scored the generated output twice; both runs were identical. Exact command/result files were temporary and removed after verification:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_recheck_sample.csv
python code/evaluation/main.py qa_recheck_sample.csv
```

Verified metrics for this snapshot: coverage 32/32; status accuracy 32/32 (100%); 162 predicted / 193 gold steps, 114 matched; precision 70.37%, recall 59.07%, F1 64.23%; field accuracy 965/1351 (71.43%); exact sequences 11/32 (34.38%); exact rows 11/32 (34.38%). VLM is unset with zero calls/tokens. This repeated QA result differs slightly from Builder's reported 64.41% F1 / 71.21% fields; the two QA runs were identical at 64.23% / 71.43%.

### Focused subset and evidence_14

Reran the existing nine-request focused subset with trace. `case_33` now emits three steps: a remaining export finding citing `evidence_18`, followed by proposed delete and verification steps with empty evidence IDs. The exact empty-INCOMPLETE residuals in this subset are `case_35`, `case_39`, `case_50`, `case_52`, `case_53`, `case_55`, `case_61`, and `case_63` (8/9); all nine are INCOMPLETE.

Manually inspected `evidence_14` (`evidence/images/connector_management_console_20260807.png`). Its manifest capture time is `2026-08-07T08:00:00Z`, before `case_39`'s `2026-08-08T10:00:00Z` audit cutoff. The screenshot visibly shows `data_flow_1121` in Healthy status, continuous sync mode, and recent successful activity; the selected connector matches the already-resolved subject. This is admissible state evidence for an active flow. However, the current run still emits zero steps for `case_39`; its trace has zero direct evidence matches. The environment has no `tesseract`, `pdftotext`, or `pdftoppm`, and VLM is unset, so the current pipeline did not extract the screenshot state.

The six other zero-step requests are `case_35`, `case_50`, `case_52`, `case_53`, `case_61`, and `case_63`; their evidence requires OCR, unavailable in this environment. `case_55` remains uncertain because an archive identity link does not prove restore permission at the cutoff. Thus the latest change fixed case_33, but it has not yet resolved case_39's admissible visual state or the six OCR-dependent cases.

### Regression results and freeze recommendation

```powershell
python -m unittest discover -s code/tests -v
python code/intent_regression.py
python code/log_parser_regression.py
python code/local_text_regression.py
python code/activity_link_regression.py
python code/main.py --requests qa_empty_subset_requests.csv --output qa_recheck_empty.csv --trace
```

All 12 unit tests, 6 intent cases, 4 log-parser cases, 3 local-text cases, and 3 activity-link cases pass. The 32-case sample has perfect status accuracy but only 11/32 exact sequences; the focused subset has eight empty INCOMPLETE rows, including one (`case_39`) with admissible active-flow evidence the current pipeline failed to parse. **QA does not recommend freezing this snapshot for a quality-ready final run yet.** The OCR dependency or image-state extraction path needs resolution and QA confirmation; `case_55` should remain conservative absent restore-state proof. No production code or dataset inputs were edited by QA; no full 518-case run was executed.

## Admin follow-up - latest extraction-path verification

Independently reran the current working-tree snapshot after Builder's latest patch. The 32 public cases produced the same metrics as the previous QA snapshot: 32/32 case statuses correct (100%); 162 predicted / 193 reference steps, 114 matched (70.37% precision, 59.07% recall, 64.23% F1); 965/1,351 fields correct (71.43%); 11/32 exact sequences and exact rows (34.38%). The pipeline reported VLM unset and zero vision calls/tokens.

Commands and results:

```powershell
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_recheck_sample_current.csv
python code/evaluation/main.py qa_recheck_sample_current.csv
python -m unittest discover -s code/tests -v
python code/intent_regression.py
python code/log_parser_regression.py
python code/local_text_regression.py
python code/activity_link_regression.py
python code/main.py --requests qa_empty_subset_requests.csv --output qa_recheck_empty_current.csv --trace
```

All 12 unit tests passed. The focused suites passed: 6 intent cases, 4 structured-log cases, 3 local-text/PDF/OCR cases, and 3 activity-link cases. The PDF/OCR extraction tests use synthetic files and mocks; this run made no actual vision calls. `pypdf` is importable, but `tesseract`, `pdftotext`, and `pdftoppm` are absent, and `GHOSTDATA_VLM_MODEL` is unset.

The nine-request subset again produced one nonempty row and eight empty INCOMPLETE rows. `case_33` now has the expected three export steps. The empty rows are `case_35`, `case_39`, `case_50`, `case_52`, `case_53`, `case_55`, `case_61`, and `case_63`; each trace shows one identity-linked activity resource and zero direct evidence matches. For `case_39`, `activity_4002` links `data_flow_1121` to the subject before the `2026-08-08T10:00:00Z` cutoff. Participant-facing manifest `evidence_14` was captured at `2026-08-07T08:00:00Z`; direct visual inspection shows the matching connector selected, Healthy status, Continuous sync, and recent successful activity. That is admissible active-flow state evidence, yet the pipeline still emits INCOMPLETE with no steps. Later sync activity `activity_3434` is after cutoff and is not used to establish the earlier state.

The remaining empty rows also have only identity links in their current traces, not state observations. In particular, `case_55`'s `activity_4006` links `backup_9287` before its `2026-04-30T11:00:00Z` cutoff, while the RESTORE_BACKUP event `activity_3387` is dated `2026-08-22T12:58:26Z`, after cutoff. The identity link does not prove restore permission at the cutoff. The other six empty rows remain unresolved; their state evidence requires OCR that was unavailable in this environment.

**Freeze recommendation: not quality-ready.** The sample and focused regressions are reproducible, but the current default run misses admissible visual active-flow evidence for `case_39` and leaves seven other focused requests without evidence-backed steps. The six additional OCR-dependent cases and the conservative unresolved `case_55` need either a working extraction configuration or evidence-based confirmation before a quality-ready freeze. No production code or participant-facing dataset inputs were changed, and the full 518-request run was not executed.

## Admin follow-up - cached layout-aware OCR QA

Verified the latest layout-aware image extraction code in the working tree (code/main.py timestamp 2026-10-25 13:22 local). QA changed only code/local_text_regression.py and this report; no production pipeline code or dataset input was modified.

Cache and fallback checks:

- The local text cache keys on SHA-256 file content plus an engine/version string. Regression coverage now verifies a repeat with the same content and engine is a cache hit, while changed content or a changed engine invokes extraction again.
- With Tesseract mocked as available, the image path requests TSV output, groups OCR words by row, and emits a DATA_FLOW active-state observation only when a unique linked resource ID and labelled state value appear in the same detail panel. The synthetic PNG/TSV fixture verifies a resource identity link alone supplies the target, while the OCR state text supplies active=true.
- With Tesseract unavailable, image extraction returns no observation and does not launch a process; the pipeline remains runnable. The current CLI does not report local OCR availability, local OCR cache hits, or skipped-image counts: its usage fields report VLM calls/cache/tokens only. README.md also still says Tesseract is not invoked. These are extraction observability/documentation gaps.
- The synthetic PNG is paired with mocked TSV. Since Tesseract is not installed here, actual OCR quality and coordinates from the binary were not exercised. Pillow 12.1.1 and pypdf are importable; tesseract, pdftotext, and pdftoppm are absent; GHOSTDATA_VLM_MODEL is unset.

Commands and results:

```powershell
python -m unittest discover -s code/tests -v
python code/intent_regression.py
python code/log_parser_regression.py
python code/local_text_regression.py -v
python code/activity_link_regression.py
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_recheck_sample_ocr_latest.csv
python code/evaluation/main.py qa_recheck_sample_ocr_latest.csv
python code/main.py --requests qa_empty_subset_requests.csv --output qa_recheck_empty_ocr_latest.csv --trace
```

Results: 12 unit tests passed; 6 intent, 4 log-parser, 5 local-text/cache/OCR, and 3 activity-link tests passed. The sample scored 32/32 statuses, 64.23% step F1 (114 matched of 193 reference and 162 predicted), 71.43% field accuracy (965/1,351), and 11/32 exact sequences/rows. VLM was unset, with zero calls/tokens.

The nine-request subset still has one nonempty row and eight empty INCOMPLETE rows: case_35, case_39, case_50, case_52, case_53, case_55, case_61, and case_63. case_33 has three steps. Every empty-row trace has an identity-linked resource but zero direct state-evidence matches. In particular, activity_4002 links case_39's data_flow_1121 before the cutoff, while participant-facing evidence_14 (captured 2026-08-07T08:00:00Z, before the 2026-08-08T10:00:00Z cutoff) visually shows the matching connector Healthy, Continuous sync, and recent successful activity. The code still misses this admissible state because this runtime has no OCR engine and no VLM configured. For case_55, activity_4006 is identity-only; activity_3387's restore event is after the 2026-04-30T11:00:00Z cutoff, so restoreability remains unproven. The post-cutoff synthetic regression and unique/ambiguous identity-link tests pass; identity links are not treated as resource state.

**Freeze recommendation: not quality-ready.** The new cache and mocked OCR paths behave as intended, but actual Tesseract execution is unavailable, case_39's admissible active state remains missed, and seven other affected rows remain empty. Runtime OCR availability/skipped-image diagnostics are also absent. No full 518-request run was performed.

## Admin follow-up - installed Tesseract OCR verification

Verified the latest Builder snapshot at code/main.py timestamp 2026-10-25 13:36 local. Tesseract 5.4.0.20240606 resolves from C:\Program Files\Tesseract-OCR\tesseract.exe through _tesseract_executable(). Direct TSV OCR of participant-facing evidence_14 recognizes data_flow_1121, Status Healthy, Continuous, and the matching selector.

Commands:

```powershell
python -m unittest discover -s code/tests -v
python code/intent_regression.py
python code/log_parser_regression.py
python code/local_text_regression.py -v
python code/activity_link_regression.py
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_recheck_sample_tesseract_latest.csv
python code/evaluation/main.py qa_recheck_sample_tesseract_latest.csv
python code/main.py --requests qa_empty_subset_requests.csv --output qa_recheck_ocr_patch_final.csv --trace
```

All 12 unit tests passed; focused suites passed 6 intent, 4 log-parser, 5 local-text/cache/OCR, and 3 activity-link tests. QA regression coverage verifies cache hits for repeated file+engine input, misses on file-content or engine change, the mocked Tesseract available and unavailable paths, the reported extractor/skipped-evidence diagnostics, and screenshot-panel state derived from OCR text rather than an identity link.

Public-sample metrics remain 32/32 status accuracy, 64.23% step F1 (114 matched / 193 gold / 162 predicted), 71.43% field accuracy (965/1,351), and 11/32 exact sequences/rows. Runtime diagnostics report image_text_extraction.extractors=[tesseract-tsv-v1] and no skipped evidence IDs; VLM is unset with zero calls/tokens. Diagnostics still omit local OCR cache hit/miss counts and invocation counts.

The nine-request subset is stable: case_33 has four steps; cases 35, 39, 50, 52, 53, and 63 each now have three evidence-backed steps; case_55 and case_61 remain empty INCOMPLETE. Every cited file is captured before its case cutoff: evidence_09 (case_35, 2026-09-01 06:00Z), evidence_14 (case_39, 2026-08-07 08:00Z), evidence_19 (case_50, 2026-07-13 10:00Z), evidence_23 (case_52, 2026-06-18 12:00Z), evidence_28 (case_53, 2026-05-24 07:00Z), and evidence_60 (case_63, 2026-09-16 07:20Z). For case_39, activity_4002 provides the identity/resource link; the screenshot supplies the ACTIVE state and is pre-cutoff. The output cites evidence_14 and contains active-flow finding/remediation/future verification.

case_55 remains appropriately unresolved: activity_4006 links backup_9287 to the subject but establishes no restore permission. Pre-cutoff evidence_32 shows the archive and retention end but no restore-access field; the OCR observation has no state. activity_3387 is post-cutoff. case_61 has identity-only activity_4007 for object_19 and no linked state observation in the trace; do not turn the identity claim into a PRESENT record finding.

Case_12 remains a reference-versus-policy conflict. Current output follows the public sample and predicts DELETE_RECORD for analytics_9914, but participant-facing rule_07 requires ANONYMIZE for an attributable ANALYTICS_PROFILE. activity_3435 is a failed DELETE_RECORD event and does not prove successful deletion or override the rule.

**Freeze recommendation: not quality-ready under the supplied policy.** The installed OCR path now runs and resolves the six formerly empty cases with pre-cutoff evidence, and the two remaining empty cases have no admissible state proof to support a finding. Reconcile case_12's DELETE reference versus rule_07 ANONYMIZE requirement before calling the snapshot policy-correct. No production files or dataset inputs were changed by QA, and the 518-case pipeline was not run.

## Admin policy-fix recheck - current snapshot still predates fix

The requested Builder policy mapping fix is not present in the current `code/main.py`: `load_rules()` reads rule_07 as `ANALYTICS_PROFILE=ANONYMIZE`, but case_12 still emits `DELETE_RECORD` and `VERIFY_RECORD_ABSENT` for analytics_9914. The public-sample prediction was regenerated from the current tree; no 518-row run was performed.

Commands and results:

```powershell
python -m unittest discover -s code/tests -v
python code/intent_regression.py
python code/log_parser_regression.py
python code/local_text_regression.py -v
python code/ocr_screen_regression.py
python code/activity_link_regression.py
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_admin_policy_recheck.csv
python code/evaluation/main.py qa_admin_policy_recheck.csv
python code/main.py --requests qa_empty_subset_requests.csv --output qa_admin_policy_empty_recheck.csv --trace
```

All 15 unit tests, 6 intent regressions, 4 log-parser regressions, 5 local-text regressions, 3 screenshot OCR regressions, and 3 activity-link regressions passed. The public sample scored 32/32 status accuracy, 64.23% step F1 (114 matched / 193 gold / 162 predicted), 71.43% field accuracy (965/1,351), and 11/32 exact rows. Case_12 remains a policy violation: the output follows DELETE while participant-facing `dataset/deletion_rules.csv` rule_07 requires ANALYTICS_PROFILE anonymization. This blocks a policy-correct freeze until Builder's generic mapping fix and regression land.

The focused nine-case subset returned all INCOMPLETE. It has evidence-backed steps for case_33, case_35, case_39, case_50, case_52, case_53, and case_63; only case_55 and case_61 remain empty. case_55 has pre-cutoff backup_9287 evidence with no restore-access state; case_61 has identity-only linkage and no direct state evidence. OCR diagnostics now expose cache counts: 11 hits, 0 misses in this warm run; Tesseract was available, 11 image files were processed, and no image evidence was skipped. Synthetic QA tests separately cover cache hits and content/namespace misses.

**Freeze recommendation: not ready** until case_12 follows rule_07. The two empty rows do not establish state violations from identity-only evidence. No full-dataset run or package was produced.

## Admin follow-up - policy precedence and OCR diagnostics freeze recheck

Verified the newer Builder policy/diagnostics/docs snapshot. `README.md` now documents Tesseract TSV extraction, optional VLM fallback, SHA-256 plus extractor-version cache, availability, counts, extracted IDs, skipped IDs/reasons, and explicitly says policy outranks the conflicting public sample for case_12. `code/main.py` diagnostics report image count, OCR availability, extractor, extracted/skipped IDs and reasons, and cache hit/miss counts. Runtime Tesseract resolves to `C:\Program Files\Tesseract-OCR\tesseract.exe` (5.4.0.20240606).

The generic rule_07 action is now honored over the failed DELETE activity: regenerated case_12 predicts `ANONYMIZE_RECORD` / `VERIFY_RECORD_ANONYMIZED`, consistent with `dataset/deletion_rules.csv`. `python code/policy_precedence_regression.py` passes and verifies that a failed DELETE activity does not override policy.

Commands and results:

```powershell
python -m unittest discover -s code/tests -v
python code/intent_regression.py
python code/log_parser_regression.py
python code/local_text_regression.py -v
python code/ocr_screen_regression.py
python code/activity_link_regression.py
python code/policy_precedence_regression.py
python code/main.py --requests dataset/sample_deletion_requests.csv --output qa_admin_diagnostic_recheck.csv
python code/evaluation/main.py qa_admin_diagnostic_recheck.csv
python code/main.py --requests qa_empty_subset_requests.csv --output qa_admin_diagnostic_subset.csv --trace
```

Results: 15 unit, 6 intent, 4 log parser, 5 local text, 3 OCR screen, 3 activity link, and 1 policy precedence regression passed. Public sample: 32/32 statuses; 110 matched steps (162 predicted / 193 gold), step F1 61.97%; fields 954/1,351 (70.61%); exact sequences/rows 10/32 (31.25%). The drop in sample sequence/step/field scores is expected because the sample expects DELETE for analytics_9914 while the authoritative policy requires anonymization. This mismatch is documented in README and this report; no hidden-gold accuracy is inferred.

OCR diagnostics: Tesseract available, 11 image evidence files, extractor `tesseract-tsv-v1`, 11 cache hits / 0 misses on the warm run, no skipped IDs, no VLM configured. The nine-case focused subset has evidence-backed steps for cases 33, 35, 39, 50, 52, 53, 63; case_39's evidence_14 reports ACTIVE and is captured 2026-08-07T08:00Z, before its 2026-08-08T10:00Z cutoff. case_55 remains empty: pre-cutoff evidence_32 (2026-04-29T09:00Z) proves backup_9287 exists but does not establish restore access; the RESTORE_BACKUP activity is after cutoff. case_61 remains empty: pre-cutoff activity_4007 establishes object_19 identity only, with no direct admissible state evidence. These should remain INCOMPLETE with no unsupported finding.

**Freeze recommendation: ready for Operator's final 518-row execution.** The identified policy conflict is fixed and regression-tested; OCR diagnostics are complete; the two remaining empty cases lack admissible state proof and are properly conservative. The public-sample metric change is the deliberate policy-over-reference result, not hidden-gold scoring. QA did not run or package the full dataset.

### Independent repeat confirmation

A second QA-owned public-sample regeneration on the same code snapshot reproduced the preceding metrics exactly: 32/32 status, 110/193 matched steps (61.97% F1), 954/1,351 fields (70.61%), and 10/32 exact sequences. The case_12 row emits REPORT_EXPOSED_PII, ANONYMIZE_RECORD, and VERIFY_RECORD_ANONYMIZED for analytics_9914. All focused tests were rerun and passed: 15 unit, 6 intent, 4 log-parser, 5 local-text, 3 OCR-screen, 3 activity-link, and 1 policy-precedence. This latest verification supersedes older report sections that recommended against freeze before the policy fix landed. No 518-case execution or packaging was performed.

### Builder follow-up repeat on current shared policy helper

After Builder pointed QA to the generic `_treatment_for_resource` path, a fresh 32-case run and scorer pass independently reproduced the same output: 32/32 status, 110/193 matched steps (61.97% F1), 954/1,351 fields (70.61%), and 10/32 exact sequences. Case_12 remains INCOMPLETE and has REPORT_EXPOSED_PII + ANONYMIZE_RECORD + VERIFY_RECORD_ANONYMIZED for analytics_9914. OCR reports Tesseract TSV, 11 images, 11 cache hits/0 misses, no skipped IDs, and no VLM model. No 518-case run/package.
