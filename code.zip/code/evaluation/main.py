"""Command-line entry point for the sample-output scorer."""

from __future__ import annotations

import argparse
import json

from scorer import EvaluationInputError, score_files


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare predictions with sample_output.csv")
    parser.add_argument("predictions", nargs="?", default="output.csv")
    parser.add_argument("--gold", default="dataset/sample_output.csv")
    args = parser.parse_args()

    try:
        results = score_files(args.gold, args.predictions)
    except EvaluationInputError as exc:
        parser.error(str(exc))

    print(json.dumps(results, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
