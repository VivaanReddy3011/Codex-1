﻿# Usage report

## Final full-dataset run

- Date: 2026-10-25 UTC.
- Command: `python code/main.py`
- Process result: exit code 0; the pipeline reported 518 requests and wrote repository-root `output.csv`.
- Status counts: 150 `COMPLETE`, 358 `INCOMPLETE`, 10 `NOT_APPLICABLE`.
- CSV validation: exact required header; 518 data rows with unique, sorted case IDs matching the 518 input requests; all `steps_json` cells parsed as JSON arrays; step numbers were consecutive wherever steps were present.
- Empty arrays: all 10 `NOT_APPLICABLE` rows have `[]`; zero `COMPLETE` rows have `[]`; two `INCOMPLETE` rows have `[]` (`case_55`, `case_61`).
- OCR extraction: 11 image evidence items processed via `tesseract-tsv-v1`; cache hits 11, misses 0; local Tesseract was available in this environment.

### Known empty-step limitation

Two `INCOMPLETE` rows have empty steps: `case_55` and `case_61`. For these cases, admissible evidence links identity but does not establish resource state at the audit cutoff; no contract-valid findings or remediation steps can be grounded, so the pipeline leaves these rows empty rather than infer state. No hidden-gold comparison was available for the full dataset.

## Model usage and estimated cost

The final run summary reported `vision_model: null` and `vision_usage.calls: 0`, with zero input/output tokens. No model provider or model was used by the core run; no rate card was applied.

| Provider / model | Calls | Input tokens | Output tokens | Total tokens | Estimated cost |
| --- | ---: | ---: | ---: | ---: | ---: |
| None (no model configured or called) | 0 | 0 | 0 | 0 | $0.00 |
| **Overall** | **0** | **0** | **0** | **0** | **$0.00** |

Total tokens: 0. Average: 0 tokens per request (0 across 518 requests). Estimated total and per-request cost: $0.00 and $0.00. The optional local vision path was not used.

## Public-sample evaluation context and limits

The latest independent QA report for the frozen code snapshot records 32/32 status accuracy, 64.41% step F1, 71.21% field accuracy, and 11/32 exact ordered sequences/rows (34.38%). QA also reports 12 unit tests, 6 intent regressions, 4 structured-log parser regressions, 3 local-text regressions, and 3 activity-link regressions passing. These results describe the public sample and synthetic checks only. The full 518-request output was not compared with hidden canonical answers, so hidden-gold accuracy is unknown and unscored.

## Unresolved `case_12` policy/activity conflict

The current operation-based treatment emits `DELETE` for `analytics_9914`, matching the public sample answer. However, `system_activity.csv` activity_3435 reports a `DELETE_RECORD` attempt with result `FAILED`, which does not prove successful deletion. Supplied `deletion_rules.csv` rule_07 says an attributable `ANALYTICS_PROFILE` requires `ANONYMIZE`. The public sample's DELETE expectation, failed operation event, and policy rule remain in conflict; this discrepancy is not resolved by the current output.