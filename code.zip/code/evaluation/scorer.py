"""Deterministic scorer for the public sample answer format."""

from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

OUTPUT_FIELDS = ("case_id", "deletion_status", "steps_json")
STEP_FIELDS = (
    "step_no",
    "phase",
    "system_id",
    "resource_id",
    "operation",
    "state",
    "evidence_id",
)


class EvaluationInputError(ValueError):
    """Raised when a scorer input cannot be evaluated unambiguously."""


def _parse_steps(value: Any, case_id: str) -> list[dict[str, Any]]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as exc:
            raise EvaluationInputError(f"Invalid steps_json for {case_id}") from exc
    if not isinstance(value, list) or any(not isinstance(step, dict) for step in value):
        raise EvaluationInputError(f"steps_json must be an array of objects for {case_id}")
    return value


def _rows_by_case(rows: Iterable[dict[str, Any]], label: str) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        case_id = str(row.get("case_id", ""))
        if not case_id:
            raise EvaluationInputError(f"{label} contains a row without case_id")
        if case_id in result:
            raise EvaluationInputError(f"{label} contains duplicate case_id values")
        if "deletion_status" not in row:
            raise EvaluationInputError(f"{label} is missing deletion_status")
        if "steps_json" not in row and "steps" not in row:
            raise EvaluationInputError(f"{label} is missing steps_json")
        result[case_id] = {
            "deletion_status": row["deletion_status"],
            "steps": _parse_steps(row.get("steps_json", row.get("steps")), case_id),
        }
    return result


def _canonical_step(step: dict[str, Any]) -> str:
    return json.dumps(step, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _same_steps(left: list[dict[str, Any]], right: list[dict[str, Any]]) -> bool:
    return [_canonical_step(step) for step in left] == [
        _canonical_step(step) for step in right
    ]


def _ratio(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def score_rows(
    gold_rows: Iterable[dict[str, Any]], prediction_rows: Iterable[dict[str, Any]]
) -> dict[str, Any]:
    """Score predictions against gold rows without relying on CSV ordering."""
    gold = _rows_by_case(gold_rows, "gold data")
    predicted = _rows_by_case(prediction_rows, "predictions")
    gold_ids = set(gold)
    predicted_ids = set(predicted)
    shared_ids = gold_ids & predicted_ids

    status_correct = sum(
        gold[case_id]["deletion_status"] == predicted[case_id]["deletion_status"]
        for case_id in gold_ids
        if case_id in predicted
    )
    exact_sequences = sum(
        _same_steps(gold[case_id]["steps"], predicted[case_id]["steps"])
        for case_id in gold_ids
        if case_id in predicted
    )

    matched_steps = 0
    gold_step_count = 0
    predicted_step_count = sum(len(row["steps"]) for row in predicted.values())
    matched_fields = 0
    field_slots = 0

    for case_id, gold_row in gold.items():
        expected = gold_row["steps"]
        actual = predicted.get(case_id, {"steps": []})["steps"]
        gold_step_count += len(expected)
        matched_steps += sum((Counter(map(_canonical_step, expected)) &
                              Counter(map(_canonical_step, actual))).values())

        for index in range(max(len(expected), len(actual))):
            expected_step = expected[index] if index < len(expected) else {}
            actual_step = actual[index] if index < len(actual) else {}
            keys = set(expected_step) | set(actual_step)
            field_slots += len(keys)
            matched_fields += sum(
                key in expected_step
                and key in actual_step
                and expected_step[key] == actual_step[key]
                for key in keys
            )

    extra_case_steps = sum(
        len(predicted[case_id]["steps"]) for case_id in predicted_ids - gold_ids
    )
    field_slots += extra_case_steps * len(STEP_FIELDS)

    step_precision = _ratio(matched_steps, predicted_step_count)
    step_recall = _ratio(matched_steps, gold_step_count)
    if step_precision is None and step_recall is None:
        step_f1: float | None = 1.0
    elif not step_precision or not step_recall:
        step_f1 = 0.0
    else:
        step_f1 = 2 * step_precision * step_recall / (step_precision + step_recall)

    return {
        "gold_cases": len(gold),
        "prediction_cases": len(predicted),
        "case_coverage": _ratio(len(shared_ids), len(gold)),
        "unexpected_prediction_cases": len(predicted_ids - gold_ids),
        "case_status_accuracy": _ratio(status_correct, len(gold)),
        "correct_case_statuses": status_correct,
        "step_precision": step_precision,
        "step_recall": step_recall,
        "step_f1": step_f1,
        "matched_steps": matched_steps,
        "gold_steps": gold_step_count,
        "prediction_steps": predicted_step_count,
        "field_accuracy": _ratio(matched_fields, field_slots),
        "matched_fields": matched_fields,
        "compared_fields": field_slots,
        "sequence_accuracy": _ratio(exact_sequences, len(gold)),
        "exact_sequences": exact_sequences,
    }


def load_csv(path: str | Path, *, gold: bool = False) -> list[dict[str, Any]]:
    path = Path(path)
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            required = set(OUTPUT_FIELDS)
            if reader.fieldnames is None or not required.issubset(reader.fieldnames):
                raise EvaluationInputError(f"CSV is missing required output columns: {path}")
            rows = list(reader)
    except OSError as exc:
        raise EvaluationInputError(f"Cannot read evaluation CSV: {path}") from exc

    if gold:
        return rows
    for row in rows:
        row["steps_json"] = _parse_steps(row["steps_json"], row.get("case_id", ""))
    return rows


def score_files(gold_path: str | Path, prediction_path: str | Path) -> dict[str, Any]:
    return score_rows(load_csv(gold_path, gold=True), load_csv(prediction_path))
