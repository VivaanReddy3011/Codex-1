﻿# Ghost Data Still Exists — Acceptance Digest

Use this as the implementation contract. The source documents are `AGENTS.md`, `problem_statement.md`, and `README.md`; where their report paths conflict, place submission reports under `code/evaluation/` as README.md specifies and as the starter layout provides.

## Input and truth boundaries

- Read participant-facing files only from `dataset/`; never use organizer-only truth.
- Audit every row in `dataset/deletion_requests.csv`, using `audit_at` as the evidence cutoff. Later evidence cannot affect that case. Workflow statuses and activity results are claims, not proof.
- Resolve both current and historical identifiers from `user_identities.csv` and `user_audit_log.csv`. Link records with grounded identifiers, hashes, resource/system IDs, timestamps, and inspected evidence contents.
- First determine whether `request_text` authorizes deletion. Otherwise return `NOT_APPLICABLE` with `[]`.

## Decision and planning

- Treat `deletion_rules.csv` as authoritative for every relevant record, including tombstones, active data flows, and restore paths. Preserve required retained records. For account tombstones, preserve the stable `user_id` only when policy allows and remove direct identifiers. If `sample_output.csv` conflicts with an explicit policy rule, follow the policy-compliant treatment and document the sample discrepancy; do not change the treatment to match the sample.
- `COMPLETE` requires compliant treatment of all relevant copies, required records retained, and no active sync/import/restore path that can recreate prohibited data. For COMPLETE, emit only evidence-backed verification steps.
- `INCOMPLETE` includes supported findings, the full remediation plan, and future verification. Findings cite participant-visible `file_id`, `activity_id`, or `audit_id`; proposed remediation/future verification use `evidence_id: ""`.
- Order deterministically: phase (`FINDING`, `REMEDIATION`, `VERIFICATION`); then operation order from the tables in `problem_statement.md`; then ascending `system_id`; then ascending `resource_id`. Remediation disables flows/blocks restores before dependent records and follows downstream-before-source dependencies where applicable. Step order must be code, never model-generated.

## Output

- Root `output.csv`; exact header `case_id,deletion_status,steps_json`; exactly 518 data rows, one per request, sorted by `case_id`.
- Valid JSON arrays with consecutive `step_no` from 1 and only allowed phases, operations, and states. `NOT_APPLICABLE` must have `[]`.
- No hardcoded case IDs, case labels, family shortcuts, or golden answers.

## Runtime and evidence extraction

- Core pipeline must run independently of Codex/OpenBot subscription access and must not require an LLM/API key.
- Prefer deterministic CSV/SQL parsing, local `sqlite3`, `pdftotext`, and `tesseract`. Optional LLM/VLM fallback is limited to unstructured evidence or request intent; cache model results and log provider/model, calls, input/output tokens, and estimated cost. Secrets come only from environment variables and never enter logs/submission.

## Evaluation and package

- `code/evaluation/evaluation_report.md`: case/status, step, field, and sequence metrics; at least three team-created synthetic cases; failures found and improvements made.
- `code/evaluation/usage_report.md`: final 518-case run model/provider/call/token/cost accounting, totals and per-request averages, plus per-model totals if applicable. With no model calls, explicitly report zero calls/tokens/cost and why.
- Package runnable source, prompts/configuration, README, and evaluation reports in `code.zip`. Exclude `dataset/`, virtual environments, `node_modules`, caches, nested archives, credentials, and secrets. Include root `output.csv` separately as required.
- Root `log.txt` is the readable transcript required by the README. Follow `AGENTS.md` append-only turn format. OpenBot chat is not guaranteed to produce a native Codex trace; do not claim the text log is a full raw agent trace.

## Work sequence and ownership

1. Builder inspects dataset/evidence and reports a deterministic plan; Admin owns this digest and orchestration, not pipeline implementation.
2. QA independently builds the sample scorer and synthetic cases in `code/evaluation/` and `code/tests/`.
3. Builder implements in `code/`; QA reports diffs; iterate status, then steps/fields, then ordering/sequence.
4. Operator runs the full dataset once after convergence, records usage, packages `code.zip`, and checks exclusions.
5. Sentinel performs the read-only pre-submission gate. Tutor prepares the user to explain their own design and evaluation.
