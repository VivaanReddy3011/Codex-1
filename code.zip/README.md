# HackerRank Orchestrate - October 2026

## Ghost Data Still Exists

Build an AI agent that audits whether a user's personal data was actually deleted.

A deletion workflow may report **Complete** while data still exists in databases, logs, support attachments, exports, search indexes, archives, or backups. Sync and restore processes may also bring deleted data back.

For each request, the agent must first determine whether deletion was actually requested. It then returns `COMPLETE`, `INCOMPLETE`, or `NOT_APPLICABLE`, reports any remaining data or recreation risk, and produces the ordered remediation and verification steps required to finish an authorized deletion safely.

Read [`problem_statement.md`](./problem_statement.md) for the complete challenge contract.

---

## Quick Start

Clone the repository and move into the project directory:

```bash
git clone https://github.com/interviewstreet/hackerrank-orchestrate-october26.git
cd hackerrank-orchestrate-october26
```

Start your AI coding tool from the **repository root** so it reads [`AGENTS.md`](./AGENTS.md) and appends session summaries to the root `log.txt`.

### Runtime and setup

Use Python 3.10 or later; the source uses Python 3.10 type-union syntax. The current implementation was inspected with Python 3.12.0. It uses the standard library, with `pypdf` as an optional dependency for extracting text from PDF evidence:

```bash
python -m venv .venv
```

Activate the environment (`.venv\\Scripts\\Activate.ps1` in PowerShell, or `source .venv/bin/activate` on macOS/Linux). Install `pypdf` if PDF evidence should be parsed:

```bash
python -m pip install pypdf
```

PDF text extraction uses `pdftotext` when available and otherwise falls back to optional `pypdf`; scanned PDF pages also need `pdftoppm` and Tesseract for OCR. Image evidence uses Tesseract TSV OCR when its executable is available (`PATH`, or the standard Windows Program Files install location). Without an OCR executable, those image evidence IDs are reported as skipped unless `GHOSTDATA_VLM_MODEL` enables the optional local vision transcription fallback. OCR text is cached in SQLite by source-file SHA-256 and extractor version; set `GHOSTDATA_LOCAL_TEXT_CACHE` to choose the cache file. The CLI reports OCR availability, image/cache counts, extracted text evidence IDs, and skipped IDs with reasons.

### Run and evaluate

From the repository root, generate the full prediction file:

```bash
python code/main.py
```

This reads the participant-facing inputs under `dataset/` and writes `output.csv` in the repository root. To score a prediction file against the public sample answers, run:

```bash
python code/evaluation/main.py output.csv
```

The evaluator defaults to `dataset/sample_output.csv` as its reference. This is a sample diagnostic, not a measure of accuracy against the hidden canonical answers.

### Pipeline approach

The implementation processes each request in these stages:

1. Load request, identity snapshot and audit history, activity, deletion rules, and the evidence manifest.
2. Classify whether the request authorizes deletion; non-deletion and negated requests become `NOT_APPLICABLE` with an empty step array.
3. Resolve the subject from current and historical identifiers as of the request's `audit_at` cutoff.
4. Parse and link participant-facing SQL, JSON, log, text, PDF, and image evidence to subjects and resource IDs. Evidence and activity after `audit_at` are excluded from that request's state.
5. Reconstruct relevant resource and process state at the cutoff and apply category policy and supported operation-based treatment.
6. Build findings, remediation actions, and verification steps in the required phase and operation order.
7. Serialize one row per request, sort by `case_id`, and write the required CSV columns with `steps_json` as a JSON array.

Request intent, identity matching, evidence linking, policy/state handling, planning, and serialization are deterministic Python logic. Tesseract OCR runs locally when installed and requires no model calls. As a fallback, an optional image-transcription path is enabled only when `GHOSTDATA_VLM_MODEL` is set; it sends images to the configured local Ollama-compatible endpoint for transcription, not for deletion decisions. Leave that variable unset for a no-model run.

### Current evaluation notes

The latest public-sample metrics and known discrepancies are recorded in [`code/evaluation/evaluation_report.md`](./code/evaluation/evaluation_report.md); final-run usage is recorded in [`code/evaluation/usage_report.md`](./code/evaluation/usage_report.md). The full dataset output has not been scored against hidden canonical answers. `deletion_rules.csv` is authoritative over the public sample when they conflict: rule_07 requires an attributable `ANALYTICS_PROFILE` to be anonymized, so the pipeline emits `ANONYMIZE_RECORD` for case_12 even though `sample_output.csv` expects DELETE. In the focused OCR subset, cases 55 and 61 remain empty because admissible pre-cutoff evidence does not establish the backup restore state or support-attachment state.

The blank template at `dataset/output.csv` is provided as a reference. The generated submission file is the root-level `output.csv`.


## Dataset

All participant-facing files are in `dataset/`:

| File | Contents |
| --- | --- |
| `deletion_requests.csv` | 518 requests |
| `sample_deletion_requests.csv` | 32 sample requests |
| `sample_output.csv` | Correct sample answers |
| `user_identities.csv` | Current user identities |
| `user_audit_log.csv` | Historical identity changes |
| `system_activity.csv` | Activity across services and data processes |
| `deletion_rules.csv` | Required treatment for each data category |
| `evidence_files.csv` | Manifest of supplied evidence files |
| `output.csv` | Blank output template |

Evidence is stored under `dataset/evidence/` and may include PDFs, images, logs, JSON, plain text, or SQL snapshot exports. SQL captures may contain a primary database, regional replicas, a reporting replica, or a failover replica so replication drift can be investigated directly. The `.sql` files are readable as text and executable with SQLite.

Only `deletion_requests.csv` requires answers. The other files provide evidence and context.

---

## Output

Create `output.csv` with these columns in this exact order:

```text
case_id,deletion_status,steps_json
```

Produce exactly one row per request. `deletion_status` is `COMPLETE`, `INCOMPLETE`, or `NOT_APPLICABLE`. `steps_json` is an ordered JSON array containing findings, remediation actions, and verification checks. Use an empty array (`[]`) for `NOT_APPLICABLE`. Evidence references may be a `file_id`, `activity_id`, or `audit_id`. Determine the resource state at `audit_at` from the available evidence; reported workflow statuses and operation results are claims. Use `dataset/sample_output.csv` as the format reference.

The final file must contain 518 data rows sorted by `case_id` (plus the header row). The grader parses `steps_json` as JSON, so object-key order and whitespace do not matter; array order does. Order findings, remediation, and verification in that phase order. Within a phase, follow the operation order in the problem statement, then sort by `system_id` and `resource_id`.

---

## Evaluation

`output.csv` will be compared with hidden canonical answers. Scoring considers:

- deletion assessment accuracy;
- current and historical identity resolution;
- discovery of remaining data and recreation risks;
- correct policy application and evidence references; and
- completeness and ordering of remediation and verification steps.

Your `code.zip` must include:

```text
code/evaluation/evaluation_report.md
code/evaluation/usage_report.md
```

- `evaluation_report.md` must cover case, row, field, and sequence accuracy, at least three additional evaluation cases created by you, failures found, and improvements made.
- `usage_report.md` must cover the final full-dataset run, including model providers and names, model calls, input and output tokens, total and average tokens per request, and estimated total and per-request cost. Include per-model and overall totals when using multiple models.

**Important:** Place `evaluation_report.md` and `usage_report.md` inside `code/evaluation/` (matching `code/evaluation/main.py` in this starter layout), write your complete evaluation metrics, custom evaluation test cases, and token/cost breakdowns directly inside those Markdown files, and keep prompts in source code or Markdown files. Automated code evaluation ignores raw data files (`.csv`, `.tsv`, `.json`, `.jsonl`, `.sql`, `.log`), so content stored only in those formats will not be visible to the code judge or AI interviewer.

---

## Chat Transcript

This repository includes [`AGENTS.md`](./AGENTS.md), which instructs compatible AI coding tools to append conversation summaries to `log.txt` in the repository root:

| Platform | Path |
| --- | --- |
| macOS / Linux | `<repo root>/log.txt` |
| Windows | `<repo root>\log.txt` |

- Always launch your AI coding agent from the repository root (or explicitly ask it to read `./AGENTS.md` first) so every turn is logged to `log.txt` with the required `User Prompt`, `Agent Response Summary`, `Actions`, and `Context` sections.
- Upload `log.txt` directly as your `chat_transcript` submission on HackerRank.
- Do not include API keys, tokens, credentials, or secrets in prompts, code, configuration, or `log.txt`.

---

## Packaging `code.zip` and Submission

| Item | Description |
| --- | --- |
| `code.zip` | Runnable solution, prompts, configuration, `README.md`, and `evaluation/` reports |
| `output.csv` | One answer row for each of the 518 requests in `dataset/deletion_requests.csv` |
| `chat_transcript` | The root `log.txt` file generated by your coding agent |
| AI interview | Live explanation of your architecture, approach, and evaluation |

You may use any programming language, model, framework, or retrieval approach. Include clear setup and execution instructions in `README.md` inside `code.zip`.

To package `code.zip` from the repository root without bundling the dataset:

**macOS / Linux:**

```bash
zip -r code.zip README.md code -x "*/__pycache__/*" "*/.venv/*" "*/venv/*" "*/node_modules/*" "*/.git/*" "*/.DS_Store"
```

**Windows (PowerShell):**

```powershell
Compress-Archive -Path README.md, code -DestinationPath code.zip -Force
```

When packaging `code.zip`:

- Keep your evaluation reports in `code/evaluation/` so they are bundled automatically with `code` (or add `evaluation` to the archive command above if you placed them in a top-level `evaluation/` directory).
- Do **not** include `dataset/`, virtual environments (`.venv`, `venv`, `node_modules`), or build caches (`__pycache__`). On Windows, keep `.venv` at the repository root (outside `code/`) and remove any `code/__pycache__` folders before running `Compress-Archive`.
- Do **not** include nested archives (`.zip`, `.tar`, `.gz`, `.tgz`, `.7z`, `.rar`) inside `code.zip` — submissions containing nested archive files will be rejected.

Before submitting, confirm that:

- `output.csv` has the exact header `case_id,deletion_status,steps_json` and contains all 518 data rows sorted by `case_id`;
- every `steps_json` value is a valid JSON array with consecutive step numbers starting at `1`;
- findings cite valid evidence IDs, and `COMPLETE` verification steps cite evidence proving the current state;
- proposed remediation and future verification steps use an empty `evidence_id` (`""`);
- `code.zip` includes your runnable code, `README.md`, `code/evaluation/evaluation_report.md`, and `code/evaluation/usage_report.md`;
- `log.txt` follows the `AGENTS.md` turn format and is uploaded to the `chat_transcript` slot; and
- no API keys, credentials, real personal data, or sensitive configuration values are included.
